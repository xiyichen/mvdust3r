import numpy as np
from scipy.optimize import least_squares

def rotation_matrix_from_vector(rvec):
    # 使用罗德里格斯公式从旋转向量计算旋转矩阵
    theta = np.linalg.norm(rvec)
    if theta == 0:
        return np.eye(3)
    k = rvec / theta
    K = np.array([[0, -k[2], k[1]],
                  [k[2], 0, -k[0]],
                  [-k[1], k[0], 0]])
    R = np.eye(3) + np.sin(theta) * K + (1 - np.cos(theta)) * (K @ K)
    return R

def objective_function(params, P1, P2_proj, P):
    # 提取参数
    rvec = params[0:3]       # 旋转向量
    sigma = params[3]        # 缩放因子
    t = params[4:7]          # 平移向量

    # 构造旋转矩阵
    R = rotation_matrix_from_vector(rvec)

    # 应用相似变换
    transformed_P1 = sigma * (R @ P1.T).T + t

    # 投影到 2D
    ones = np.ones((transformed_P1.shape[0], 1))
    homogeneous_P1 = np.hstack((transformed_P1, ones))
    projected_P1 = (P @ homogeneous_P1.T).T

    # 计算残差
    residuals = (P2_proj - projected_P1).flatten()
    return residuals

# 定义投影矩阵 P
# 这里使用简单的正交投影，将 3D 点投影到 XY 平面
P = np.array([[1, 0, 0, 0],
              [0, 1, 0, 0]])

# 创建示例点云 P1 和 P2
# 您可以根据需要替换为您的实际数据
P1 = np.random.rand(10, 3)
# 对 P1 应用一个已知的相似变换来生成 P2
true_R = np.array([[0.866, -0.5, 0],
                   [0.5, 0.866, 0],
                   [0, 0, 1]])
true_sigma = 2.0
true_t = np.array([1, 2, 3])
P2 = (true_sigma * (true_R @ P1.T).T) + true_t

# 计算 P2 的投影点
ones = np.ones((P2.shape[0], 1))
homogeneous_P2 = np.hstack((P2, ones))
P2_proj = (P @ homogeneous_P2.T).T

# 初始参数估计
initial_rvec = np.zeros(3)     # 旋转向量初始值
initial_sigma = 1.0            # 缩放因子初始值
initial_t = np.zeros(3)        # 平移向量初始值
initial_params = np.hstack((initial_rvec, initial_sigma, initial_t))

# 进行非线性最小二乘优化
result = least_squares(
    objective_function,
    initial_params,
    args=(P1, P2_proj, P),
    method='lm'  # Levenberg-Marquardt 算法
    # 如果需要鲁棒损失函数，可以添加 loss 参数，例如 loss='huber'
)

# 提取优化结果
optimized_params = result.x
optimized_rvec = optimized_params[0:3]
optimized_sigma = optimized_params[3]
optimized_t = optimized_params[4:7]
optimized_R = rotation_matrix_from_vector(optimized_rvec)

print("优化后的旋转矩阵 R：\n", optimized_R)
print("优化后的缩放因子 sigma：", optimized_sigma)
print("优化后的平移向量 t：", optimized_t)
