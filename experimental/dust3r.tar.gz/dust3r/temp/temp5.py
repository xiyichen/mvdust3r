import torch
def umeyama_alignment2(P1, P2): # [bs, N, 3], [bs, N, 3] all are torch.Tensor
    """
    Return:
    R: (bs, 3, 3)
    sigma: (bs, )
    t: (bs, 3)
    """
    bs, N = P1.shape[0:2]

    mu1 = P1.mean(1) # [bs, 3]
    mu2 = P2.mean(1)

    X1 = P1 - mu1[:, None]
    X2 = P2 - mu2[:, None]

    # Calculate the Cov
    S = (X2.transpose(-1, -2) @ X1) / N # (bs, 3, 3)

    # SVD decomposition
    U, D, Vt = torch.linalg.svd(S) # [bs, 3, 3], [bs, 3], [bs, 3, 3]

    # diag mat D_mat
    d = torch.ones((bs, 3)).to(P1.device)
    det = torch.linalg.det(U @ Vt) # [bs, ]
    d[:, -1][det < 0] = -1

    D_mat = torch.eye(3).to(P1.device).repeat(bs, 1, 1) # [bs, 3, 3]
    D_mat[:, -1, -1] = d[:, -1]

    # rotation R
    R = U @ D_mat @ Vt

    D_diag = torch.diag_embed(D) # [bs, 3, 3]

    # scale sigma
    var1 = torch.square(X1).sum(dim = (1, 2)) / N # [bs, ]
    sigma = (D_mat @ D_diag).diagonal(dim1 = -2, dim2 = -1).sum(-1) / (var1 + 1e-8) # [bs, ]
    # sigma = np.trace(D_mat @ D_diag) / var1

    # translation t
    # t = mu2 - sigma * R @ mu1 
    t = mu2 - sigma[:, None] * (R @ mu1[:, :, None])[:, :, 0]
    

    return R, sigma, t


bs = 40
N = 50000

P1 = torch.randn((bs, N, 3))

true_R = torch.Tensor([[0.866, -0.5, 0],
                [0.5, 0.866, 0],
                [0, 0, 1]]).repeat(bs, 1, 1)

true_R[0] = torch.Tensor([[0.866, 0.5, 0],
    [-0.5, 0.866, 0],
    [0, 0, 1]])

true_sigma = torch.Tensor([2. + i for i in range(bs)]).reshape(bs, 1, 1)
true_t = torch.Tensor([1, 2, 3]).repeat(bs, 1) # [bs, 3]
P2 = (true_sigma * (true_R @ P1.transpose(-1, -2)).transpose(-1, -2)) + true_t[:, None]
# P2 = (true_R @ (true_sigma * P1)) + true_t


# (W2C * T) * sigma * P1 = W2C * T * sigma * P1

# 计算估计的相似变换
P1 = P1.cuda()
P2 = P2.cuda()
import time
while 1:
    t = time.time()
    R_est, sigma_est, t_est = umeyama_alignment(P1, P2)

    # print("Estimated rotation:\n", R_est)
    # print("Estimated scaling factor:", sigma_est)
    # print("Estimated translation:", t_est)

    print(R_est.mean() + sigma_est.mean() + t_est.mean(), time.time() - t)
