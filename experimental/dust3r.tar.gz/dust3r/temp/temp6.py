import torch
def umeyama_alignment2(P1, P2): # [bs, N, 3], [bs, N, 3] all are torch.Tensor
    """
    Return:
    R: (bs, 3, 3)
    sigma: (bs, )
    t: (bs, 3)
    """
    bs, N = P1.shape[0:2]

    mu1 = P1.mean(1) # [bs, 3]
    mu2 = P2.mean(1)

    X1 = P1 - mu1[:, None]
    X2 = P2 - mu2[:, None]

    # Calculate the Cov
    S = (X2.transpose(-1, -2) @ X1) / N # (bs, 3, 3)

    # SVD decomposition
    U, D, Vt = torch.linalg.svd(S) # [bs, 3, 3], [bs, 3], [bs, 3, 3]

    # diag mat D_mat
    d = torch.ones((bs, 3)).to(P1.device)
    det = torch.linalg.det(U @ Vt) # [bs, ]
    d[:, -1][det < 0] = -1

    D_mat = torch.eye(3).to(P1.device).repeat(bs, 1, 1) # [bs, 3, 3]
    D_mat[:, -1, -1] = d[:, -1]

    # rotation R
    R = U @ D_mat @ Vt

    D_diag = torch.diag_embed(D) # [bs, 3, 3]

    # scale sigma
    var1 = torch.square(X1).sum(dim = (1, 2)) / N # [bs, ]
    sigma = (D_mat @ D_diag).diagonal(dim1 = -2, dim2 = -1).sum(-1) / (var1 + 1e-8) # [bs, ]
    # sigma = np.trace(D_mat @ D_diag) / var1

    # translation t
    # t = mu2 - sigma * R @ mu1 
    t = mu2 - sigma[:, None] * (R @ mu1[:, :, None])[:, :, 0]
    

    return R, sigma, t


bs = 40
N = 50000

# P2 = (true_sigma * (true_R @ P1.transpose(-1, -2)).transpose(-1, -2)) + true_t[:, None]
# P2 = (true_R @ (true_sigma * P1)) + true_t


# (W2C * T) * sigma * P1 = W2C * T * sigma * P1

# P1 = P1.cuda()
# P2 = P2.cuda()
import time
while 1:
    t = time.time()
    P1 = torch.randn((bs, N, 3)).cuda()
    P2 = torch.randn((bs, N, 3)).cuda()
    R_est, sigma_est, t_est = umeyama_alignment2(P1, P2)
    mse = torch.square(P1 - P2).mean()
    P1_transformed = (sigma_est[:,None,None] * (R_est @ P1.transpose(-1, -2)).transpose(-1, -2)) + t_est[:, None]
    mse2 = torch.square(P1_transformed - P2).mean()
    print(mse.item(), mse2.item())
    # print("Estimated rotation:\n", R_est)
    # print("Estimated scaling factor:", sigma_est)
    # print("Estimated translation:", t_est)


R, sigma, t = umeyama_alignment(pred_pts, gt_pts, mask)
pts3d_normalized_rot = (sigma[:,None,None] * (R @ pred_pts.transpose(-1, -2)).transpose(-1, -2)) + t[:, None]
mse = torch.square(pred_pts - gt_pts).mean((1,2))
mse2= torch.square(pts3d_normalized_rot - gt_pts).mean((1,2))
print(mse, mse2)
