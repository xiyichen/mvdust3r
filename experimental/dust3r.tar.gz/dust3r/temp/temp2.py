import numpy as np

def umeyama_alignment(P1, P2):
    """
    使用 Umeyama 方法计算最佳相似变换（旋转、缩放、平移），使得 P1 对齐到 P2。

    参数：
        P1: 源点云，形状为 (N, 3)
        P2: 目标点云，形状为 (N, 3)

    返回：
        R: 旋转矩阵，形状为 (3, 3)
        sigma: 缩放因子
        t: 平移向量，形状为 (3,)
    """
    N = P1.shape[0]

    # 计算质心
    mu1 = P1.mean(axis=0)
    mu2 = P2.mean(axis=0)

    # 中心化点云
    X1 = P1 - mu1
    X2 = P2 - mu2

    # 计算协方差矩阵
    S = (X2.T @ X1) / N

    # SVD 分解
    U, D, Vt = np.linalg.svd(S)

    # 构造对角矩阵 D
    d = np.ones(3)
    if np.linalg.det(U @ Vt) < 0:
        d[-1] = -1
    D_mat = np.diag(d)

    # 计算旋转矩阵 R
    R = U @ D_mat @ Vt

    # 计算缩放因子 sigma
    var1 = (X1 ** 2).sum() / N
    sigma = np.trace(D_mat @ np.diag(D)) / var1

    # 计算平移向量 t
    t = mu2 - sigma * R @ mu1

    return R, sigma, t

# 示例使用
P1 = np.random.rand(10, 3) + np.random.rand(10, 3)+0.1
# 对 P1 应用一个已知的相似变换来生成 P2
true_R = np.array([[0.866, -0.5, 0],
                   [0.5, 0.866, 0],
                   [0, 0, 1]])
true_sigma = 2.0
true_t = np.array([1, 2, 3])
P2 = (true_sigma * (true_R @ P1.T).T) + true_t

# 计算估计的相似变换
R_est, sigma_est, t_est = umeyama_alignment(P1, P2)

print("Estimated rotation:\n", R_est)
print("Estimated scaling factor:", sigma_est)
print("Estimated translation:", t_est)
