import torch
import torch.nn as nn
import torch.optim as optim

import cv2
import numpy as np
import torch

def calibrate_camera_pnpransac(pointclouds, img_points, masks, intrinsics):
    """
    使用 PnP RANSAC 进行相机标定。
    
    参数：
        pointclouds: (bs, N, 3) 的张量，3D 点云。
        img_points: (bs, N, 2) 的张量，对应的 2D 图像点。
        h, w: 图像高度和宽度。
        num_iters: 优化迭代次数 (在PnPRansac中不用，但保持这个参数一致)。
        lr: 学习率 (在PnPRansac中不用，但保持这个参数一致)。

    返回：
        rotations: (bs, 3, 3) 的张量，表示每个批次的旋转矩阵。
        translations: (bs, 3, 1) 的张量，表示每个批次的平移向量。
    """
    bs = pointclouds.shape[0]
    
    # 假设相机的初始内参矩阵，可以根据需要修改
    camera_matrix = intrinsics.cpu().numpy()  # (bs, 3, 3)
    
    dist_coeffs = np.zeros((5, 1))  # 假设没有畸变

    rotations = []
    translations = []
    
    # 遍历每个批次，使用PnPRansac估计相机的旋转和平移
    for i in range(bs):
        # 将3D点和2D点从PyTorch Tensor转换为NumPy数组
        obj_points = pointclouds[i][masks[i]].cpu().numpy()
        img_pts = img_points[i][[masks[i]]].cpu().numpy()

        # 使用RANSAC估计PnP
        success, rvec, tvec, inliers = cv2.solvePnPRansac(obj_points, img_pts, camera_matrix[i], dist_coeffs)

        if success:
            # 将旋转向量转换为旋转矩阵
            rotation_matrix, _ = cv2.Rodrigues(rvec)
            rotations.append(torch.tensor(rotation_matrix, dtype=torch.float32))
            translations.append(torch.tensor(tvec, dtype=torch.float32))
        else:
            # 如果PnPRansac失败，则返回None
            rotations.append(torch.eye(3))
            translations.append(torch.ones(3, 1))

    # 将旋转矩阵和平移向量转换为PyTorch张量
    rotations = torch.stack(rotations).to(pointclouds.device)
    translations = torch.stack(translations).to(pointclouds.device)

    return rotations, translations

def calibrate_camera_pytorch(pointclouds, img_points, h, w, num_iters=10000, lr=1e-3):
    """
    使用 PyTorch 在 GPU 上进行相机标定。

    参数：
        pointclouds: (bs, N, 3) 的张量，3D 点云。
        img_points: (bs, N, 2) 的张量，对应的 2D 图像点。
        h, w: 图像高度和宽度。
        num_iters: 优化迭代次数。
        lr: 学习率。

    返回：
        K_batch: (bs, 3, 3) 的相机内参矩阵。
        extrinsics_batch: (bs, 4, 4) 的相机外参矩阵。
    """
    device = pointclouds.device
    bs, N, _ = pointclouds.shape

    # 初始化内参参数
    fx = torch.full((bs, 1), w / 2.0, device=device, requires_grad=True)
    fy = torch.full((bs, 1), w / 2.0, device=device, requires_grad=True)
    cx = torch.full((bs, 1), w / 2.0, device=device, requires_grad=True)
    cy = torch.full((bs, 1), h / 2.0, device=device, requires_grad=True)

    # 初始化外参参数（旋转向量和平移向量）
    rvec = torch.zeros((bs, 3), device=device, requires_grad=True)
    tvec = torch.zeros((bs, 3), device=device, requires_grad=True)

    # 优化器
    optimizer = optim.Adam([fx, fy, cx, cy, rvec, tvec], lr=lr)

    # 损失函数
    mse_loss = nn.MSELoss()

    for iter in range(num_iters):
        optimizer.zero_grad()

        # 构建内参矩阵 K
        K = torch.zeros((bs, 3, 3), device=device)
        K[:, 0, 0] = fx.squeeze()
        K[:, 1, 1] = fy.squeeze()
        K[:, 0, 2] = cx.squeeze()
        K[:, 1, 2] = cy.squeeze()
        K[:, 2, 2] = 1.0

        # 计算旋转矩阵 R（使用 Rodrigues 公式）
        theta = torch.norm(rvec, dim=1, keepdim=True) + 1e-8
        rvec_normalized = rvec / theta
        theta = theta.unsqueeze(-1)
        cos_theta = torch.cos(theta)
        sin_theta = torch.sin(theta)
        one_minus_cos = 1 - cos_theta

        rx = rvec_normalized[:, 0].unsqueeze(-1)
        ry = rvec_normalized[:, 1].unsqueeze(-1)
        rz = rvec_normalized[:, 2].unsqueeze(-1)

        R = torch.zeros((bs, 3, 3), device=device)
        R[:, 0, 0] = cos_theta.squeeze() + rx.squeeze() * rx.squeeze() * one_minus_cos.squeeze()
        R[:, 0, 1] = rx.squeeze() * ry.squeeze() * one_minus_cos.squeeze() - rz.squeeze() * sin_theta.squeeze()
        R[:, 0, 2] = rx.squeeze() * rz.squeeze() * one_minus_cos.squeeze() + ry.squeeze() * sin_theta.squeeze()
        R[:, 1, 0] = ry.squeeze() * rx.squeeze() * one_minus_cos.squeeze() + rz.squeeze() * sin_theta.squeeze()
        R[:, 1, 1] = cos_theta.squeeze() + ry.squeeze() * ry.squeeze() * one_minus_cos.squeeze()
        R[:, 1, 2] = ry.squeeze() * rz.squeeze() * one_minus_cos.squeeze() - rx.squeeze() * sin_theta.squeeze()
        R[:, 2, 0] = rz.squeeze() * rx.squeeze() * one_minus_cos.squeeze() - ry.squeeze() * sin_theta.squeeze()
        R[:, 2, 1] = rz.squeeze() * ry.squeeze() * one_minus_cos.squeeze() + rx.squeeze() * sin_theta.squeeze()
        R[:, 2, 2] = cos_theta.squeeze() + rz.squeeze() * rz.squeeze() * one_minus_cos.squeeze()

        # 应用外参变换
        X_cam = torch.bmm(pointclouds, R.transpose(1, 2)) + tvec.unsqueeze(1)
        X_cam = X_cam.transpose(1, 2)

        # 投影到 2D 图像平面
        x = X_cam[:, 0, :]
        y = X_cam[:, 1, :]
        z = X_cam[:, 2, :].clamp(min=1e-6)

        u = (x / z) * fx + cx
        v = (y / z) * fy + cy

        projected_points = torch.stack([u.squeeze(), v.squeeze()], dim=2)

        # 计算损失
        loss = mse_loss(projected_points, img_points)

        # 反向传播和优化
        loss.backward()
        optimizer.step()

        if iter % 100 == 0 or iter == num_iters - 1:
            print(f"iter {iter}, Loss: {loss.item():.6f}")

    # 构建最终的内参矩阵 K
    K_final = torch.zeros((bs, 3, 3), device=device)
    K_final[:, 0, 0] = fx.squeeze()
    K_final[:, 1, 1] = fy.squeeze()
    K_final[:, 0, 2] = cx.squeeze()
    K_final[:, 1, 2] = cy.squeeze()
    K_final[:, 2, 2] = 1.0

    # 计算最终的旋转矩阵 R
    theta = torch.norm(rvec, dim=1, keepdim=True) + 1e-8
    rvec_normalized = rvec / theta
    theta = theta.unsqueeze(-1)
    cos_theta = torch.cos(theta)
    sin_theta = torch.sin(theta)
    one_minus_cos = 1 - cos_theta

    rx = rvec_normalized[:, 0].unsqueeze(-1)
    ry = rvec_normalized[:, 1].unsqueeze(-1)
    rz = rvec_normalized[:, 2].unsqueeze(-1)

    R_final = torch.zeros((bs, 3, 3), device=device)
    R_final[:, 0, 0] = cos_theta.squeeze() + rx.squeeze() * rx.squeeze() * one_minus_cos.squeeze()
    R_final[:, 0, 1] = rx.squeeze() * ry.squeeze() * one_minus_cos.squeeze() - rz.squeeze() * sin_theta.squeeze()
    R_final[:, 0, 2] = rx.squeeze() * rz.squeeze() * one_minus_cos.squeeze() + ry.squeeze() * sin_theta.squeeze()
    R_final[:, 1, 0] = ry.squeeze() * rx.squeeze() * one_minus_cos.squeeze() + rz.squeeze() * sin_theta.squeeze()
    R_final[:, 1, 1] = cos_theta.squeeze() + ry.squeeze() * ry.squeeze() * one_minus_cos.squeeze()
    R_final[:, 1, 2] = ry.squeeze() * rz.squeeze() * one_minus_cos.squeeze() - rx.squeeze() * sin_theta.squeeze()
    R_final[:, 2, 0] = rz.squeeze() * rx.squeeze() * one_minus_cos.squeeze() - ry.squeeze() * sin_theta.squeeze()
    R_final[:, 2, 1] = rz.squeeze() * ry.squeeze() * one_minus_cos.squeeze() + rx.squeeze() * sin_theta.squeeze()
    R_final[:, 2, 2] = cos_theta.squeeze() + rz.squeeze() * rz.squeeze() * one_minus_cos.squeeze()

    # 构建外参矩阵
    extrinsics_batch = torch.zeros((bs, 4, 4), device=device)
    extrinsics_batch[:, :3, :3] = R_final
    extrinsics_batch[:, :3, 3] = tvec
    extrinsics_batch[:, 3, 3] = 1.0

    return K_final, extrinsics_batch

if __name__ == "__main__":
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 参数设置
    bs = 10       # 批量大小
    N = 1000     # 每个批次的点数
    h = 480 // 4     # 图像高度
    w = 640 // 4     # 图像宽度

    # 生成示例的 3D 点云数据（随机生成）
    pointclouds = torch.randn(bs, N, 3, device=device) * 10  # 放大范围
    pointclouds[:, :, 2] += 50  # 确保 Z 轴为正值，避免除零

    # 假设真实的相机参数（用于生成示例数据）
    true_fx = w / 2.0
    true_fy = w / 2.0
    true_cx = w / 2.0
    true_cy = h / 2.0

    # 真实的旋转矩阵和平移向量
    true_rvec = torch.tensor([[0.1, 0.2, 0.3],
                              [-0.1, 0.1, 0.2]], device=device).repeat(bs // 2, 1)  # (bs, 3)
    true_tvec = torch.tensor([[0.5, -0.2, 1.0],
                              [-0.3, 0.4, 0.8]], device=device).repeat(bs // 2, 1)  # (bs, 3)

    # 构建真实的内参矩阵 K
    K_true = torch.zeros((bs, 3, 3), device=device)
    K_true[:, 0, 0] = true_fx
    K_true[:, 1, 1] = true_fy
    K_true[:, 0, 2] = true_cx
    K_true[:, 1, 2] = true_cy
    K_true[:, 2, 2] = 1.0

    # 计算真实的旋转矩阵 R（使用 Rodrigues 公式）
    def rodrigues_batch(rvec):
        theta = torch.norm(rvec, dim=1, keepdim=True)
        rvec_normalized = rvec / theta
        theta = theta.unsqueeze(-1)
        cos_theta = torch.cos(theta)
        sin_theta = torch.sin(theta)
        one_minus_cos = 1 - cos_theta

        rx = rvec_normalized[:, 0].unsqueeze(-1)
        ry = rvec_normalized[:, 1].unsqueeze(-1)
        rz = rvec_normalized[:, 2].unsqueeze(-1)

        R = torch.zeros((bs, 3, 3), device=device)
        R[:, 0, 0] = cos_theta.squeeze() + rx.squeeze() * rx.squeeze() * one_minus_cos.squeeze()
        R[:, 0, 1] = rx.squeeze() * ry.squeeze() * one_minus_cos.squeeze() - rz.squeeze() * sin_theta.squeeze()
        R[:, 0, 2] = rx.squeeze() * rz.squeeze() * one_minus_cos.squeeze() + ry.squeeze() * sin_theta.squeeze()
        R[:, 1, 0] = ry.squeeze() * rx.squeeze() * one_minus_cos.squeeze() + rz.squeeze() * sin_theta.squeeze()
        R[:, 1, 1] = cos_theta.squeeze() + ry.squeeze() * ry.squeeze() * one_minus_cos.squeeze()
        R[:, 1, 2] = ry.squeeze() * rz.squeeze() * one_minus_cos.squeeze() - rx.squeeze() * sin_theta.squeeze()
        R[:, 2, 0] = rz.squeeze() * rx.squeeze() * one_minus_cos.squeeze() - ry.squeeze() * sin_theta.squeeze()
        R[:, 2, 1] = rz.squeeze() * ry.squeeze() * one_minus_cos.squeeze() + rx.squeeze() * sin_theta.squeeze()
        R[:, 2, 2] = cos_theta.squeeze() + rz.squeeze() * rz.squeeze() * one_minus_cos.squeeze()

        return R

    R_true = rodrigues_batch(true_rvec)

    # 应用真实的外参变换
    X_cam = torch.bmm(pointclouds, R_true.transpose(1, 2)) + true_tvec.unsqueeze(1)

    # 投影到 2D 图像平面，生成对应的 img_points
    x = X_cam[:, :, 0]
    y = X_cam[:, :, 1]
    z = X_cam[:, :, 2].clamp(min=1e-6)

    u = (x / z) * true_fx + true_cx
    v = (y / z) * true_fy + true_cy

    intrinsics = torch.zeros((bs, 3, 3), device=device)
    intrinsics[:, 0, 0] = true_fx
    intrinsics[:, 1, 1] = true_fy
    intrinsics[:, 0, 2] = true_cx
    intrinsics[:, 1, 2] = true_cy

    img_points = torch.stack([u.squeeze(), v.squeeze()], dim=2)

    # 加入一些噪声（可选）
    img_points += torch.randn_like(img_points) * 0.2

    # 调用相机标定函数
    num_iters = 10000  # 优化迭代次数
    lr = 1e-2         # 学习率

    # K_estimated, extrinsics_estimated = calibrate_camera_pytorch(
    #     pointclouds, img_points, h, w, num_iters=num_iters, lr=lr
    # )
    R, t = calibrate_camera_pnpransac(pointclouds, img_points, intrinsics)
    extrinsics_estimated = torch.zeros((bs, 4, 4), device=device)
    print(R.shape, t.shape)
    extrinsics_estimated[:, :3, :3] = R
    extrinsics_estimated[:, :3, 3:] = t


    # 打印估计的相机内参和外参
    for b in range(bs):
        print(f"\n批次 {b}:")
        print("估计的相机内参矩阵 K：")
        print(intrinsics[b].cpu().detach().numpy())
        print("真实的相机内参矩阵 K：")
        print(K_true[b].cpu().detach().numpy())

        print("\n估计的相机外参矩阵 Extrinsic：")
        print(extrinsics_estimated[b].cpu().detach().numpy())
        print("真实的相机外参矩阵 Extrinsic：")
        extrinsic_true = torch.eye(4)
        extrinsic_true[:3, :3] = R_true[b]
        extrinsic_true[:3, 3] = true_tvec[b]
        print(extrinsic_true.cpu().detach().numpy())
