import torch
import numpy as np
import cv2

import torch
import numpy as np
import cv2

def calibrate_camera_pytorch(pointclouds, img_points, h, w, num_iters=1000, lr=1e-3):
    """
    使用 PyTorch 在 GPU 上进行相机标定。

    参数：
        pointclouds: (bs, N, 3) 的张量，3D 点云。
        img_points: (bs, N, 2) 的张量，对应的 2D 图像点。
        h, w: 图像高度和宽度。
        num_iters: 优化迭代次数。
        lr: 学习率。

    返回：
        K_batch: (bs, 3, 3) 的相机内参矩阵。
        extrinsics_batch: (bs, 4, 4) 的相机外参矩阵。
    """
    device = pointclouds.device
    bs, N, _ = pointclouds.shape

    # 初始化内参参数
    fx = torch.full((bs, 1), w / 2.0, device=device, requires_grad=True)
    fy = torch.full((bs, 1), w / 2.0, device=device, requires_grad=True)
    cx = torch.full((bs, 1), w / 2.0, device=device, requires_grad=True)
    cy = torch.full((bs, 1), h / 2.0, device=device, requires_grad=True)

    # 初始化外参参数
    rvec = torch.zeros((bs, 3), device=device, requires_grad=True)
    tvec = torch.zeros((bs, 3), device=device, requires_grad=True)

    # 优化器
    optimizer = optim.Adam([fx, fy, cx, cy, rvec, tvec], lr=lr)

    # 损失函数
    mse_loss = nn.MSELoss()

    for iter in range(num_iters):
        optimizer.zero_grad()

        # 构建内参矩阵 K
        K = torch.zeros((bs, 3, 3), device=device)
        K[:, 0, 0] = fx.squeeze()
        K[:, 1, 1] = fy.squeeze()
        K[:, 0, 2] = cx.squeeze()
        K[:, 1, 2] = cy.squeeze()
        K[:, 2, 2] = 1.0

        # 计算旋转矩阵 R（使用 Rodrigues 公式）
        theta = torch.norm(rvec, dim=1, keepdim=True) + 1e-8
        rvec_normalized = rvec / theta
        theta = theta.unsqueeze(-1)
        cos_theta = torch.cos(theta)
        sin_theta = torch.sin(theta)
        one_minus_cos = 1 - cos_theta

        rx, ry, rz = rvec_normalized[:, 0], rvec_normalized[:, 1], rvec_normalized[:, 2]
        R = torch.stack([
            cos_theta + rx*rx*one_minus_cos,
            rx*ry*one_minus_cos - rz*sin_theta,
            rx*rz*one_minus_cos + ry*sin_theta,

            ry*rx*one_minus_cos + rz*sin_theta,
            cos_theta + ry*ry*one_minus_cos,
            ry*rz*one_minus_cos - rx*sin_theta,

            rz*rx*one_minus_cos - ry*sin_theta,
            rz*ry*one_minus_cos + rx*sin_theta,
            cos_theta + rz*rz*one_minus_cos
        ], dim=-1).reshape(bs, 3, 3)

        # 应用外参变换
        X_cam = torch.bmm(R, pointclouds.transpose(1, 2)) + tvec.unsqueeze(-1)
        X_cam = X_cam.transpose(1, 2)

        # 投影到 2D 图像平面
        x = X_cam[:, :, 0]
        y = X_cam[:, :, 1]
        z = X_cam[:, :, 2].clamp(min=1e-6)

        u = (x / z) * fx + cx
        v = (y / z) * fy + cy

        projected_points = torch.stack([u, v], dim=2)

        # 计算损失
        loss = mse_loss(projected_points, img_points)

        # 反向传播和优化
        loss.backward()
        optimizer.step()

        if iter % 100 == 0:
            print(f"迭代 {iter}，损失：{loss.item()}")

    # 构建最终的内参矩阵 K
    K_final = torch.zeros((bs, 3, 3), device=device)
    K_final[:, 0, 0] = fx.squeeze()
    K_final[:, 1, 1] = fy.squeeze()
    K_final[:, 0, 2] = cx.squeeze()
    K_final[:, 1, 2] = cy.squeeze()
    K_final[:, 2, 2] = 1.0

    # 计算最终的旋转矩阵 R
    theta = torch.norm(rvec, dim=1, keepdim=True) + 1e-8
    rvec_normalized = rvec / theta
    theta = theta.unsqueeze(-1)
    cos_theta = torch.cos(theta)
    sin_theta = torch.sin(theta)
    one_minus_cos = 1 - cos_theta

    rx, ry, rz = rvec_normalized[:, 0], rvec_normalized[:, 1], rvec_normalized[:, 2]
    R_final = torch.stack([
        cos_theta + rx*rx*one_minus_cos,
        rx*ry*one_minus_cos - rz*sin_theta,
        rx*rz*one_minus_cos + ry*sin_theta,

        ry*rx*one_minus_cos + rz*sin_theta,
        cos_theta + ry*ry*one_minus_cos,
        ry*rz*one_minus_cos - rx*sin_theta,

        rz*rx*one_minus_cos - ry*sin_theta,
        rz*ry*one_minus_cos + rx*sin_theta,
        cos_theta + rz*rz*one_minus_cos
    ], dim=-1).reshape(bs, 3, 3)

    # 构建外参矩阵
    extrinsics_batch = torch.zeros((bs, 4, 4), device=device)
    extrinsics_batch[:, :3, :3] = R_final
    extrinsics_batch[:, :3, 3] = tvec
    extrinsics_batch[:, 3, 3] = 1.0

    return K_final, extrinsics_batch

def calibrate_pinhole_camera_from_pointcloud(pointclouds, h, w):
    """
    从点云数据计算针孔相机的内参和外参，假设没有畸变。
    """
    bs, N, _ = pointclouds.shape
    device = pointclouds.device

    # 确保点数匹配
    assert N == h * w, "点云中的点数必须等于 h * w"

    K_batch = []
    extrinsics_batch = []
    tt = [time.time()]
    for b in range(bs):
        tt.append(time.time())
        print(b, tt[-1] - tt[-2])
        # 获取当前批次的点云
        pcd = pointclouds[b]  # (N, 3)

        # 将点云转换为 numpy 数组
        obj_points = pcd.cpu().numpy().astype(np.float32)

        # 生成对应的二维图像坐标 (u, v)
        u_coords = np.tile(np.arange(w), h)
        v_coords = np.repeat(np.arange(h), w)
        img_points = np.stack((u_coords, v_coords), axis=1).astype(np.float32)

        # 准备标定数据列表
        obj_points_list = [obj_points]
        img_points_list = [img_points]

        # 设置标定标志
        flags = (cv2.CALIB_USE_INTRINSIC_GUESS |
                 cv2.CALIB_FIX_PRINCIPAL_POINT |
                 cv2.CALIB_FIX_ASPECT_RATIO |
                 cv2.CALIB_ZERO_TANGENT_DIST |
                 cv2.CALIB_FIX_K1 |
                 cv2.CALIB_FIX_K2 |
                 cv2.CALIB_FIX_K3 |
                 cv2.CALIB_FIX_K4 |
                 cv2.CALIB_FIX_K5 |
                 cv2.CALIB_FIX_K6)

        # 初始内参矩阵，假设焦距为图像宽度的一半，主点在图像中心
        f_init = w / 2.0
        K_init = np.array([[f_init, 0, w / 2],
                           [0, f_init, h / 2],
                           [0,      0,     1]], dtype=np.float64)

        # 将畸变系数设为零
        distCoeffs = np.zeros((4, 1))  # 或者使用 (5, 1) 取决于畸变系数的数量

        # 调用 calibrateCamera
        ret, K, dist_coeffs, rvecs, tvecs = cv2.calibrateCamera(
            obj_points_list,
            img_points_list,
            (w, h),
            K_init,
            distCoeffs,
            flags=flags
        )

        if not ret:
            print(f"批次 {b} 的相机标定失败。")
            # 使用初始内参和单位外参
            K_batch.append(torch.from_numpy(K_init).float())
            extrinsic = torch.eye(4)
            extrinsics_batch.append(extrinsic)
            continue

        # 将结果转换为 PyTorch 张量
        K_tensor = torch.from_numpy(K).float()
        K_batch.append(K_tensor)

        # 计算外参矩阵
        R, _ = cv2.Rodrigues(rvecs[0])
        t = tvecs[0]

        extrinsic = np.eye(4)
        extrinsic[:3, :3] = R
        extrinsic[:3, 3] = t.flatten()

        extrinsic_tensor = torch.from_numpy(extrinsic).float()
        extrinsics_batch.append(extrinsic_tensor)

    # 堆叠批量结果
    K_batch = torch.stack(K_batch).to(device)  # (bs, 3, 3)
    extrinsics_batch = torch.stack(extrinsics_batch).to(device)  # (bs, 4, 4)

    return K_batch, extrinsics_batch


# 示例使用
if __name__ == "__main__":
    import time
    # 假设有一个批量的点云数据，形状为 (bs, N, 3)
    bs = 100
    h = 50
    w = 50
    N = h * w

    # 生成示例点云数据（这里使用一个简单的平面作为示例）
    xx, yy = torch.meshgrid(torch.linspace(0, w - 1, w),
                            torch.linspace(0, h - 1, h))
    xx = xx.t().reshape(-1)  # (N,)
    yy = yy.t().reshape(-1)  # (N,)
    zz = torch.abs(torch.randn_like(xx)) * 1000  # 假设深度为1000毫米

    pcd_sample = torch.stack((xx, yy, zz), dim=1)  # (N, 3)
    
    # 将样本复制 bs 次，形成批量数据
    pointclouds = torch.stack([pcd_sample for _ in range(bs)], dim=0)  # (bs, N, 3)

    # 将数据移动到 GPU（如果可用）
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    pointclouds = pointclouds.to(device)

    # 调用函数
    t = time.time()
    K_batch, extrinsics_batch = calibrate_pinhole_camera_from_pointcloud(pointclouds, h, w)
    print('t', time.time() - t)
    # 打印结果
    for b in range(bs):
        print(f"批次 {b} 的相机内参矩阵 K：\n", K_batch[b])
        print(f"批次 {b} 的相机外参矩阵 Extrinsic：\n", extrinsics_batch[b])
