import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from dust3r.gs import GaussianRenderer
gs_renderer = GaussianRenderer()
gs_renderer.set_view_info(height = 400, width = 400)
import torch
import imageio
from torch import nn
intrinsics = torch.Tensor([
    [1000, 0, 200],
    [0, 1000, 200],
    [0, 0, 1],
]).cuda()[None]
c2ws_gs = torch.eye(4).cuda()[None]
pts3d_gs = torch.randn(10000, 3).cuda() * 0.1 + torch.Tensor([0,0,2.]).cuda().float()

class GS(nn.Module):

    def __init__(self):
        super().__init__()
        self.rgb_gs = torch.zeros(10000, 12).cuda()
        self.rgb_gs = nn.Parameter(self.rgb_gs)

gs = GS()
optim = torch.optim.Adam(gs.parameters(), lr=0.01)
rot = torch.ones(10000, 4).cuda()
tgt = torch.Tensor([1., -1, -1]).float().cuda()
for i in range(10000):
    c = torch.linalg.inv(c2ws_gs)
    o = torch.ones_like(gs.rgb_gs[:,0]) * 0.5
    s = torch.ones_like(pts3d_gs) * 0.001
    res = gs_renderer(c, intrinsics, pts3d_gs, gs.rgb_gs, o, s, rot, eps2d=0.1, debug = (i >= 10000))
    rgb_copy = gs_renderer.calc_color_from_sh(pts3d_gs[None], c2ws_gs, gs.rgb_gs.reshape(-1, 4, 3)[None], 1, debug = (i >= 98000))[0] # # def calc_color_from_sh(self, pcds, c2ws, sh, sh_degree): # pcds: [nv, N, 3], c2ws: [nv, 4, 4], sh: [nv, N, K, 3] -> colors: [nv, N, 3] -1~1
    rgb = res['rgb'][0]
    imageio.imwrite(f"/home/zgtang/test/{i}.png", (((rgb.detach().cpu() + 1) / 2)))
    loss = torch.square(tgt - rgb).mean()
    optim.zero_grad()
    loss.backward()
    optim.step()
    print(i, loss, rgb_copy.mean(0))





# def f(a,b,c,d,**kw):
#     print(a,b,c,d,kw)

# def g(a,b,c,d,**kw):
#     return f(a,b,c,d,**kw)


# print(g(1,2,3,4,log=5))

aha = 3
def f():
    print(aha)

f()
exit()

import numpy as np
import time
import json
import h5py

if 1:

    t = time.time()
    # ff = [h5py.File('/home/zgtang/scannet_large_easier_12/dps.h5', 'r', lazy_load = False) for i in range(100)]
    f = h5py.File('/home/zgtang/scannet_large_easier_12/dps.h5', 'r')['json_strs']
    print('loading', time.time()-t, len(f))
    
    for i in range(0, len(f), 10000):
        t = time.time()
        d = json.loads(f[i])
        print(d)
        print(i, time.time()-t)

    while 1:
        pass


if 0:
    t = time.time()
    
    data = [np.load('/home/zgtang/scannet_large_easier_12/dps.npz', mmap_mode='r') for i in range(10)]
    print('loading', time.time()-t)
    for i in range(0, len(data[0]), 20000):
        t = time.time()
        d = data[0][f'{i}']
        print(d)
        print(i, time.time()-t)

    
    while 1:
        pass


if 0:
    print('a')
    t = time.time()
    data = [np.load('/home/zgtang/temp.npy', mmap_mode='r') for i in range(10)]
    print('loading', time.time()-t)
    while 1:
        pass

    for i in range(0, 1000000, 10000):
        t = time.time()
        print(data[i])
        print(i, time.time()-t)

if 0:
    def random():
        return np.random.randint(10, 20)

    x = ["a" * random() + "o" * random() + "d" * random() for i in range(10000000)]

    np.save("/home/zgtang/temp.npy", x)
