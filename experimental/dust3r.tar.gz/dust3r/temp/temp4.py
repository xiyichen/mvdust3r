import imageio
import numpy as np

# 假设您有一个包含图像数据的NumPy数组，数据类型为uint16
# 这里创建一个示例16位灰度图像
height, width = 512, 512
img = np.random.randint(0, 65536, size=(height, width), dtype=np.uint16)

# 使用imageio保存16位PNG图像
imageio.imwrite('output_16bit.png', img, format='png')
