#!/bin/bash

n_job=8
n_v=5
n_render=1
data_type=scannetpp
hardness=hard

for ((i=0; i<n_job; i++))
do
  echo $((8 * n_job)) $i
  torchx run -s mast -- -h zionex -j 1x8 -m datasets_preprocess/preproc_scannet2.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness
done
#   torchx run -s mast -- -h zionex -j 1x8 -m datasets_preprocess/preproc_scannet_render.py -- --div 64 --node-no $i


# for i in {0..15}
# do
#   torchx run -s mast -- -h zionex -j 1x8 -m datasets_preprocess/preproc_scannet.py -- --div 128 --node-no $i
# done


# for i in {0..3}
# do
#   torchx run -s mast -- -h zionex -j 1x8 -m datasets_preprocess/preproc_scannetpp.py -- --div 32 --node-no $i
# done
