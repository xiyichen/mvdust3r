## install the python env

with-proxy conda create -n p3d python=3.9
conda activate p3d
with-proxy pip install -r requirements_data.txt

## install the habitat-sim

 8459  with-proxy conda create -n habitat python=3.8 habitat-sim=0.2.1 headless=2.0 -c aihabitat -c conda-forge
 8460  conda activate habitat
 8461  with-proxy conda install pytorch -c pytorch
 8462  with-proxy pip install opencv-python tqdm

## copy pairs to local

manifold --prod-use-cython-client getr --threads 2 --jobs 1000 ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large /home/zgtang/scannet_large
manifold --prod-use-cython-client getr --threads 2 --jobs 1000 ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy /home/zgtang/scannet_large_easy
manifold --prod-use-cython-client getr --threads 2 --jobs 1000 ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_12 /home/zgtang/scannet_large_12
manifold --prod-use-cython-client getr --threads 2 --jobs 1000 ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_12 /home/zgtang/scannet_large_easy_12
manifold --prod-use-cython-client getr --threads 2 --jobs 1000 ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_12 /home/zgtang/scannet_large_easier_12

manifold --prod-use-cython-client getr --threads 2 --jobs 1000 ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_16 /home/zgtang/scannet_large_easy_16
manifold --prod-use-cython-client getr --threads 2 --jobs 1000 ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_16 /home/zgtang/scannet_large_easier_16

manifold --prod-use-cython-client getr --threads 2 --jobs 1000 ondevice_ai_writedata/tree/zgtang/dust3r/data/scannetpp_large_easier_16 /home/zgtang/scannetpp_large_easier_16
manifold --prod-use-cython-client getr --threads 2 --jobs 1000 ondevice_ai_writedata/tree/zgtang/dust3r/data/scannetpp_large_easy_16 /home/zgtang/scannetpp_large_easy_16
manifold --prod-use-cython-client getr --threads 2 --jobs 1000 ondevice_ai_writedata/tree/zgtang/dust3r/data/scannetpp_large_hard_4 /home/zgtang/scannetpp_large_hard_4

## get dps.json

python datasets_preprocess/get_scannet_list.py --data-name scannet_large_easier_12
python datasets_preprocess/get_scannet_list.py --data-name scannet_large_easy_12

python datasets_preprocess/get_scannet_list.py --data-name scannetpp_large_easier_16
python datasets_preprocess/get_scannet_list.py --data-name scannetpp_large_easy_16
python datasets_preprocess/get_scannet_list.py --data-name scannetpp_large_hard_4

python datasets_preprocess/get_scannet_list.py --data-name hs_meta

## visualize the Data

torchx run -- -j 1x1 -m datasets_preprocess/vis_dps.py -- --data-name scannet_large_easy_12
torchx run -- -j 1x1 -m datasets_preprocess/vis_dps.py -- --data-name scannet_large_easier_12

torchx run -- -j 1x1 -m datasets_preprocess/vis_dps.py -- --data-name scannetpp_large_easier_16 --n-render 4

torchx run -- -j 1x1 -m datasets_preprocess/vis_dps.py -- --data-name hs_meta

## copy back the dps.json to manifold

manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/scannet_large_easy_12/dps.json ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_12/dps.json
manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/scannet_large_easy_12/dps.h5   ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_12/dps.h5
manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/scannet_large_easier_12/dps.json ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_12/dps.json
manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/scannet_large_easier_12/dps.h5   ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_12/dps.h5


manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/scannet_large_easy_16/dps.json ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_16/dps.json
manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/scannet_large_easy_16/dps.h5   ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_16/dps.h5
manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/scannet_large_easier_16/dps.json ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_16/dps.json
manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/scannet_large_easier_16/dps.h5   ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_16/dps.h5

manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/scannetpp_large_hard_5/dps.h5   ondevice_ai_writedata/tree/zgtang/dust3r/data/scannetpp_large_hard_5/dps.h5

manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/scannetpp_large_easy_16/dps.h5   ondevice_ai_writedata/tree/zgtang/dust3r/data/scannetpp_large_easy_16/dps.h5

manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/scannetpp_large_easier_16/dps.h5   ondevice_ai_writedata/tree/zgtang/dust3r/data/scannetpp_large_easier_16/dps.h5

manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/data_gen/croco/hs_meta/dps.h5   ondevice_ai_writedata/tree/zgtang/dust3r/data/hs/dps.h5
manifold --prod-use-cython-client put --threads 50 --overwrite /home/zgtang/hs_meta/dps.json   ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_large/dps.json


manifold --prod-use-cython-client get --threads 50 ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_12/dps.json /home/zgtang/dps_easy.json
