#!/usr/bin/env python3
# Copyright (C) 2024-present Naver Corporation. All rights reserved.
# Licensed under CC BY-NC-SA 4.0 (non-commercial use only).
#
# --------------------------------------------------------
# training code for DUSt3R
# --------------------------------------------------------
# References:
# MAE: https://github.com/facebookresearch/mae
# DeiT: https://github.com/facebookresearch/deit
# BEiT: https://github.com/microsoft/unilm/tree/master/beit
# --------------------------------------------------------
import argparse
import datetime
import json
import numpy as np
import os
import sys
import time
import math
from collections import defaultdict
from pathlib import Path
from typing import Sized
import imageio


import torch
import torch.backends.cudnn as cudnn
from torch.utils.tensorboard import SummaryWriter
torch.backends.cuda.matmul.allow_tf32 = True  # for gpu >= Ampere and pytorch >= 1.12
import torch.manifold.patch

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from iopath.common.file_io import g_pathmgr
from datasets_preprocess.html_gen.run_model_doctor import generate_html
from on_device_ai.cvg.pipix.mini.distributed import get_local_path, set_device
from on_device_ai.cvg.pipix.mini.logging import get_log_dir

from dust3r.model import AsymmetricCroCo3DStereo, AsymmetricCroCo3DStereoMultiView, inf 
import dust3r.utils.path_to_croco  # noqa: F401
from dust3r.datasets import get_data_loader  # noqa
from dust3r.losses import *  # noqa: F401, needed when loading the model
from dust3r.inference import loss_of_one_batch # noqa
from inference_global_optimization import loss_of_one_batch_go_mv  # noqa
from dust3r.pcd_render import pcd_render, save_image_manifold, save_video_combined
from dust3r.gs import gs_render
from dust3r.utils.geometry import inv, geotrf

import dust3r.utils.path_to_croco  # noqa: F401
import croco.utils.misc as misc  # noqa
from croco.utils.misc import NativeScalerWithGradNormCount as NativeScaler  # noqa

def get_args_parser():
    parser = argparse.ArgumentParser('DUST3R training', add_help=False)
    # model and criterion
    parser.add_argument('--model', default="AsymmetricCroCo3DStereo(patch_embed_cls='ManyAR_PatchEmbed')",
                        type=str, help="string containing the model to build")
    parser.add_argument('--pretrained', default=None, help='path of a starting checkpoint')
    parser.add_argument('--train_criterion', default="ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)",
                        type=str, help="train criterion")
    parser.add_argument('--test_criterion', default=None, type=str, help="test criterion")

    # dataset
    parser.add_argument('--train_dataset', required=True, type=str, help="training set")
    parser.add_argument('--test_dataset', default='[None]', type=str, help="testing set")

    # training
    parser.add_argument('--seed', default=0, type=int, help="Random seed")
    parser.add_argument('--batch_size', default=64, type=int,
                        help="Batch size per GPU (effective batch size is batch_size * accum_iter * # gpus")
    parser.add_argument('--accum_iter', default=1, type=int,
                        help="Accumulate gradient iterations (for increasing the effective batch size under memory constraints)")
    parser.add_argument('--epochs', default=800, type=int, help="Maximum number of epochs for the scheduler")

    parser.add_argument('--weight_decay', type=float, default=0.05, help="weight decay (default: 0.05)")
    parser.add_argument('--lr', type=float, default=None, metavar='LR', help='learning rate (absolute lr)')
    parser.add_argument('--blr', type=float, default=1.5e-4, metavar='LR',
                        help='base learning rate: absolute_lr = base_lr * total_batch_size / 256')
    parser.add_argument('--min_lr', type=float, default=0., metavar='LR',
                        help='lower lr bound for cyclic schedulers that hit 0')
    parser.add_argument('--warmup_epochs', type=int, default=40, metavar='N', help='epochs to warmup LR')

    parser.add_argument('--amp', type=int, default=0,
                        choices=[0, 1], help="Use Automatic Mixed Precision for pretraining")

    # others
    parser.add_argument('--num_workers', default=8, type=int)
    parser.add_argument('--world_size', default=1, type=int, help='number of distributed processes')
    parser.add_argument('--local_rank', default=-1, type=int)
    parser.add_argument('--dist_url', default='env://', help='url used to set up distributed training')

    parser.add_argument('--eval_freq', type=int, default=1, help='Test loss evaluation frequency')
    parser.add_argument('--save_freq', default=1, type=int,
                        help='frequence (number of epochs) to save checkpoint in checkpoint-last.pth')
    parser.add_argument('--keep_freq', default=20, type=int,
                        help='frequence (number of epochs) to save checkpoint in checkpoint-%d.pth')
    parser.add_argument('--print_freq', default=20, type=int,
                        help='frequence (number of iterations) to print infos while training')

    # output dir
    parser.add_argument('--output_dir', default=None, type=str, help="path where to save the output")
    return parser


def main(args):
    print('args', args)
    misc.init_distributed_mode(args)
    global_rank = misc.get_rank()
    world_size = misc.get_world_size()
    real_batch_size = args.batch_size * world_size
    print('world size', world_size, 'global_rank', global_rank, 'real_batch_size', real_batch_size)
    set_device(args.gpu)

    args.output_dir = get_log_dir(
        manifold_bucket="ondevice_ai_writedata",
        manifold_dir="zgtang/dust3r/logs",
        resume_from=args.output_dir,
    )
    print("output_dir: "+args.output_dir) # manifold://ondevice_ai_writedata/tree/zgtang/dust3r/logs/torchx-dust3r_train-temp3
    if args.output_dir:
        g_pathmgr.mkdirs(args.output_dir)

    # auto resume
    last_ckpt_fname = os.path.join(args.output_dir, f'checkpoint-last.pth')
    args.resume = last_ckpt_fname if g_pathmgr.isfile(last_ckpt_fname) else None

    print('job dir: {}'.format(os.path.dirname(os.path.realpath(__file__))))
    print("{}".format(args).replace(', ', ',\n'))

    device = "cuda" if torch.cuda.is_available() else "cpu"
    device = torch.device(device)

    # fix the seed
    seed = args.seed + misc.get_rank()
    torch.manual_seed(seed)
    np.random.seed(seed)

    cudnn.benchmark = True

    # training dataset and loader
    print('Building train dataset {:s}'.format(args.train_dataset))
    #  dataset and loader
    # data_loader_train = build_dataset(args.train_dataset, args.batch_size, args.num_workers, test=False)
    # train_epoch_size = real_batch_size * len(data_loader_train)
    train_epoch_size = real_batch_size * 100000
    print('Building test dataset {:s}'.format(args.test_dataset))
    data_loader_test = {}
    for dataset_name in args.test_dataset.split('+'):
        dataset = build_dataset(dataset_name, args.batch_size, args.num_workers, test=True)
        dataset_name = dataset.dataset.tb_name
        data_loader_test[dataset_name] = dataset

    # data_loader_test = {dataset.split('(')[0]: build_dataset(dataset, args.batch_size, args.num_workers, test=True)
    #                     for dataset in args.test_dataset.split('+')}


    print(f'>> Creating train criterion = {args.train_criterion}')
    train_criterion = eval(args.train_criterion).to(device) # ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)
    print(f'>> Creating test criterion = {args.test_criterion or args.train_criterion}')
    test_criterion = eval(args.test_criterion or args.criterion).to(device)


    eff_batch_size = args.batch_size * args.accum_iter * misc.get_world_size()
    if args.lr is None:  # only base_lr is specified
        args.lr = args.blr * eff_batch_size / 256
    print("base lr: %.2e" % (args.lr * 256 / eff_batch_size))
    print("actual lr: %.2e" % args.lr)
    print("accumulate grad iterations: %d" % args.accum_iter)
    print("effective batch size: %d" % eff_batch_size)


    if global_rank == 0 and args.output_dir is not None:
        log_writer = SummaryWriter(log_dir=args.output_dir)
    else:
        log_writer = None

    print(f"Start training for {args.epochs} epochs")
    start_time = time.time()
    train_stats = test_stats = {}
    epoch = 0
    test_stats = {}
    test_set_id = -1
    for test_name, testset in data_loader_test.items():
        test_set_id += 1
        t_test = time.time()
        print('test name', test_name)
        stats = test_one_epoch(None, None, testset,
                                device, epoch, train_epoch_size, log_writer=log_writer, args=args, prefix=test_name, test_set_id = test_set_id)



def build_dataset(dataset, batch_size, num_workers, test=False):
    split = ['Train', 'Test'][test]
    print(f'Building {split} Data loader for dataset: ', dataset)
    loader = get_data_loader(dataset,
                             batch_size=batch_size,
                             num_workers=num_workers,
                             pin_mem=True,
                             shuffle=not (test),
                             drop_last=not (test))

    print(f"{split} dataset length: ", len(loader))
    return loader


def test_one_epoch(model: torch.nn.Module, criterion: torch.nn.Module,
                   data_loader: Sized, device: torch.device, epoch: int,
                   train_epoch_size, args, log_writer=None, prefix='test', test_set_id = 0):
    t_begin1 = -time.time()
    metric_logger = misc.MetricLogger(delimiter="  ")
    metric_logger.meters = defaultdict(lambda: misc.SmoothedValue(window_size=9**9))
    header = 'Test Epoch: [{}]'.format(epoch)

    if log_writer is not None:
        print('log_dir: {}'.format(log_writer.log_dir))
    t_begin1 += time.time()
    t_begin2 = -time.time()
    if hasattr(data_loader, 'dataset') and hasattr(data_loader.dataset, 'set_epoch'):
        print('set in dataset')
        data_loader.dataset.set_epoch(epoch)
    if hasattr(data_loader, 'sampler') and hasattr(data_loader.sampler, 'set_epoch'):
        print('set in sampler')
        data_loader.sampler.set_epoch(epoch)
    t_begin2 += time.time()
    
    os.makedirs(f"/home/zgtang/data_local/{prefix}/", exist_ok = True)
    for batch_id, batch in enumerate(metric_logger.log_every(data_loader, args.print_freq, header)):
        torch.save(batch, f"/home/zgtang/data_local/{prefix}/{batch_id}.pth")

    

if __name__ == '__main__':
    args = get_args_parser()
    args = args.parse_args()
    main(args)
