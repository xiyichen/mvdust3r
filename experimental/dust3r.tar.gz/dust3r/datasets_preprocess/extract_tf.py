import argparse
import os, sys
from copy import deepcopy
import csv

parser = argparse.ArgumentParser()
# parser.add_argument("--node-no", default=0, type=int)
args = parser.parse_args()


import glob, sys
import json

import sys

import cv2
import h5py
import imageio
import numpy as np


import PIL
import torch

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__))))

try:
    import fbvscode
    import torch.manifold.patch
    from iopath.common.file_io import PathManager
    from iopath.fb.manifold import ManifoldPathHandler

    pathmgr = PathManager()
    pathmgr.register_handler(ManifoldPathHandler())
except:
    
    import tensorflow as tf



'''
\multirow{6}{*}{\rotatebox[origin=c]{90}{4 views}} & PoseDiffusion & x\\
& Spann3R & \\
& \dst~w/ GA & 0.20 & 0.75 & 0.06 & 0.89 & 0.98 & 0.79 & 15.99 & 0.50 & 0.37 & 2.42\\
& Ours (MV-\dst) & 0.15 & 0.92 & 0.02 & 0.98 & 0.99 & 0.95 & 19.92 & 0.60 & 0.20 & 0.05\\
& Ours (MV-\dst++) & 0.13 & 0.95 & 0.02 & 0.99 & 0.99 & 0.95 & 20.22 & 0.61 & 0.19 & 0.28\\\cline{2-12}
& {\color{lightgray}Ours (MV-\dst~oracle)} & 0.14 & 0.95 & 0.02 & 1.00 & 1.00 & 0.97 & 21.05 & 0.65 & 0.16\\\midrule 
'''

GO_time = [2.42,4.49,8.28,13.07,19.59,27.21]
MV_dst_time = [0.05383, 0.10302, 0.1525, 0.217028, 0.288316, 0.3548145]
dst2_time = [0.287772, 0.5603833, 0.887719, 1.1966371536, 1.54, 1.96590]
# hs_tdf_2_testFull_25_5
# sc_1_15_3
# mp3d_tdf_2_testFull_30_6
# logname_list = ["GO_zionex_test_new3", "MV_dust3r_fs_load_nref4_last_new3", "dust3r2_nref4_load_50_new4", "MV_dust3r_fs_load_nref4_last_new3_best"]
logname_list = ['GO_zionex_test_all4', 'MV_dust3r_fs_test_all4', 'dust3r2_nref4_test_all4', 'MV_dust3r_fs_test_all4_best', 'dust3r2_nref4_test_all4_best']
logname_latex_list = [r"\dustthreer & \checkmark", r"\mvdustthreer & $\times$", r"\mvdustthreerp & $\times$", r" {\color{lightgray}$\text{\mvdustthreer}_\text{oracle}$} & $\times$ ", r" {\color{lightgray}$\text{\mvdustthreerp}_\text{oracle}$} & $\times$ "]
post_str_latex_list = [r"\\", r"\\", r"\\\cline{2-12}", r"\\", r"\\\midrule "]

view_range = [1, 2,3,4,5, 6]

hs_pre_list = [f"hs_tdf_2_testFull_{i * 5}_{i}" for i in view_range]
sc_pre_list = [f"sc_1_{i * 5}_{i}" for i in view_range]
mp3d_pre_list = [f"mp3d_tdf_2_testFull_{i * 5}_{i}" for i in view_range]

pre_list = [hs_pre_list, sc_pre_list, mp3d_pre_list]



# logname_list = ['dust3r2_nref4_test_4view2', 'dust3r2_nref4_test_ft2', 'MV_dust3r_fs_test_no_rgb2', 'dust3r2_nref4_test_no_rgb2', 'MV_dust3r_fs_test_all4', 'dust3r2_nref4_test_all4']
# logname_latex_list = [r"MV+ 4view", r"MV+ 8view, ft on 4 to 12 view", r"MV no 3DGS", r"MV+ no 3DGS", r"MV (baseline)", r"MV+ (baseline)"]
# post_str_latex_list = [r"\\", r"\\", r"\\\cline{2-12}", r"\\",r"\\",r"\\", r"\\\midrule "]

# # hs_pre_list = [f"hs_tdf_2_testFull_{i * 5}_{i}" for i in range(4,4 + 1)]

# view_range = [1,2, 3,4,5, 6]

# hs_pre_list = [f"hs_tdf_2_testFull_{i * 5}_{i}" for i in view_range]
# sc_pre_list = [f"sc_1_{i * 5}_{i}" for i in view_range]
# mp3d_pre_list = [f"mp3d_tdf_2_testFull_{i * 5}_{i}" for i in view_range]

# pre_list = [hs_pre_list, sc_pre_list, mp3d_pre_list]


# logname_list = ['dust3r2_nref4_test_4view2', 'dust3r2_nref4_test_ft2', 'MV_dust3r_fs_test_no_rgb2', 'dust3r2_nref4_test_no_rgb2', 'MV_dust3r_fs_test_all4', 'dust3r2_nref4_test_all4']
# logname_latex_list = [r"MV+ 4view", r"MV+ 8view, ft on 4 to 12 view", r"MV no 3DGS", r"MV+ no 3DGS", r"MV (baseline)", r"MV+ (baseline)"]
# post_str_latex_list = [r"\\", r"\\", r"\\\cline{2-12}", r"\\",r"\\",r"\\", r"\\\midrule "]

# # hs_pre_list = [f"hs_tdf_2_testFull_{i * 5}_{i}" for i in range(4,4 + 1)]

# view_range = [1, 3, 6]

# hs_pre_list = [f"hs_tdf_2_testFull_{i * 5}_{i}" for i in view_range]
# sc_pre_list = [f"sc_1_{i * 5}_{i}" for i in view_range]
# mp3d_pre_list = [f"mp3d_tdf_2_testFull_{i * 5}_{i}" for i in view_range]

# pre_list = [hs_pre_list, sc_pre_list, mp3d_pre_list]


logname_list = ['dust3r2_nref4_test_all4', 'dust3r2_nref4_test_ft3']
logname_latex_list = [r"MV+ 8view", r"MV+ 8view, ft on 4 to 12 view"]
post_str_latex_list = [r"\\", r"\\\midrule ", r"\\\cline{2-12}", r"\\",r"\\",r"\\", r"\\\midrule "]

# hs_pre_list = [f"hs_tdf_2_testFull_{i * 5}_{i}" for i in range(4,4 + 1)]

view_range = [1, 2, 3,4,5, 6]

hs_pre_list = [f"hs_tdf_2_testFull_{i * 5}_{i}" for i in view_range]
sc_pre_list = [f"sc_1_{i * 5}_{i}" for i in view_range]
mp3d_pre_list = [f"mp3d_tdf_2_testFull_{i * 5}_{i}" for i in view_range]

pre_list = [hs_pre_list, sc_pre_list, mp3d_pre_list]

round_list = [1, 1, 1, 1, 1, 1, 1, 1, 1]
metricsName_list = ["MSE", "mseAccu@0.2", "chamferDis", "RRA15", "RTA15", "mAA30", "PSNR", "SSIM", "LPIPS"]
# "Regr3D_ScaleShiftAllInv_pts3d_rotInv_first_avg",
# "Regr3D_ScaleShiftAllInv_pts3d_rotInv_best_avg",
# "Regr3D_ScaleShiftAllInv_pts3d_first_avg",
# "RotInv MSE", /
metrics_list = [
    "Regr3D_ScaleShiftAllInv_pts3d_first_avg",
    "Regr3D_ScaleShiftAllInv_pts3d_0.2_accu_first_avg",
    "Regr3D_ScaleShiftAllInv_cd_first_avg",
    "GSRenderLoss_RRA_first_avg",
    "GSRenderLoss_RTA_first_avg",
    "GSRenderLoss_mAA_first_avg",
    "GSRenderLoss_gs_inference_psnr_first_avg",
    "GSRenderLoss_gs_inference_ssim_first_avg",
    "GSRenderLoss_gs_inference_lpips_first_avg",
]

f_list = [
    lambda x: x * 10,
    lambda x: x * 100,
    lambda x: x * 100,
    lambda x: 100 * (1 - x),
    lambda x: 100 * (1 - x),
    lambda x: 100 * (1 - x),
    lambda x: x,
    lambda x: 10 * x,
    lambda x: 10 * x,
]

# size
# 7.48 & 10.57 & 12.89 & 14.89 & 16.52 & 17.85 \\
# 2.20 & 2.56 & 2.88 & 3.13 & 3.40 & 3.30 \\
# 19.27 & 24.92 & 29.38 & 32.24 & 34.79 * 37.31 \\


metrics_best_list = [
    "Regr3D_ScaleShiftAllInv_pts3d_min_avg",
    "Regr3D_ScaleShiftAllInv_pts3d_0.2_accu_max_avg",
    "Regr3D_ScaleShiftAllInv_cd_min_avg",
    "GSRenderLoss_RRA_max_avg",
    "GSRenderLoss_RTA_max_avg",
    "GSRenderLoss_mAA_max_avg",
    "GSRenderLoss_gs_inference_psnr_max_avg",
    "GSRenderLoss_gs_inference_ssim_max_avg",
    "GSRenderLoss_gs_inference_lpips_min_avg",
]
# "Regr3D_ScaleShiftAllInv_rotInv_first_avg",

# metrics_list = [
#     "Regr3D_ScaleShiftAllInv_pts3d_first_avg",
#     "Regr3D_ScaleShiftAllInv_pts3d_first_0.3_accu_avg",
#     "Regr3D_ScaleShiftAllInv_cd_first_avg",
#     "GSRenderLoss_RRA_avg",
#     "GSRenderLoss_RTA_avg",
#     "GSRenderLoss_mAA_avg",
#     "GSRenderLoss_gs_inference_psnr_avg",
#     "GSRenderLoss_gs_inference_ssim_avg",
#     "GSRenderLoss_gs_inference_lpips_avg",
# ]


def download_tf():
    for logname in logname_list:
        if "_best" in logname:
            continue
        # (f"/home/zgtang/tf/{logname}", exist_ok=True)
        os.makedirs(f"/home/zgtang/tf/{logname}", exist_ok=True)
        manifold_path = f"manifold://ondevice_ai_writedata/tree/zgtang/dust3r/logs/{logname}"
        files = sorted(pathmgr.ls(manifold_path))
        for file in files:
            if "events.out" in file:
                command = f"manifold --prod-use-cython-client get --threads 5 ondevice_ai_writedata/tree/zgtang/dust3r/logs/{logname}/{file} /home/zgtang/tf/{logname}/{file}"
                print(command)
                os.system(command)
        # print(files)
        # fbvscode.set_trace()

def parse_tf():
    res = {}
    for logname in logname_list:
        if "_best" in logname:
            continue
        results = {}
        # (f"/home/zgtang/tf/{logname}", exist_ok=True)
        log_dir = f"/home/zgtang/tf/{logname}"
        event_files = [os.path.join(log_dir, file) for file in os.listdir(log_dir) if 'events.out' in file]

        for event_file in event_files:
            for event in tf.compat.v1.train.summary_iterator(event_file):
                step = event.step
                if step not in results.keys():
                    results[step] = {}
                for value in event.summary.value:
                    # output to /home/zgtang/tf/debug.txt
                    # print('parse', logname, value.tag)
                    with open('/home/zgtang/tf/debug.txt', 'a') as f:
                        f.write(f'parse {logname} {value.tag}\n')
                    results[step][value.tag] = value.simple_value
        res[logname] = results
    return res

def get_table(res):
    row = ["Method"] + metricsName_list * len(hs_pre_list)  
    table = [row]
    for logname in logname_list:
        if "_best" in logname:
            met_list = metrics_best_list
            results = res[logname[:-5]]
            # logname = logname[:-5]
        else:
            met_list = metrics_list
            results = res[logname]
        
        results = results[0]
        
        for id, hs_pre in enumerate(hs_pre_list):
            row = [f"{logname}_{hs_pre}"]
            for metrics in met_list:
                key = f"{hs_pre}_{metrics}" if "GO" in logname else f"{hs_pre}/{metrics}"
                # print(key)
                if key in results.keys():
                    row.append(f"{results[key]:.2f}")
                else:
                    row.append("-1")

            if "GO" in logname:
                row.append(GO_time[id])
            elif "MV" in logname:
                row.append(MV_dst_time[id])
            elif "dust3r2" in logname:
                row.append(dst2_time[id])
            else:
                row.append(" ")
            table.append(row)
        # row = [f"{logname}_sc"]
        # for sc_pre in sc_pre_list:
        #     for metrics in met_list:
        #         key = f"{sc_pre}_{metrics}" if "GO" in logname else f"{sc_pre}/{metrics}"
        #         if key in results.keys():
        #             row.append(results[key])
        #         else:
        #             row.append("-1")
        #     row.append(' ')
        # table.append(row)
    return table

def get_table_latex(res):
    table = []
    for pre_list_i in pre_list:
        for logname in logname_list:
            if "_best" in logname:
                met_list = metrics_best_list
                results = res[logname[:-5]]
            else:
                met_list = metrics_list
                results = res[logname]
            
            results = results[0]
            
            for id, hs_pre in enumerate(pre_list_i):
                row = [f"{logname}_{hs_pre}"]
                for m_id, metrics in enumerate(met_list):
                    key = f"{hs_pre}_{metrics}" if "GO" in logname else f"{hs_pre}/{metrics}"
                    # print(key)
                    f = f_list[m_id]
                    if key in results.keys():
                        avg = f(results[key])
                        avg = np.round(avg, round_list[m_id])
                        med = f(results[key.replace('avg', 'med')])
                        med = np.round(med, round_list[m_id])
                        if m_id == 2:
                            row.append(f"{avg}({med})")
                        else:
                            # row.append(f"{avg}({med})")
                            row.append(f"{avg}")
                    else:
                        row.append("-1")
                
                table.append(row)
    return table

def output_csv(table):

    with open(f'/home/zgtang/tf/output.csv', 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        # 写入数据行
        for row in table:
            print(row)
            writer.writerow(row)


    '''
    \multirow{6}{*}{\rotatebox[origin=c]{90}{4 views}} & PoseDiffusion & x\\
    & Spann3R & \\
    & \dst~w/ GA & 0.20 & 0.75 & 0.06 & 0.89 & 0.98 & 0.79 & 15.99 & 0.50 & 0.37 & 2.42\\
    & Ours (MV-\dst) & 0.15 & 0.92 & 0.02 & 0.98 & 0.99 & 0.95 & 19.92 & 0.60 & 0.20 & 0.05\\
    & Ours (MV-\dst++) & 0.13 & 0.95 & 0.02 & 0.99 & 0.99 & 0.95 & 20.22 & 0.61 & 0.19 & 0.28\\\cline{2-12}
    & {\color{lightgray}Ours (MV-\dst~oracle)} & 0.14 & 0.95 & 0.02 & 1.00 & 1.00 & 0.97 & 21.05 & 0.65 & 0.16\\\midrule 
    '''
    # write also to txt
    # dataset, method, n_of_views
    texts = []
    n_data = len(pre_list)
    n_method = len(logname_list)
    n_view = len(pre_list[0])
    for data_id in range(n_data):
        texts.append("")
        for view_id in range(n_view):
            real_n_view = view_range[view_id] * 4
            text_row = r'\multirow{'+str(n_method)+r'}{*}{\rotatebox[origin=c]{90}{' + str(real_n_view) + r'v}} '
            
            for method_id in range(n_method):
                table_position = data_id * n_view * n_method + method_id * n_view + view_id
                is_gray = r"\color{lightgray}" in logname_latex_list[method_id]
                is_red = r"ft" in logname_latex_list[method_id]
                # print('name', logname_latex_list[method_id])
                table_elements = table[table_position][1:]
                if is_gray:
                    # {\color{lightgray}x}
                    table_elements = [r"\lgr{" + r + "}" for r in table_elements]
                
                if is_red:
                    table_elements = [r"\cellcolor[rgb]{0.999, 0.8, 0.8}" + r for r in table_elements]

                texts.append(f'& {logname_latex_list[method_id]} & ' + r' & '.join(table_elements) + post_str_latex_list[method_id])
                if text_row != "":
                    texts[-1] = text_row + texts[-1]
                    text_row = ""

    with open(f'/home/zgtang/tf/output2.txt', 'w', encoding='utf-8') as f:
        for row in texts:
            f.write(row + '\n')

def output_csv2(table):

    with open(f'/home/zgtang/tf/output.csv', 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        # 写入数据行
        for row in table:
            print(row)
            writer.writerow(row)


    '''
    \multirow{6}{*}{\rotatebox[origin=c]{90}{4 views}} & PoseDiffusion & x\\
    & Spann3R & \\
    & \dst~w/ GA & 0.20 & 0.75 & 0.06 & 0.89 & 0.98 & 0.79 & 15.99 & 0.50 & 0.37 & 2.42\\
    & Ours (MV-\dst) & 0.15 & 0.92 & 0.02 & 0.98 & 0.99 & 0.95 & 19.92 & 0.60 & 0.20 & 0.05\\
    & Ours (MV-\dst++) & 0.13 & 0.95 & 0.02 & 0.99 & 0.99 & 0.95 & 20.22 & 0.61 & 0.19 & 0.28\\\cline{2-12}
    & {\color{lightgray}Ours (MV-\dst~oracle)} & 0.14 & 0.95 & 0.02 & 1.00 & 1.00 & 0.97 & 21.05 & 0.65 & 0.16\\\midrule 
    '''
    # write also to txt
    # dataset, method, n_of_views
    texts = []
    n_data = len(pre_list)
    n_method = len(logname_list)
    n_view = len(pre_list[0])
    task_groups = [[0, 3], [3, 6], [6, 9]]
    for task_group in task_groups: # different table
        for view_id in range(n_view): 
            real_n_view = view_range[view_id] * 4
            text_begin = r'\multirow{5}{*}{\rotatebox[origin=c]{90}{' + str(real_n_view) + r' views}} '
            
            for method_id in range(n_method):
                text_row = f'& {logname_latex_list[method_id]} & '
                is_gray = r"\color{lightgray}" in logname_latex_list[method_id]
                is_red = r"\mvdustthreerp" == logname_latex_list[method_id][:len(r"\mvdustthreerp")]
                table_elements = [] 
                for data_id in range(n_data):
                    table_position = data_id * n_view * n_method + method_id * n_view + view_id
                    table_elements_i = table[table_position][1 + task_group[0]:1 + task_group[1]]
                    if is_gray:
                        # {\color{lightgray}x}
                        table_elements_i = [r"\lgr{" + r + "}" for r in table_elements_i]
                    if is_red:
                        table_elements_i = [r"\cellcolor[rgb]{0.999, 0.8, 0.8}" + r for r in table_elements_i]
                    table_elements += table_elements_i
                
                # print(table[table_position][0], table_elements)
                texts.append(text_row + r' & '.join(table_elements) + post_str_latex_list[method_id])
                
                if text_begin != "":
                    texts[-1] = text_begin + texts[-1]
                    text_begin = ""
        texts.append('')
        texts.append('')

    with open(f'/home/zgtang/tf/output3.txt', 'w', encoding='utf-8') as f:
        for row in texts:
            f.write(row + '\n')

# download_tf()
tf_results = parse_tf()
# table = get_table(tf_results)
table = get_table_latex(tf_results)
output_csv(table)
# output_csv2(table)
