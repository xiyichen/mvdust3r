
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import glob
from ..dust3r.pcd_render import pcd_render

import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--div", default=1, type=int)
parser.add_argument("--node-no", default=0, type=int)
args = parser.parse_args()
print('args', args)
node_no = args.node_no

# import os
# cuda_id = int(args.cuda_id)
# cuda_id = f"cuda:{cuda_id}"
# print('cuda id', cuda_id)

import torch.manifold.patch
import torch.distributed as dist

def init_distributed():
    if not dist.is_initialized():
        dist.init_process_group(backend='gloo', init_method='env://')

def get_rank():
    if not dist.is_initialized():
        return 0
    return dist.get_rank()

init_distributed()
rank = get_rank()


cuda_id = int(rank) % 8
device = f"cuda:{cuda_id}"
print('cuda id', cuda_id)

import PIL
import numpy as np
import torch
import glob, sys
import json
import imageio
import cv2

import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__))))

from dust3r.utils.geometry import depthmap_to_absolute_camera_coordinates

from iopath.common.file_io import g_pathmgr

nn_shrink_rate = 6

def compare(a, b):
    a = int(os.path.basename(a)[:-4])
    b = int(os.path.basename(b)[:-4])
    return a < b

def key(a):
    return int(os.path.basename(a)[:-4])


def min_dis(A, B):

    A = torch.from_numpy(A).reshape(-1, 3).to(device)
    B = torch.from_numpy(B).reshape(-1, 3).to(device)
    # print(A.device)
    from pytorch3d.ops import knn_points
    dis, _, _ = knn_points(B[None], A[None]) # B querying in A, dis: [1, B.shape[0], 1]
    # print('min_dis', dis.shape, dis.mean())
    return dis[0,:,0]

def cover(pc1_, pc2_): # querying pc2 in pc1
    import numpy as np
    pc1 = pc1_.reshape(-1, 3)
    pc2 = pc2_.reshape(-1, 3)
    distances = min_dis(pc1, pc2)
    
    thres = 0.015 * nn_shrink_rate / 3
    return distances[(distances > 0) * (distances < thres)].shape[0] / distances.shape[0]

def get_score(pc1, pc2):
    return (cover(pc1, pc2) + cover(pc2, pc1)) / 2
    
def exist(path):
    try:
        if os.path.exists(g_pathmgr.get_local_path(path)):
            return True
        else:
            return False
    except:
        return False

def get_scene_list_scannet():
    scan_list = np.load(g_pathmgr.get_local_path("manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large/scan_list.npy"))
    # print("scan_list", scan_list[:1000:200], len(scan_list)) # 1513
    return scan_list
    scan_list = []
    for i in range(10000):
        for j in range(100):
            scan_name = f"manifold://scannet_dataset/tree/scans/scene{str(i).zfill(4)}_{str(j).zfill(2)}"
            if exist(os.path.join(scan_name, "frames", "intrinsic", "intrinsic_depth.txt")):
                scan_list.append(scan_name)
                print(scan_name)
            else:
                break
            
        if j == 0:
            break
    print(scan_list)
    np.save("scan_list.npy", scan_list)
    return scan_list

def extract_K(lines):
    ss = lines[3].split(' ')
    K = np.eye(3)
    K[0,0] = float(ss[4])
    K[1,1] = float(ss[5])
    K[0,2] = float(ss[6])
    K[1,2] = float(ss[7])
    return K

# Camera list with one line of data per camera:
#   CAMERA_ID, MODEL, WIDTH, HEIGHT, PARAMS[]
# Number of cameras: 1
# 1 OPENCV 1920 1440 1435.97 1438.42 958.945 720.418 0.0650361 -0.0757979 -0.000747881 0.000162046


n_v = 4
n_tuple_per_scene = 1000
n_try = 100
target_n = 1000
debug = False

dataset_name = "scannetpp"
# dataset_name = "scannetpp_easy"

def qvec2rotmat(qvec):
    return np.array([
        [1 - 2 * qvec[2]**2 - 2 * qvec[3]**2,
         2 * qvec[1] * qvec[2] - 2 * qvec[0] * qvec[3],
         2 * qvec[3] * qvec[1] + 2 * qvec[0] * qvec[2]],
        [2 * qvec[1] * qvec[2] + 2 * qvec[0] * qvec[3],
         1 - 2 * qvec[1]**2 - 2 * qvec[3]**2,
         2 * qvec[2] * qvec[3] - 2 * qvec[0] * qvec[1]],
        [2 * qvec[3] * qvec[1] - 2 * qvec[0] * qvec[2],
         2 * qvec[2] * qvec[3] + 2 * qvec[0] * qvec[1],
         1 - 2 * qvec[1]**2 - 2 * qvec[2]**2]])

def qt2w2c(q, t) -> np.ndarray:
    R = qvec2rotmat(q)
    world2cam = np.eye(4)
    world2cam[:3, :3] = R
    world2cam[:3, 3] = t
    return world2cam

def extract_image_txt(lines):
    c2ws = []
    frame_names = []
    for x in lines:
        if ".jpg" in x:
            x = x.split(' ')
            q = [float(y) for y in x[1:5]]
            t = [float(y) for y in x[5:8]]
            frame = int(x[9].replace('frame_', '').replace('.jpg', ''))
            c2ws.append(np.linalg.inv(qt2w2c(q, t)))
            frame_names.append(frame)
            # print('extract', x, q, t, frame)
    
    return c2ws, frame_names

def main():
    
    scene_list = get_scene_list_scannetpp()
    print(scene_list, len(scene_list))
    tuple_done = 0
    for scene_id, scene_name in enumerate(scene_list[:]):
        scene_name = os.path.join("manifold://ondevice_ai_writedata/tree/zgtang/data/scannetpp/data", scene_name.split('/')[-1])
        if scene_id % args.div != cuda_id + args.node_no * 8:
            continue
        print('trying', scene_id, cuda_id, cuda_id + args.node_no * 8, scene_name)
        
        # with g_pathmgr.open(os.path.join(scene_name, "valid_frames.txt"), 'r') as f:
        #     valid_frames_ss = f.readlines()
        # valid_frames_name = extract_valid_frames(valid_frames_ss)
        
        # target_scene_name = f"/home/zgtang/manifold_things/data/{dataset_name}/{os.path.basename(scene_name)}"
        target_scene_name = f"manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/{dataset_name}/{os.path.basename(scene_name)}"
        last_name = f"{target_scene_name}/{str(n_tuple_per_scene - 1).zfill(6)}_extra.pt"
        if g_pathmgr.exists(last_name):
            print('exist', last_name)
            continue
        print('doing', scene_id, cuda_id, cuda_id + args.node_no * 8, scene_name)
        
        g_pathmgr.mkdirs(target_scene_name)
        poses, frame_names = extract_image_txt(open(g_pathmgr.get_local_path(os.path.join(scene_name, "iphone", "colmap", "images.txt")), "r").readlines())
        intrinsic_depth = extract_K(open(g_pathmgr.get_local_path(os.path.join(scene_name, "iphone", "colmap", "cameras.txt")), "r").readlines())
        intrinsic_depth[:2] *= 1 / nn_shrink_rate
        rgb_list = []
        depth_list = []
        depth_dir = os.path.join("manifold://ondevice_ai_writedata/tree/zgtang/data/scannetpp/render", scene_name.split('/')[-1])
        for frame in frame_names:
            rgb_name   = os.path.join(scene_name, "iphone", "rgb", f"frame_{str(frame).zfill(6)}.jpg")
            depth_name = os.path.join(depth_dir, "iphone", "render_depth", f"frame_{str(frame).zfill(6)}.png")
            rgb_list.append(rgb_name)
            depth_list.append(depth_name)

        print('scene_name', scene_name, len(rgb_list))

        
        step = max(len(rgb_list) // target_n, 1)
        rgb_list = rgb_list[::step]
        depth_list = depth_list[::step]
        poses = poses[::step]
        
        print('loading:', len(rgb_list))
        rgb_preload = []
        depth_preload = []
        pose_preload = []
        for id in range(len(rgb_list)):
            try:
                if debug:
                    rgb = imageio.imread(g_pathmgr.get_local_path(rgb_list[id])).astype(np.float32) / 255
                depth = imageio.imread(g_pathmgr.get_local_path(depth_list[id])).astype(np.float32) / 1000
                pose = poses[id]
                if debug:
                    rgb_preload.append(rgb)
                depth_preload.append(depth)
                pose_preload.append(pose)
            except:
                pass
            print('ll', id)
        if len(depth_preload) < len(rgb_list) * 0.7:
            continue
        print('loading Done')
        for cnt in range(n_tuple_per_scene):
            current_name = f"{target_scene_name}/{str(cnt).zfill(6)}_extra.pt"
            if g_pathmgr.exists(current_name):
                print('secEx', current_name)
                continue
            # generate n_v views randomly from rgb_list and depth_list, do not replace.

            id_list = [None for i in range(n_v)]
            focal = (intrinsic_depth[0,0] + intrinsic_depth[1, 1]) / 2
            pcd_all = []
            C = np.zeros((n_v, n_v))
            i = 0
            rgbs = []
            while i < n_v:
                            
                try_cnt = 0
                
                while 1:

                    try_cnt += 1
                    id_list[i] = np.random.choice(len(depth_list))

                    if try_cnt > n_try:
                        print('failed')
                        id_list = [None for i in range(n_v)]
                        try_cnt = 0
                        i = -1
                        rgbs = []
                        pcd_all = []
                        C = np.zeros((n_v, n_v))
                        break
                    
                    if id_list[i] in id_list[:i]:
                        continue

                    print('test', i, id_list[i], try_cnt)
                    import time
                    t = time.time()
                    id = id_list[i]
                    if debug:
                        rgb = rgb_preload[id]
                    depth = depth_preload[id]
                    pose = pose_preload[id]
                    print('load time', time.time() - t)
                    t = time.time()
                    depth = cv2.resize(depth, (depth.shape[1] // nn_shrink_rate, depth.shape[0] // nn_shrink_rate))
                    pcd, valid_mask = depthmap_to_absolute_camera_coordinates(depth, intrinsic_depth, pose) # pcd (480, 640, 3) (480, 640) 0.9917024739583333 （c2w here)
                    # pcd = pcd[::nn_shrink_rate,::nn_shrink_rate]
                    # valid_mask = valid_mask[::nn_shrink_rate,::nn_shrink_rate]
                    pcd_valid = pcd[valid_mask]
                    print('depth calc time', time.time() - t)
                    # print('pcd', pcd.shape, valid_mask.shape, valid_mask.mean()) # pcd (480, 640, 3) (480, 640) 0.9874479166666666
                    score_list = []
                    t = time.time()
                    for j in range(i):
                        score_list.append(get_score(pcd_all[j], pcd_valid))
                    print('nn time', time.time() - t)
                    print(score_list)

                    # if len(score_list) == 0 or (np.max(score_list) > 0.0 and np.max(score_list) < 1.0):
                    # if len(score_list) == 0 or (np.max(score_list) > 0.85 and np.max(score_list) < 1.0):
                    # if len(score_list) == 0 or (np.max(score_list) > 0.3 and np.max(score_list) < 0.7):
                    # if len(score_list) == 0 or (np.max(score_list) > 0.1 and np.max(score_list) < 0.4):
                    if len(score_list) == 0 or (np.max(score_list) > 0.3 and np.max(score_list) < 0.7):
                        pcd_all.append(pcd_valid)
                        try_cnt = 0
                        break

                i += 1
                
                # rgb = cv2.resize(rgb, (depth.shape[1], depth.shape[0]))
                # np.save(f"{target_scene_name}/{str(cnt).zfill(6)}_rgb_{i}.npy", rgb)
                # np.save(f"{target_scene_name}/{str(cnt).zfill(6)}_pcd_{i}.npy", pcd)
                # np.save(f"{target_scene_name}/{str(cnt).zfill(6)}_valid_{i}.npy", valid_mask)
                # np.save(f"{target_scene_name}/{str(cnt).zfill(6)}_focal_{i}.npy", focal)
                # np.save(f"{target_scene_name}/{str(cnt).zfill(6)}_pose_{i}.npy", pose)
                
                if debug and i != 0:
                    rgb = cv2.resize(rgb, (depth.shape[1], depth.shape[0]))
                    rgb = (rgb * 255).astype(np.uint8)
                    rgbs.append(rgb)
            
            tuple_done += 1
            if debug:
                
                rgbs = np.concatenate(rgbs, axis=1)
                imageio.imwrite(f"/home/zgtang/manifold_things/temp/scnpp/{str(cnt).zfill(6)}_rgb.png", rgbs)
                pcd = np.concatenate(pcd_all, axis=0)
                pcd = torch.from_numpy(pcd).cuda().float()
                rgb_pcd = torch.ones_like(pcd) * 0.5
                # def pcd_render(pcd, rgb, tgt = None, normalize = False, rot = True):
                pcd_render(pcd, rgb_pcd, f"/home/zgtang/manifold_things/temp/scnpp/{str(cnt).zfill(6)}_pcd.mp4", normalize = True)

            C_avg = []
            for i in range(n_v):
                for j in range(n_v):
                    if i != j:
                        C[i,j] = get_score(pcd_all[i], pcd_all[j])
                        C_avg.append(C[i,j])
                    # print(i,j, C[i,j])
            
            rgb_list_ = [rgb_list[id] for id in id_list]
            depth_list_ = [depth_list[id] for id in id_list]
            pose_list_ = [poses[id].tolist() for id in id_list]
            intrinsic_list_ = [intrinsic_depth.tolist()] * len(rgb_list_)
            extra_info = {
                'C': C.tolist(),
                'C_avg': np.mean(np.array(C_avg)).item(),
                'id_list': id_list,
                'rgb_list': rgb_list_,
                'depth_list': depth_list_,
                'pose_list': pose_list_,
                'intrinsic_list': intrinsic_list_,
                }
            print('extra_info', scene_id, scene_name, extra_info)
            torch.save(extra_info, f"{target_scene_name}/{str(cnt).zfill(6)}_extra.pt")
            if debug:
                with open(f"/home/zgtang/manifold_things/temp/scnpp/{str(cnt).zfill(6)}_extra.json", "w") as f:
                    json.dump(extra_info, f, indent=4)
            
            print('C')
            print(C)
            print('tuple done', tuple_done, cuda_id, id_list)


main()
