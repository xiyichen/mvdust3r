
import sys, os


import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--div", default=1, type=int)
parser.add_argument("--node-no", default=0, type=int)
args = parser.parse_args()
print('args', args)
node_no = args.node_no

# import os
# cuda_id = int(args.cuda_id)
# cuda_id = f"cuda:{cuda_id}"
# print('cuda id', cuda_id)

import torch.manifold.patch
import torch.distributed as dist

def init_distributed():
    if not dist.is_initialized():
        dist.init_process_group(backend='gloo', init_method='env://')

def get_rank():
    if not dist.is_initialized():
        return 0
    return dist.get_rank()

init_distributed()
rank = get_rank()


cuda_id = int(rank) % 8
device = f"cuda:{cuda_id}"
print('cuda id', cuda_id)

import PIL
import numpy as np
import torch
import glob, sys
import json
import imageio
import cv2

import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__))))

from dust3r.utils.geometry import depthmap_to_absolute_camera_coordinates

from iopath.common.file_io import g_pathmgr

nn_shrink_rate = 2

def compare(a, b):
    a = int(os.path.basename(a)[:-4])
    b = int(os.path.basename(b)[:-4])
    return a < b

def key(a):
    return int(os.path.basename(a)[:-4])


# def min_dis(pc1, pc2): # querying pc2 in pc1
#     h,w = pc1.shape[:2]
#     import cupy as cp
#     import numpy as np
#     from scipy.spatial import cKDTree
#     pc1 = pc1.reshape(-1, 3)
#     pc2 = pc2.reshape(-1, 3)
#     pcd1_cp = cp.asarray(pc1)
#     pcd2_cp = cp.asarray(pc2)

#     # Construct KD-Trees
#     tree_pcd1 = cKDTree(pc1)
#     tree_pcd2 = cKDTree(pc2)

#     # Query nearest neighbors
#     distances, _ = tree_pcd1.query(pcd2_cp.get(), k=1)
#     print('dis', np.mean(distances))
#     while 1:
#         thres = float(input('thres'))
#         print(distances[(distances > 0) * (distances < thres)].shape[0] / distances.shape[0])
#         from copy import deepcopy
#         dd = deepcopy(distances).reshape(h, w)
#         dd[dd >= thres] = 0
#         dd[( dd > 0) * (dd < thres)] = 255
#         dd[dd == 0] = 0
#         print('dd', dd.mean())
#         imageio.imwrite(f'temp/{thres}.png', dd.astype(np.uint8)) # 0.03 should be good

def min_dis(A, B):

    A = torch.from_numpy(A).reshape(-1, 3).to(device)
    B = torch.from_numpy(B).reshape(-1, 3).to(device)
    # print(A.device)
    from pytorch3d.ops import knn_points
    dis, _, _ = knn_points(B[None], A[None]) # B querying in A, dis: [1, B.shape[0], 1]
    # print('min_dis', dis.shape, dis.mean())
    return dis[0,:,0]

def cover(pc1_, pc2_): # querying pc2 in pc1
    import numpy as np
    pc1 = pc1_.reshape(-1, 3)
    pc2 = pc2_.reshape(-1, 3)
    # pcd1_cp = cp.asarray(pc1)
    # pcd2_cp = cp.asarray(pc2)

    # # Construct KD-Trees
    # tree_pcd1 = cKDTree(pc1)
    # tree_pcd2 = cKDTree(pc2)

    # # Query nearest neighbors
    # distances, _ = tree_pcd1.query(pcd2_cp.get(), k=1)
    distances = min_dis(pc1, pc2)
    # print(distances.shape, distances.mean())
    
    thres = 0.015 * nn_shrink_rate
    return distances[(distances > 0) * (distances < thres)].shape[0] / distances.shape[0]

def get_score(pc1, pc2):
    return (cover(pc1, pc2) + cover(pc2, pc1)) / 2
    
def exist(path):
    try:
        if os.path.exists(g_pathmgr.get_local_path(path)):
            return True
        else:
            return False
    except:
        return False

def get_scene_list():
    scan_list = np.load(g_pathmgr.get_local_path("manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large/scan_list.npy"))
    # print("scan_list", scan_list[:1000:200], len(scan_list)) # 1513
    return scan_list
    scan_list = []
    for i in range(10000):
        for j in range(100):
            scan_name = f"manifold://scannet_dataset/tree/scans/scene{str(i).zfill(4)}_{str(j).zfill(2)}"
            if exist(os.path.join(scan_name, "frames", "intrinsic", "intrinsic_depth.txt")):
                scan_list.append(scan_name)
                print(scan_name)
            else:
                break
            
        if j == 0:
            break
    print(scan_list)
    np.save("scan_list.npy", scan_list)
    return scan_list

def extract_valid_frames(valid_frames_ss):
    valid_frames_name = []
    for x in valid_frames_ss:
        x = x.split(' ')
        if len(x) <= 1:
            break
        if int(x[2]) != 0:
            print('get bad frame', x)
            # exit(0)
        valid_frames_name.append(int(x[1]))
    return valid_frames_name

n_v = 4
n_tuple_per_scene = 1000
n_try = 100
target_n = 1000

dataset_name = "scannet_large_easy"
dataset_name = "scannet_large"

def main():
    
    scene_list = get_scene_list()
    # exit(0)
    tuple_done = 0
    for scene_id, scene_name in enumerate(scene_list[:]):
        if scene_id % args.div != cuda_id + args.node_no * 8:
            continue
        print('trying', scene_id, cuda_id, cuda_id + args.node_no * 8, scene_name)
        
        with g_pathmgr.open(os.path.join(scene_name, "valid_frames.txt"), 'r') as f:
            valid_frames_ss = f.readlines()
        valid_frames_name = extract_valid_frames(valid_frames_ss)
        
        # target_scene_name = f"/home/zgtang/manifold_things/data/{dataset_name}/{os.path.basename(scene_name)}"
        target_scene_name = f"manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/{dataset_name}/{os.path.basename(scene_name)}"
        last_name = f"{target_scene_name}/{str(n_tuple_per_scene - 1).zfill(6)}_extra.pt"
        if g_pathmgr.exists(last_name):
            print('exist', last_name)
            continue
        print('doing', scene_id, cuda_id, cuda_id + args.node_no * 8, scene_name)
        
        g_pathmgr.mkdirs(target_scene_name)
        
        print('scene_name', scene_name)

        rgb_suff = "jpg"
        if not exist(os.path.join(scene_name, "frames", "color", f"{valid_frames_name[0]}.{rgb_suff}")):
            print('not exist', os.path.join(scene_name, "frames", "color", f"{valid_frames_name[0]}.{rgb_suff}"))
            rgb_suff = "png"
        rgb_list = [os.path.join(scene_name, "frames", "color", f"{valid_frame}.{rgb_suff}") for valid_frame in valid_frames_name]
        depth_list = [os.path.join(scene_name, "frames", "depth", f"{valid_frame}.png") for valid_frame in valid_frames_name]
        pose_list = [os.path.join(scene_name, "frames", "pose", f"{valid_frame}.txt") for valid_frame in valid_frames_name]
        intrinsic_depth = np.loadtxt(g_pathmgr.get_local_path(os.path.join(scene_name, "frames", "intrinsic", "intrinsic_depth.txt")))
        
        step = max(len(rgb_list) // target_n, 1)
        rgb_list = rgb_list[::step]
        depth_list = depth_list[::step]
        pose_list = pose_list[::step]
        
        print('loading:', len(rgb_list))
        # rgb_preload = []
        depth_preload = []
        pose_preload = []
        for id in range(len(rgb_list)):
            try:
                # rgb = imageio.imread(g_pathmgr.get_local_path(rgb_list[id])).astype(np.float32) / 255
                depth = imageio.imread(g_pathmgr.get_local_path(depth_list[id])).astype(np.float32) / 1000
                pose = np.loadtxt(g_pathmgr.get_local_path(pose_list[id]))
                # rgb_preload.append(rgb)
                depth_preload.append(depth)
                pose_preload.append(pose)
            except:
                pass
            print('ll', id)
        if len(depth_preload) < target_n * 0.7:
            continue
        print('loading Done')
        for cnt in range(n_tuple_per_scene):
            current_name = f"{target_scene_name}/{str(n_tuple_per_scene - 1).zfill(6)}_extra.pt"
            if g_pathmgr.exists(current_name):
                print('secEx', current_name)
                continue
            # generate n_v views randomly from rgb_list and depth_list, do not replace.

            id_list = [None for i in range(n_v)]
            focal = (intrinsic_depth[0,0] + intrinsic_depth[1, 1]) / 2
            pcd_all = []
            C = np.zeros((n_v, n_v))
            i = 0
            rgbs = []
            while i < n_v:
                            
                try_cnt = 0
                
                while 1:

                    try_cnt += 1
                    id_list[i] = np.random.choice(len(depth_list))

                    if try_cnt > n_try:
                        print('failed')
                        try_cnt = 0
                        i = -1
                        break
                    
                    if id_list[i] in id_list[:i]:
                        continue

                    print('test', i, id_list[i], try_cnt)
                    import time
                    t = time.time()
                    id = id_list[i]
                    # rgb = rgb_preload[id]
                    depth = depth_preload[id]
                    pose = pose_preload[id]
                    print('load time', time.time() - t)
                    t = time.time()
                    pcd, valid_mask = depthmap_to_absolute_camera_coordinates(depth, intrinsic_depth, pose) # pcd (480, 640, 3) (480, 640) 0.9917024739583333
                    pcd = pcd[::nn_shrink_rate,::nn_shrink_rate]
                    valid_mask = valid_mask[::nn_shrink_rate,::nn_shrink_rate]
                    pcd_valid = pcd[valid_mask]
                    print('depth calc time', time.time() - t)
                    # print('pcd', pcd.shape, valid_mask.shape, valid_mask.mean()) # pcd (480, 640, 3) (480, 640) 0.9874479166666666
                    score_list = []
                    t = time.time()
                    for j in range(i):
                        score_list.append(get_score(pcd_all[j], pcd_valid))
                    print('nn time', time.time() - t)
                    print(score_list)

                    # if len(score_list) == 0 or (np.max(score_list) > 0.3 and np.max(score_list) < 0.7):
                    if len(score_list) == 0 or (np.max(score_list) > 0.1 and np.max(score_list) < 0.4):
                        pcd_all.append(pcd_valid)
                        try_cnt = 0
                        break

                i += 1
                
                # rgb = cv2.resize(rgb, (depth.shape[1], depth.shape[0]))
                # np.save(f"{target_scene_name}/{str(cnt).zfill(6)}_rgb_{i}.npy", rgb)
                # np.save(f"{target_scene_name}/{str(cnt).zfill(6)}_pcd_{i}.npy", pcd)
                # np.save(f"{target_scene_name}/{str(cnt).zfill(6)}_valid_{i}.npy", valid_mask)
                # np.save(f"{target_scene_name}/{str(cnt).zfill(6)}_focal_{i}.npy", focal)
                # np.save(f"{target_scene_name}/{str(cnt).zfill(6)}_pose_{i}.npy", pose)

                # rgb = cv2.resize(rgb, (depth.shape[1], depth.shape[0]))
                # rgb = (rgb * 255).astype(np.uint8)
                # rgbs.append(rgb)
            
            tuple_done += 1
            # rgbs = np.concatenate(rgbs, axis=1)
            # imageio.imwrite(f"{target_scene_name}/{str(cnt).zfill(6)}_rgb.png", rgbs)



            C_avg = []
            for i in range(n_v):
                for j in range(n_v):
                    if i != j:
                        C[i,j] = get_score(pcd_all[i], pcd_all[j])
                        C_avg.append(C[i,j])
                    # print(i,j, C[i,j])
            
            rgb_list_ = [rgb_list[id] for id in id_list]
            depth_list_ = [depth_list[id] for id in id_list]
            pose_list_ = [pose_list[id] for id in id_list]
            intrinsic_list_ = [os.path.join(scene_name, "frames", "intrinsic", "intrinsic_depth.txt")] * len(rgb_list_)
            extra_info = {
                'C': C.tolist(),
                'C_avg': np.mean(np.array(C_avg)).item(),
                'id_list': id_list,
                'rgb_list': rgb_list_,
                'depth_list': depth_list_,
                'pose_list': pose_list_,
                'intrinsic_list': intrinsic_list_,
                }
            print('extra_info', scene_id, scene_name, extra_info)
            torch.save(extra_info, f"{target_scene_name}/{str(cnt).zfill(6)}_extra.pt")
            # with open(f"{target_scene_name}/{str(cnt).zfill(6)}_extra.json", "w") as f:
            #     json.dump(extra_info, f, indent=4)
            
            print('C')
            print(C)
            print('tuple done', tuple_done, cuda_id, id_list)


main()
