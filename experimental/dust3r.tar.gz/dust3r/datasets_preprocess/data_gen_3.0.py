import h5py
import json
import glob
import os, sys
import random
import numpy as np
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__))))
def extract_data_name(x, data_name):
    if "scannet_dataset" in x:
        x = x.replace('manifold://scannet_dataset/tree/scans/', '')
        # "manifold://scannet_dataset/tree/scans/scene0000_00/frames/color/1660.jpg"
        result = x.split('/')[0]
    elif "scannetpp" in x:
        # x = x.replace('manifold://ondevice_ai_writedata/tree/zgtang/data/scannetpp/data/', '')
        x = x.replace('manifold://ondevice_ai_writedata/tree/zgtang/data/scannetpp/data/', 'scannetpp/') # a hack, all scannetpp should be train
        # manifold://ondevice_ai_writedata/tree/zgtang/data/scannetpp/data/09c1414f1b/iphone/rgb/frame_002770.jpg
        result = x.split('/')[0]
    elif "habitat_sim" in x:
        # x = x.replace('manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/hs/gibson/', '')
        x = x.replace(f'manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/{data_name}/gibson/', 'gibson/') # a hack, all gibson should be train
        x = x.replace(f'manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/{data_name}/hm3d/val/', '')
        x = x.replace(f'manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/{data_name}/hm3d/train/', '')
        # manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/hs/gibson/Aldrich/00000000.png
        # manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/hs_tree_diverse_first_2/gibson/Ackermanville/00001929.png
        # manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/hs/hm3d/val/00899-58NLZxWBSpk/58NLZxWBSpk.basis/00001997.png
        # manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/hs/hm3d/train/00009-vLpv2VX547B/vLpv2VX547B.basis/00000575.png
        result = x.split('/')[0]
    if result[:len("manifold")] == "manifold":
        raise NotImplementedError
    return result

def scannet_add_more(data_list, num):
    scannet_full = glob.glob("/home/zgtang/scannet_large_easier_12/*")
    scannet_full = [os.path.basename(x) for x in scannet_full]
    random.shuffle(scannet_full)
    for x in scannet_full:
        if len(data_list) >= num:
            break
        if x not in data_list:
            # print('add', x, data_list[0])
            data_list.append(x)
        else:
            pass
            # print('duplicate', x)
    return data_list

def scannet_add_more2(data_list):
    data_list_base = []
    for x in data_list:
        if '_' in os.path.basename(x):
            scene_base_name = os.path.basename(x).split('_')[0]
            if scene_base_name not in data_list_base:
                data_list_base.append(scene_base_name)
                print('more2 add base', scene_base_name)
    scannet_full = glob.glob("/home/zgtang/scannet_large_easier_12/*")
    scannet_full = [os.path.basename(x) for x in scannet_full]
    scannet_full.sort()
    for x in scannet_full:
        if x.split('_')[0] in data_list_base:
            # print('add', x, data_list[0])
            if x not in data_list:
                print('add', x)
                data_list.append(x)
        else:
            print('not add', x)
            # print('duplicate', x)
    return data_list

def get_train_data():
    hm3d_train = glob.glob("/home/zgtang/data_gen/multiview_habitat_metadata/hm3d/train/*")
    hm3d_train.sort()
    print('hm3d_train', len(hm3d_train))
    data_list = hm3d_train
    scannet_train = glob.glob("/home/zgtang/data_gen/multiview_habitat_metadata/scannet/*")
    scannet_train = [os.path.basename(x) for x in scannet_train]
    print('scannet_train before', len(scannet_train))
    scannet_train.sort()
    # scannet_train = scannet_add_more(scannet_train, 1415) # the full is 1515
    scannet_train = scannet_add_more2(scannet_train) # the full is 1515
    scannet_train.sort()
    print('scannet_train after', len(scannet_train))
    data_list = data_list + scannet_train
    data_list = data_list + ['gibson'] # a hack, all gibson should be train
    data_list = data_list + ['scannetpp'] # a hack, all gibson should be train
    data_list = [os.path.basename(x) for x in data_list]
    return set(data_list)

def get_train_data2():
    data_list = json.load(open("/home/zgtang/misc/train_name_list.json", 'r'))
    data_list = scannet_add_more2(data_list) # the full is 1515
    data_list.sort()
    print('scannet_train after', len(data_list))
    data_list = [os.path.basename(x) for x in data_list]
    return set(data_list)

def get_train_data_list():
    # data_list = list(get_train_data())
    data_list = list(get_train_data2())
    data_list.sort()
    with open('/home/zgtang/misc/train_name_list.json', 'w') as f:
        json.dump(data_list, f)

    print(len(data_list))

def check_h5():

    h5f_path = "/home/zgtang/scannetpp_large_easier_16/dps.h5"
    h5f_path = "/home/zgtang/hs_meta/dps.h5"
    with h5py.File(h5f_path, 'r') as h5f:
        json_str = h5f['json_strs'][1000000]
        data_dict = json.loads(json_str)
        print(data_dict)


dataname_list = [
    "scannet_huge", # nv4 hard
    "scannet_huge_easy", # nv4 easy
    "scannet_large_easier_12",
    "scannet_large_easy_12",
    "scannetpp_large_easy_16",
    "scannetpp_large_easier_16",
    "hs_large",
    "hs_tree_large",
]

dataname_list2 = [
    "scannet_huge",
    "scannet_huge_easy",
    "scannet_large_easier_12",
    "scannet_large_easy_12",
    "scannetpp_large_easy_16",
    "scannetpp_large_easier_16",
    "hs_meta",
    "hs_tree_meta",
    "hs_chain_meta",
    "hs_tree_last_meta",
    "hs_tree_diverse_first_meta",
    "hs_tree_diverse_first_2_meta",
]

dataname_list_test = [
    "hs_tree_old_test_hard_4_1_meta",
    "hs_tree_old_test_easy_4_1_meta",
    "hs_tree_old_test_easy_12_3_meta",
    "hs_tree_old_test_easier_12_3_meta",
    "scannet_large_hard_5_test",
    "scannet_large_easy_5_test",
    "scannet_large_easy_15_test",
    "scannet_large_easier_15_test"
]

def manifold_get_meta():

    for dataname in dataname_list_test:
        # makedir at /home/zgtang/{dataname}
        os.system(f"mkdir /home/zgtang/{dataname}")
        if not "hs_" in dataname:
            command = f"manifold --prod-use-cython-client getr --threads 2 --jobs 1000 ondevice_ai_writedata/tree/zgtang/dust3r/data/{dataname} /home/zgtang/{dataname}"
        else:
            command = f"manifold --prod-use-cython-client getr --threads 2 --jobs 1000 ondevice_ai_writedata/tree/zgtang/data/habitat_sim/{dataname} /home/zgtang/{dataname}"
        print(command)
        os.system(command)

def manifold_get_dps():

    for dataname in dataname_list:
        # makedir at /home/zgtang/{dataname}
        os.system(f"mkdir /home/zgtang/{dataname}")
        
        command = f"manifold --prod-use-cython-client get --threads 100 ondevice_ai_writedata/tree/zgtang/dust3r/data/{dataname}/dps.h5 /home/zgtang/{dataname}/dps.h5"
        print(command)
        os.system(command)
        if os.path.exists(f"/home/zgtang/{dataname}/dps.h5"):
            print(f"downloaded {dataname} h5")
        else:
            command = f"manifold --prod-use-cython-client get --threads 100  ondevice_ai_writedata/tree/zgtang/dust3r/data/{dataname}/dps.json /home/zgtang/{dataname}/dps.json"
            print(command)
            os.system(command)
            if os.path.exists(f"/home/zgtang/{dataname}/dps.json"):
                print(f"downloaded {dataname} json")

    for dataname in dataname_list:
        if "hs_" in dataname:
            os.system(f"mv /home/zgtang/{dataname} /home/zgtang/{dataname[:-6]}_meta")

def get_and_split_dps():
    
    # command: python datasets_preprocess/get_scannet_list.py --data-name scannet_large_easier_12
    # for dataname in dataname_list2:
    for dataname in dataname_list_test:
        command = f"python get_scannet_list.py --data-name {dataname}"
        print(command)
        os.system(command)

def manifold_put_dps():
    from iopath.common.file_io import g_pathmgr
    filename_list = ['dps_train.h5', 'dps_test.h5', 'dps_train_sample.json', 'dps_test_sample.json']
    # for dataname in dataname_list2:
    for dataname in dataname_list_test:
        manifold_dataname = dataname
        if "_meta" in manifold_dataname:
            manifold_dataname = manifold_dataname[:-5]
        manifold_dataname += "_3.0"
        # mkdir at manifold: ondevice_ai_writedata/tree/zgtang/dust3r/data/{dataname}/
        g_pathmgr.mkdirs(f"manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/{manifold_dataname}/")
        for filename in filename_list:
            command = f"manifold --prod-use-cython-client put --threads 100 --overwrite /home/zgtang/{dataname}/{filename} ondevice_ai_writedata/tree/zgtang/dust3r/data/{manifold_dataname}/{filename}"
            print(command)
            os.system(command)
        
# get_train_data_list()
# manifold_get_dps()
get_and_split_dps()
# manifold_put_dps()
# manifold_get_meta()

'''TODO:
regerate test data for hm3d and scannet (length: 4, 12, 24, NVS with larger overlapping region)
    script done
    generating 4+1 easy for both
generate dps for all hs data, then train using it to see whether it helps the method.
generate or download dps of all data, then split to dps_train and dps_test 
write the code supporting for loading dps_train and dps_test, mix train, mix test. using same script to test whether we can reproduce when mixing is forced to be [8].
more evaluation: chamfer, relative cam pose, 0.3 accu. [first this to make sure we look good] [done except relative cam pose, left it later]
evaluation GO again. [first this to make sure we look good]
try mix training [4, 8]
need fix the code for training with bs=1
implement dust3r + heuristic GS baseline. may need the others to help me for more baselines like poseDiffusion, spanner3D.
maybe I should reimplement the dataloader
higher resolution finetuning

'''
