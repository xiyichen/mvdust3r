# pyre-strict
import logging
import typing as T

import numpy as np
import torch
from detectron2.data import Metadata
from detectron2.structures import Instances
from detectron2.utils.visualizer import ColorMode, Visualizer
from torch import Tensor


logger: logging.Logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def visualize_single_view_segmentation(
    image: np.ndarray,
    pred_classes: Tensor,
    pred_masks: Tensor,
    scores: Tensor,
    instance_score_thres: float,
    mask_score_thres: float,
    metadata: Metadata,
    scale: float = 1.0,
    visualization_font_size_scale: float = 1.0,
) -> np.ndarray:
    """
    Args:
        image: dtype: np.uint8, shape (H, W, C). value range [0, 255]
        pred_classes: dtype: torch.int32, shape (topk,)
        pred_masks: shape (topk, H, W), dtype: float32, value range [0, 1]
        scores: dtype: torch.float32, shape (topk,)
        instance_score_thres: per-instance confidence score threshold
        mask_score_thres: per-pixel mask confidence score threshold
        metadata: meta data of the dataset
        scale: scale factor to resize the original image
        visualization_font_size_scale: scale factor of font size in visualization
    Return:
        vis_image: dtype: np.uint8, shape (H, W, C)
    """
    image_size = (image.shape[0], image.shape[1])
    assert image_size == pred_masks.shape[1:]

    indices = scores >= instance_score_thres

    scores_str = ",".join([f"{x:.2f}" for x in scores.tolist()])
    logger.info(f"instance_score_thres {instance_score_thres}, scores {scores_str}")

    instances = Instances(image_size)
    instances.pred_classes = pred_classes[indices]
    instances.pred_masks = (pred_masks[indices] > mask_score_thres).float()
    instances.scores = scores[indices]

    logger.info(f"mask_score_thres {mask_score_thres}")
    logger.info(f"torch.sum(instances.pred_masks) {torch.sum(instances.pred_masks)}")

    indices = torch.argsort(instances.scores)
    instances = instances[indices]  # pyre-ignore

    v = Visualizer(
        image,
        metadata,
        scale=scale,
        instance_mode=ColorMode.SEGMENTATION,
        font_size_scale=visualization_font_size_scale,
    )
    # shape (H, W, 3), dtype np.uint8
    vis_image = v.draw_instance_predictions(
        instances.to("cpu"), jittering=False
    ).get_image()
    return vis_image


def visualize_stereo_segmentation(
    image: np.ndarray,
    pred_classes: T.Union[T.List[Tensor], Tensor],
    pred_masks: T.Union[T.List[Tensor], Tensor],
    scores: T.Union[T.List[Tensor], Tensor],
    instance_score_thres: float,
    mask_score_thres: float,
    metadata: Metadata,
    scale: float = 1.0,
    vis_input_image: bool = False,
    visualization_font_size_scale: float = 1.0,
) -> np.ndarray:
    """
    Args:
        image: dtype: np.uint8, shape (2, H, W, C). value range [0, 255]
        pred_classes: dtype: torch.int32, shape (2, topk)
        pred_masks: shape (2, topk, H, W), dtype: float32, value range [0, 1]
        scores: dtype: torch.float32, shape (2, topk)
        instance_score_thres: per-instance confidence score threshold
        mask_score_thres: per-pixel mask confidence score threshold
        metadata: meta data of the dataset
        scale: scale factor to resize the original image
        vis_input_image: if True, include input image in the visualization
        visualization_font_size_scale: scale factor of font size in visualization
    Return:
        vis_image: dtype: np.uint8, shape (H, 4*W, C) or (H, 2*W, C)
    """
    # shape (H, W, 3), dtype: np.uint8
    vis_image_left = visualize_single_view_segmentation(
        image[0],
        pred_classes[0],
        pred_masks[0],
        scores[0],
        instance_score_thres,
        mask_score_thres,
        metadata,
        scale=scale,
        visualization_font_size_scale=visualization_font_size_scale,
    )
    vis_image_right = visualize_single_view_segmentation(
        image[1],
        pred_classes[1],
        pred_masks[1],
        scores[1],
        instance_score_thres,
        mask_score_thres,
        metadata,
        scale=scale,
        visualization_font_size_scale=visualization_font_size_scale,
    )

    if vis_input_image:
        # dtype: np.uint8, shape (H, 4*W, C)
        vis_image = np.concatenate(
            [image[0], image[1], vis_image_left, vis_image_right], axis=1
        )
    else:
        # dtype: np.uint8, shape (H, 2*W, C)
        vis_image = np.concatenate([vis_image_left, vis_image_right], axis=1)
    return vis_image
