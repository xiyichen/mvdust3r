# pyre-strict
import io
import typing as T

import matplotlib.pyplot as plt

import numpy as np


def figure_to_numpy(figure: plt.Figure) -> np.ndarray:
    with io.BytesIO() as buffer:
        figure.savefig(buffer, format="raw")
        buffer.seek(0)
        data = np.frombuffer(buffer.getvalue(), dtype=np.uint8)
    w, h = figure.canvas.get_width_height()
    return data.reshape((int(h), int(w), -1))


def plot_figure_row_helper(
    figure_sequence: T.List[np.ndarray],
    label_sequence: T.List[str],
    model_id: str,
    model_name: T.Optional[str],
    display_plot: bool,
    # pyre-ignore
    color_range: T.Optional[T.List[T.Tuple[T.Any, ...]]] = None,
) -> np.ndarray:
    """
    Replicate the original impl (https://fburl.com/code/8gdx3l5m). This avoid depending on //ml4mr/ml4mr/utils:depth_vis_utils. Otherwise, we need to have libeva.so, which is often require to pack the python executable and libeva.so in the same fbpkg. However, we only build a python executable and do not have libeva.so available.
    """

    # Turn off interactive mode to have control over whether the plot will be displayed.
    plt.ioff()
    plt.style.use("seaborn-white")
    SMALL_SIZE = 34
    plt.rc("font", size=SMALL_SIZE)  # controls default text sizes
    plt.rc("axes", titlesize=SMALL_SIZE)  # fontsize of the axes title
    plt.rc("axes", labelsize=SMALL_SIZE)  # fontsize of the x and y labels
    plt.rc("xtick", labelsize=SMALL_SIZE)  # fontsize of the tick labels
    plt.rc("ytick", labelsize=SMALL_SIZE)  # fontsize of the tick labels
    plt.rc("legend", fontsize=SMALL_SIZE)  # legend fontsize
    plt.rc("figure", titlesize=SMALL_SIZE)
    nc = len(figure_sequence)
    fig, axs = plt.subplots(nrows=1, ncols=nc, figsize=(256 * nc // 16, 320 // 16))
    fig.tight_layout(h_pad=1.2, w_pad=2.5)
    if color_range is None:
        color_range = [(None, None)] * nc
    else:
        assert len(color_range) == nc
    for i, ax in enumerate(axs.flatten()):
        plt.sca(ax)
        vmin, vmax = color_range[i]
        plt.imshow(
            figure_sequence[i],
            cmap=plt.cm.jet if i > 1 else "gray",
            vmin=vmin,
            vmax=vmax,
        )
        plt.colorbar(fraction=0.046, pad=0.04)
        plt.title(label_sequence[i])
    model_title = f"Model {model_id}"
    if model_name is not None:
        model_title += f" - {model_name}"
    plt.suptitle(
        model_title,
        fontsize=52,
        verticalalignment="top",
        horizontalalignment="center",
        x=0.5,
        y=0.07,
    )

    plt.ion()
    if display_plot:
        plt.show()

    # Clear the plotting cache for future plt.show() calls.
    plt.close()
    return figure_to_numpy(fig)


def visualize_stereo_depth(
    model_id: str,
    model_name: T.Optional[str],
    input_images: np.ndarray,
    disparity_left: np.ndarray,
    disparity_right: np.ndarray,
    display_visualization: bool,
    # pyre-ignore
    color_range: T.Optional[T.List[T.Tuple[T.Any, ...]]] = None,
) -> np.ndarray:
    """
    Inputs:
        model_id: -
        model_name: -
        input_images: shape [2, H, W], dtype np.single
        disparity_left: shape [H, W], dtype np.single
        disparity_right: shape [H, W], dtype np.single
        display_visualization: -
        color_range: -
    Returns
        vis_image: shape (2000, 9600, 4), dtype: np.uint8
    """
    # shape (height, width)
    image_left = input_images[0, :, :]
    image_right = input_images[1, :, :]

    figures = [
        image_left,
        image_right,
        disparity_left,
        disparity_right,
    ]
    labels = [
        "Left image",
        "Right image",
        "Left predicted disparity",
        "Right predicted disparity",
    ]
    vis_image = plot_figure_row_helper(
        figures,
        labels,
        model_id,
        model_name,
        display_visualization,
        color_range=color_range,
    )
    return vis_image
