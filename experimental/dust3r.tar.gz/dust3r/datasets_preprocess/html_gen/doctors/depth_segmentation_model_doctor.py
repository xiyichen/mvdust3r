# pyre-strict
import logging
import os
import typing as T
from time import perf_counter

import cv2

import numpy as np
import torch
import tqdm

# @manual=fbsource//arvr/python/xri_scene_data_utils:gt_format_utils
from arvr.python.xri_scene_data_utils.gt_format_utils import StreamName
from fblearner.flow.facebook.fbpackage import FbPackage
from iopath.common.file_io import PathManager
from iopath.fb.manifold import ManifoldPathHandler
from PIL import Image
from torch import Tensor
from torch.nn import functional as F

from ..datasets.base_dataset import BaseDataset
from ..visualization.ffmpeg import assemble_frames_into_video
from ..visualization.vis_depth import visualize_stereo_depth
from ..visualization.vis_segmentation import visualize_stereo_segmentation

from .base_model_doctor import BaseModelDoctor
from .utils import (
    load_mld_preprocess_data_file,
    run_data_dumper,
    SEGM_DEFAULT_INSTANCE_SCORE_THRESHOLD,
    SEGM_DEFAULT_MASK_SCORE_THRESHOLD,
)

# pyre-ignore
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

pathmgr = PathManager()
pathmgr.register_handler(ManifoldPathHandler())


STREAM_NAMES_TO_USE: T.Set[StreamName] = {
    StreamName.RECORDING,
}


class DepthSegmentationModelDoctor(BaseModelDoctor):
    """
    This doctor checks if the depth segmentation model predicts diparity map and segmentation masks well.
    """

    def __init__(
        self, doctor_config: T.Dict, model_config: T.Dict, dataset: BaseDataset, manifold_output_dir: str  # pyre-ignore
    ) -> None:
        super().__init__(doctor_config, model_config, dataset, manifold_output_dir)
        self.device: str = dataset.config.get("device", "arcata")
        self.build_app_depth_pipeline: bool = bool(
            self.config.get("build_app_depth_pipeline", False)
        )

        jef_cherry_plvrs_process_binary_pkg: FbPackage = FbPackage(
            "jef.cherry_plvrs_process_binary"
        )
        self.app_depth_pipeline_bin: str = os.path.join(
            jef_cherry_plvrs_process_binary_pkg.package_path, "app_depth_pipeline"
        )

    def run_data_dumper(self, recording_id: str) -> T.Optional[T.Dict[str, T.Any]]:
        data_dumper_work_dir = os.path.join(
            self.work_dir, "data_dumper", f"{recording_id}"
        )
        os.makedirs(data_dumper_work_dir, exist_ok=True)
        frame_type = 0
        do_image_binning = self.dataset.config.get("image_binning", True)
        pyramid_level = self.dataset.config.get("pyramid_level", 1)
        debug = True

        results = run_data_dumper(
            int(recording_id),
            data_dumper_work_dir,
            self.device,
            frame_type,
            do_image_binning,
            pyramid_level,
            debug,
            app_depth_pipeline_bin=self.app_depth_pipeline_bin,
            build_app_depth_pipeline=self.build_app_depth_pipeline,
        )
        return results

    def transform_segm_outputs(
        self, outputs: T.Dict[str, Tensor]
    ) -> T.Tuple[Tensor, Tensor, Tensor]:
        """
        Transform the segmentation outputs to the format that is compatible with the stereo semantics model.
        """
        compact_output_mask = bool(self.model_config.get("compact_output_mask", 0))
        if not compact_output_mask:
            # shape (2, topk), dtype torch.float32
            segm_pred_classes = outputs["segm_pred_classes"].detach().cpu()
            # shape (2, topk, H_k, W_j), dtype torch.float32 or torch.uint8
            segm_pred_masks = outputs["segm_pred_masks"].detach().cpu().float()
            # shape (2, topk), dtype torch.float32
            segm_mask_scores = outputs["segm_mask_scores"].detach().cpu()
        else:
            # shape (2, topk), dtype torch.float32
            segm_classes = outputs["segm_classes"].detach().cpu()
            # shape (2, H_j, W_j), dtype torch.float32 or torch.uint8
            segm_mask_confidence = (
                outputs["segm_mask_confidence"].detach().cpu().float()
            )
            logger.info(
                f"torch.mean(segm_mask_confidence) {torch.mean(segm_mask_confidence)}"
            )

            # shape (2, H_j, W_j), dtype torch.float32
            segm_instance_map = outputs["segm_instance_map"].detach().cpu()
            # shape (2, topk), dtype torch.float32
            segm_scores = outputs["segm_scores"].detach().cpu()

            unique_segm_inst_id = torch.unique(segm_instance_map)
            logger.info(f"before rounding, unique_segm_inst_id {unique_segm_inst_id}")
            # Due to quantization, instance ID, which has dtype float32 and ideally has integer value, could be either a bit smaller or a bit larger than the integer value. It is key to round it to the nearest integer.
            segm_instance_map = torch.floor(segm_instance_map + 0.5).to(torch.int32)

            unique_segm_inst_id = torch.unique(segm_instance_map)
            logger.info(f"after rounding, unique_segm_inst_id {unique_segm_inst_id}")

            topk = segm_classes.shape[1]
            h, w = segm_mask_confidence.shape[1:]

            segm_pred_classes = torch.zeros(2, topk)
            segm_pred_masks = torch.zeros(2, topk, h, w)
            segm_mask_scores = torch.zeros(2, topk)

            for view in range(2):
                inst_ids = torch.unique(segm_instance_map[view])
                inst_index = 0
                for inst_id in sorted(inst_ids.tolist()):
                    if inst_id == 0:
                        continue

                    score = segm_scores[view, inst_id - 1]
                    class_id = segm_classes[view, inst_id - 1]
                    logger.info(
                        f"view {view}, inst_id {inst_id}, score {score:.2f}, class_id {class_id}"
                    )

                    segm_pred_classes[view, inst_index] = class_id
                    # shape (h, w)
                    inst_mask = segm_mask_confidence[view] * (
                        (segm_instance_map[view] == inst_id).float()
                    )

                    segm_pred_masks[view, inst_index] = inst_mask
                    segm_mask_scores[view, inst_index] = score

                    inst_index += 1

        return segm_pred_classes, segm_pred_masks, segm_mask_scores

    def filter_instances(
        self,
        allowlist_segm_categories: T.List[str],
        segm_mask_scores: Tensor,
        segm_pred_classes: Tensor,
        segm_pred_masks: Tensor,
    ) -> T.Tuple[Tensor, Tensor, Tensor]:
        """
        Inputs:
            allowlist_segm_categories: a list of segmentation categories that we want to keep
            segm_mask_scores: shape (topk), dtype torch.float32
            segm_pred_classes: shape (topk), dtype torch.float32
            segm_pred_masks: shape (topk, H_j, W_j), dtype torch.float32
        """
        idx_to_cat_name = {
            idx: cat_name
            for idx, cat_name in enumerate(self.model.segm_metadata.thing_classes)
            if cat_name in allowlist_segm_categories
        }

        segm_pred_classes = segm_pred_classes.to(torch.int32)
        filtered_segm_mask_scores = []
        filtered_segm_pred_classes = []
        filtered_segm_pred_masks = []
        for i in range(segm_pred_classes.shape[0]):
            if segm_pred_classes[i].item() in idx_to_cat_name:
                filtered_segm_mask_scores.append(segm_mask_scores[i])
                filtered_segm_pred_classes.append(segm_pred_classes[i])
                filtered_segm_pred_masks.append(segm_pred_masks[i])

        if len(filtered_segm_mask_scores) > 0:
            filtered_segm_mask_scores = torch.stack(filtered_segm_mask_scores)
            filtered_segm_pred_classes = torch.stack(filtered_segm_pred_classes)
            filtered_segm_pred_masks = torch.stack(filtered_segm_pred_masks)
        else:
            filtered_segm_mask_scores = torch.zeros(0)
            filtered_segm_pred_classes = torch.zeros(0)
            filtered_segm_pred_masks = torch.zeros(
                0, segm_pred_masks.shape[1], segm_pred_masks.shape[2]
            )

        logger.info(
            f"# of instance after filtering by allowlist of segm categories {len(filtered_segm_mask_scores)}"
        )

        return (
            filtered_segm_mask_scores,
            filtered_segm_pred_classes,
            filtered_segm_pred_masks,
        )

    def visualize_model_outputs(
        self, inputs: T.Dict[str, Tensor], outputs: T.Dict[str, Tensor]
    ) -> np.ndarray:
        # shape (1, 2, H, W)
        disparity = outputs["disparity"].detach().cpu()
        H, W = disparity.shape[-2:]

        segm_pred_classes, segm_pred_masks, segm_mask_scores = (
            self.transform_segm_outputs(outputs)
        )
        # shape (2, topk)
        segm_pred_classes = segm_pred_classes.to(torch.int32)
        # shape (2, topk, H_j, W_j)
        segm_pred_masks = segm_pred_masks / 255.0
        if not (segm_pred_masks.shape[2] == H and segm_pred_masks.shape[3] == W):
            logger.debug(
                f"segm_pred_masks, shape {segm_pred_masks.shape}. Need upsampling"
            )
            # upsample predicted mask
            segm_pred_masks = F.interpolate(
                segm_pred_masks,
                size=(H, W),
                mode="bilinear",
                align_corners=False,
            )

        # sort predicted segmentation instances by score in each view (i.e. left/right view)
        for i in range(2):
            scores, indices = torch.sort(segm_mask_scores[i])
            segm_mask_scores[i] = scores
            segm_pred_classes[i] = segm_pred_classes[i][indices]
            segm_pred_masks[i] = segm_pred_masks[i][indices]

        if self.dataset.config.get("allowlist_segm_categories", None) is not None:
            segm_mask_scores_filtered_list = []
            segm_pred_classes_filtered_list = []
            segm_pred_masks_filtered_list = []
            for i in range(2):
                (
                    segm_mask_scores_filtered,
                    segm_pred_classes_filtered,
                    segm_pred_masks_filtered,
                ) = self.filter_instances(
                    self.dataset.config["allowlist_segm_categories"],
                    segm_mask_scores[i],
                    segm_pred_classes[i],
                    segm_pred_masks[i],
                )

                segm_mask_scores_filtered_list.append(segm_mask_scores_filtered)
                segm_pred_classes_filtered_list.append(segm_pred_classes_filtered)
                segm_pred_masks_filtered_list.append(segm_pred_masks_filtered)

            segm_mask_scores = segm_mask_scores_filtered_list
            segm_pred_classes = segm_pred_classes_filtered_list
            segm_pred_masks = segm_pred_masks_filtered_list

        # shape (2, H, W), dtype: np.single
        input_images = torch.stack(
            [inputs["frame_left"], inputs["frame_right"]]
        ).numpy()
        depth_disparity_left = disparity.numpy()[0, 0]
        depth_disparity_right = disparity.numpy()[0, 1]

        ## Color range for uniform color range across all visualizations
        color_range = [
            (None, None),  # "Left image",
            (None, None),  # "Right image",
            (0, 50),  # "Left predicted disparity",
            (0, 50),  # "Right predicted disparity",
        ]

        # shape (2000, 9600, 4), dtype: np.uint8
        depth_vis_image = visualize_stereo_depth(
            self.model.config.get("name", "unnamed_model"),
            self.model.config.get("id", ""),
            input_images,
            depth_disparity_left,
            depth_disparity_right,
            display_visualization=False,
            color_range=color_range,
        )
        logger.debug(
            f"depth_vis_image, shape {depth_vis_image.shape}, dtype {depth_vis_image.dtype}"
        )

        # shape (2, H, W), value range [0, 255]
        input_tensor = torch.stack([inputs["frame_left"], inputs["frame_right"]]).to(
            torch.uint8
        )

        # shape (H, W * 2, 3) =  (320, 512, 3), dtype uint8
        segm_vis_image = visualize_stereo_segmentation(
            input_tensor.unsqueeze(3).repeat(1, 1, 1, 3).numpy(),
            segm_pred_classes,
            segm_pred_masks,
            segm_mask_scores,
            self.config.get(
                "instance_score_thres", SEGM_DEFAULT_INSTANCE_SCORE_THRESHOLD
            ),
            self.config.get("mask_score_thres", SEGM_DEFAULT_MASK_SCORE_THRESHOLD),
            self.model.segm_metadata,
            visualization_font_size_scale=self.vis_font_size_scale,
        )

        pad = 40
        # shape (320 + 80, 512 + 80, 3) = (400, 592, 3)
        segm_vis_image_padded = (
            np.ones(
                (
                    segm_vis_image.shape[0] + 2 * pad,
                    segm_vis_image.shape[1] + 2 * pad,
                    3,
                ),
                dtype=np.float32,
            )
            * 255.0
        )
        segm_vis_image_padded = segm_vis_image_padded.astype(np.uint8)
        segm_vis_image_padded[pad:-pad, pad:-pad, :] = segm_vis_image

        # downscale depth_vis_image, concatenate with segm_vis_image
        scaled_h = segm_vis_image_padded.shape[0] * 2
        scaling = float(scaled_h) / depth_vis_image.shape[0]
        depth_vis_image_scaled_width = int(depth_vis_image.shape[1] * scaling)
        depth_vis_image_scaled = cv2.resize(
            depth_vis_image,
            (depth_vis_image_scaled_width, scaled_h),
            interpolation=cv2.INTER_LINEAR,
        )
        logger.debug(
            f"depth_vis_image_scaled, shape {depth_vis_image_scaled.shape}, dtype {depth_vis_image_scaled.dtype}"
        )

        # shape (800, 1184, 3)
        segm_vis_image_padded_scaled = cv2.resize(
            segm_vis_image_padded,
            (
                segm_vis_image_padded.shape[1] * 2,
                segm_vis_image_padded.shape[0] * 2,
            ),
            interpolation=cv2.INTER_LINEAR,
        )
        logger.debug(
            f"segm_vis_image_padded_scaled, shape {segm_vis_image_padded_scaled.shape}, dtype {segm_vis_image_padded_scaled.dtype}"
        )

        depth_segm_vis_image = np.concatenate(
            [depth_vis_image_scaled[:, :, :3], segm_vis_image_padded_scaled], axis=1
        )

        logger.debug(
            f"depth_segm_vis_image, shape {depth_segm_vis_image.shape}, dtype {depth_segm_vis_image.dtype}"
        )

        return depth_segm_vis_image

    def run_model_inference(
        self,
        recording_id: int,
        data_dumper_results: T.Dict[str, T.Any],
        manifold_vis_recording_dir: str,
    ) -> None:
        vis_recording_dir = self._get_local_vis_recording_dir(recording_id)
        im_files = data_dumper_results["im_files"]
        for im_file in tqdm.tqdm(im_files):
            # im_file: $ROOT_DIR/data_dumper/$RECORDING_ID/$TIMESTAMP_INDEX.bin
            # such as /tmp/DepthSegmentationModelDoctor_5526602b7f804a1da03a1bdf8a87b714/data_dumper/1000765597883812/00000000.bin
            logger.info(f"im_file: {im_file}")
            frame_height = self.dataset.config.get("orig_frame_height", 320)
            frame_width = self.dataset.config.get("orig_frame_width", 256)
            # np.ndarray, shape (2, H, W), dtype np.single
            frame_data = load_mld_preprocess_data_file(
                im_file, frame_height, frame_width
            )
            logger.debug(
                f"frame_data, shape {frame_data.shape}, dtype {frame_data.dtype}"
            )
            # torch.Tensor, shape (2, H, W), dtype torch.float
            frame_data = torch.from_numpy(frame_data)
            model_inputs = {"frame_left": frame_data[0], "frame_right": frame_data[1]}
            model_outputs = self.model.run_model(model_inputs)

            depth_segm_vis_image = self.visualize_model_outputs(
                model_inputs, model_outputs
            )

            timestamp_idx = os.path.basename(im_file).split(".")[0]

            im = Image.fromarray(depth_segm_vis_image)
            im_path = os.path.join(vis_recording_dir, f"{timestamp_idx}.png")
            im.save(im_path)
            logger.info(f"save depth segm vis image locally: {im_path}")

            if self.debug:
                manifold_im_path = os.path.join(
                    manifold_vis_recording_dir, f"{timestamp_idx}.png"
                )
                pathmgr.copy_from_local(im_path, manifold_im_path, overwrite=True)

                logger.info(f"Saved visualization image to {manifold_im_path}")

    def encode_model_prediction_vis_video(
        self, dataset_dict: T.Dict[str, T.Any], manifold_vis_dir: str
    ) -> None:
        """
        Generate a video of the model prediction visualizations. Upload it to manifold
        """
        recording_id = dataset_dict["recording_id"]
        vis_recording_dir = self._get_local_vis_recording_dir(recording_id)
        fps = self.dataset.config.get("fps", 30)

        generated_video_path = assemble_frames_into_video(
            vis_recording_dir,
            manifold_vis_dir,
            f"{recording_id}_model_pred.mp4",
            fps,
        )
        self.generated_video_paths.append(generated_video_path)

    # pyre-ignore
    def process_dataset_item(self, dataset_dict: T.Dict[str, T.Any]):
        recording_id = dataset_dict["recording_id"]
        manifold_vis_recording_dir = os.path.join(
            self.manifold_vis_dir, "recordings", str(recording_id)
        )
        pathmgr.mkdirs(manifold_vis_recording_dir)

        time_start = perf_counter()
        logger.info("run_data_dumper() starts")
        results = self.run_data_dumper(recording_id)
        elapsed_time = perf_counter() - time_start
        logger.info(f"run_data_dumper(). Total time (secs): {elapsed_time:.2f}")

        if results is None:
            logger.warning(f"No data dumper results found for recording {recording_id}")
            return

        time_start = perf_counter()
        self.run_model_inference(recording_id, results, manifold_vis_recording_dir)
        elapsed_time = perf_counter() - time_start
        logger.info(f"run_model_inference(). Total time (secs): {elapsed_time:.2f}")

        manifold_vis_video_dir = os.path.join(self.manifold_vis_dir, "vis_videos")
        pathmgr.mkdirs(manifold_vis_video_dir)

        self.encode_model_prediction_vis_video(dataset_dict, manifold_vis_video_dir)
