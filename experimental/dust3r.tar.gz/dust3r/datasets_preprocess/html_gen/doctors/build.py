# pyre-strict
import typing as T

from ..datasets.base_dataset import BaseDataset

from .base_model_doctor import BaseModelDoctor

from .depth_segmentation_model_doctor import DepthSegmentationModelDoctor
from .mask2former_model_doctor import Mask2FormerModelDoctor

# Manually register the datasets below. Sort model doctor classes alphabetically
model_doctor_register = {
    "DepthSegmentationModelDoctor": DepthSegmentationModelDoctor,
    "Mask2FormerModelDoctor": Mask2FormerModelDoctor,
}


def build_model_doctor(
    doctor_config: T.Dict[str, T.Any],
    model_config: T.Dict[str, T.Any],
    dataset: BaseDataset,
    manifold_output_dir: str,
) -> BaseModelDoctor:
    doctor_class = doctor_config["class"]
    assert (
        doctor_class in model_doctor_register
    ), f"model doctor class {doctor_class} is not supported."
    return model_doctor_register[doctor_class](
        doctor_config, model_config, dataset, manifold_output_dir
    )
