# pyre-strict
import logging
import os
import shutil
import typing as T
import uuid

from iopath.common.file_io import PathManager
from iopath.fb.manifold import ManifoldPathHandler
from mobile_cv.torch.utils_pytorch import comm

from ..datasets.base_dataset import BaseDataset
from ..models.build import build_model
from .utils import get_manifold_vis_dir, model_description

pathmgr = PathManager()
pathmgr.register_handler(ManifoldPathHandler())

# pyre-ignore
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class BaseModelDoctor:
    def __init__(
        self, doctor_config: T.Dict, model_config: T.Dict, dataset: BaseDataset, manifold_output_dir: str  # pyre-ignore
    ) -> None:
        self.config = doctor_config  # pyre-ignore
        self.model_config = model_config
        self.dataset = dataset
        self.setup_working_dir()
        self.setup_model()
        self.setup_manifold_output_dir(manifold_output_dir)
        self.setup_vis_dir()
        self.debug: bool = self.config.get("debug", False)
        self.vis_font_size_scale: float = self.config.get(
            "visualization_font_size_scale", 1.0
        )
        self.generated_video_paths: T.List[str] = []

    def setup_working_dir(self) -> None:
        rank = comm.get_rank()
        assert "name" in self.model_config, "name not found in config"
        model_name = self.model_config["name"]
        model_id = self.model_config.get("id", "default_id")
        self.model_desc = model_description(model_name, model_id)
        self.work_dir: str = os.path.join(
            "/tmp",
            f"{self.__class__.__name__}_{str(uuid.uuid4().hex)}",
            f"{self.dataset.name}",
            f"{self.model_desc}",
            f"rank_{rank}",
        )
        logger.info(
            f"{self.__class__.__name__}, rank {rank}, work_dir: {self.work_dir}"
        )
        os.makedirs(self.work_dir, exist_ok=True)

    def setup_vis_dir(self) -> None:
        self.vis_dir: str = os.path.join(self.work_dir, "vis")
        os.makedirs(self.vis_dir, exist_ok=True)

        self.manifold_vis_dir: str = get_manifold_vis_dir(self.manifold_output_dir)
        pathmgr.mkdirs(self.manifold_vis_dir)

    def setup_manifold_output_dir(self, manifold_output_dir: str) -> None:
        self.manifold_output_dir: str = os.path.join(
            manifold_output_dir, self.dataset.name, self.model_desc
        )
        pathmgr.mkdirs(self.manifold_output_dir)
        logger.info(f"manifold output dir: {self.manifold_output_dir}")

    def setup_model(self) -> None:
        self.model = build_model(
            self.model_config["model_class"], self.model_config, self.work_dir
        )

    def _get_local_vis_recording_dir(self, recording_id: int) -> str:
        vis_recording_dir = os.path.join(self.vis_dir, str(recording_id))
        os.makedirs(vis_recording_dir, exist_ok=True)
        return vis_recording_dir

    # pyre-ignore
    def process_dataset_item(self, dataset_dict: T.Dict[str, T.Any]):
        """
        Overload this function to implement custom processing of a single item from the dataset
        """
        raise NotImplementedError

    def build_summary_page(self) -> None:
        """
        Optionally, build a front-end web page to summarize the model doctor results
        """
        pass

    def run(self) -> None:
        global_rank = comm.get_rank()
        local_rank = comm.get_local_rank()

        for idx in range(len(self.dataset)):
            dataset_dict = self.dataset[idx]
            try:
                self.process_dataset_item(dataset_dict)
            except Exception as e:
                logger.error(
                    f"global_rank {global_rank}, local_rank {local_rank}, Failed to process item {idx} due to {e}"
                )

        self.build_summary_page()

        logger.info(f"manifold output dir: {self.manifold_output_dir}")

    def cleanup(self) -> None:
        self.model.cleanup()
        shutil.rmtree(self.work_dir)
