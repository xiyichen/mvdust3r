# pyre-strict
import logging
import os
import typing as T
from collections import defaultdict, OrderedDict

from concurrent.futures import Future, ThreadPoolExecutor
from time import perf_counter

import numpy as np
import torch
import tqdm

# @manual=fbsource//arvr/python/xri_scene_data_utils:data_provider_utils
from arvr.python.xri_scene_data_utils.data_provider_utils import (
    get_recording_metadata_from_live_gaia,
)

# @manual=fbsource//arvr/python/xri_scene_data_utils:gt_format_utils
from arvr.python.xri_scene_data_utils.gt_format_utils import (
    figure_out_data_provider,
    find_gt_from_recording,
    PoseProvider,
    select_vrs_gt_from_gaia_gts,
    StreamName,
    ValidPurpose,
)

# @manual=fbsource//arvr/python/xri_scene_data_utils:multi_vrs_reader
from arvr.python.xri_scene_data_utils.multi_vrs_reader import MultiVrsGtReader
from fblearner.flow.projects.xri_scene_data_pipeline.modular_pipeline.modules.sample_from_vrs import (
    build_image_from_records,
    get_factory_calibration,
    RecordingContext,
)
from fblearner.flow.projects.xri_scene_data_pipeline.modular_pipeline.modules.transform import (
    registered_transformations,
    run_image_transform,
    Transformation,
    ValidTransformation,
)
from fblearner.flow.projects.xri_scene_data_pipeline.modular_pipeline.types.data_types import (
    Image,
)
from fblearner.flow.projects.xri_scene_data_pipeline.modular_pipeline.utils import (
    DummyExecutor,
)
from iopath.common.file_io import PathManager
from iopath.fb.manifold import ManifoldPathHandler
from PIL import Image as PILImage

from torch import Tensor
from torch.nn import functional as F

from ..datasets.base_dataset import BaseDataset
from ..visualization.ffmpeg import assemble_frames_into_video

from ..visualization.vis_segmentation import visualize_single_view_segmentation
from .base_model_doctor import BaseModelDoctor
from .utils import (
    parse_image_id,
    SEGM_DEFAULT_INSTANCE_SCORE_THRESHOLD,
    SEGM_DEFAULT_MASK_SCORE_THRESHOLD,
)

# pyre-ignore
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

pathmgr = PathManager()
pathmgr.register_handler(ManifoldPathHandler())

PURPOSE = ValidPurpose("slam")
CAMERA_ID = 0
SAMPLE_FREQUENCY = 30

STREAM_NAMES_TO_USE: T.Set[StreamName] = {
    StreamName.RECORDING,
    # StreamName.DEPTH,
}


class Mask2FormerModelDoctor(BaseModelDoctor):
    """
    This doctor checks if the Mask2Former segmentation model predicts instance segmentation masks well.
    """

    def __init__(
        self, doctor_config: T.Dict, model_config: T.Dict, dataset: BaseDataset, manifold_output_dir: str  # pyre-ignore
    ) -> None:
        super().__init__(doctor_config, model_config, dataset, manifold_output_dir)
        self.num_threads: int = self.config.get("num_threads", 1)

    def sample_from_vrs(self, recording_id: int) -> T.List[Image]:
        """
        Adapted impl from original impl in modular_pipeline (https://fburl.com/code/hglz0qh7)
        """
        recording_metadata = get_recording_metadata_from_live_gaia(recording_id)
        data_provider = figure_out_data_provider(recording_metadata)
        logger.debug(f"data_provider: {data_provider}")

        gt_type_to_gaia_id = find_gt_from_recording(recording_metadata)
        stream_name_to_vrs_path = select_vrs_gt_from_gaia_gts(
            gt_type_to_gaia_id, recording_metadata
        )

        logger.debug("stream_name_to_vrs_path")
        for stream_name, vrs_path in stream_name_to_vrs_path.items():
            logger.debug(f"stream_name {stream_name}, vrs_path {vrs_path}")

        stream_names_to_use = {k.name for k in STREAM_NAMES_TO_USE}
        stream_name_to_vrs_path = {
            k: v
            for k, v in stream_name_to_vrs_path.items()
            if k.name in stream_names_to_use
        }

        camera_id = CAMERA_ID
        purpose = PURPOSE
        factory_intrinsics = get_factory_calibration(recording_id, camera_id)

        try:
            logger.debug(f"Getting PoseProvider for {recording_id}..")
            pose_provider = PoseProvider(recording_metadata)
        except Exception:
            logger.warning(
                f"Error spawning pose_provider or MultiVrsGtReader for gaia:{recording_id}."
            )
            pose_provider = None

        sampling_frequency = self.dataset.config.get("sampling_frequency", -1)
        if sampling_frequency < 0:
            sampling_frequency = None

        max_samples = self.dataset.config.get("max_samples_per_recordings", 0)
        if max_samples < 1:
            max_samples = None

        logger.debug(f"Getting MultiVrsGtReader for {recording_id}..")
        reader = MultiVrsGtReader(
            stream_name_to_vrs_path=stream_name_to_vrs_path,
            camera_id=camera_id,
            data_provider=data_provider,
            purpose=purpose,
            max_samples=max_samples,
            sampling_frequency=sampling_frequency,
        )

        frame_data_dir = os.path.join(self.work_dir, "frame_data")
        os.makedirs(frame_data_dir, exist_ok=True)
        logger.debug(f"frame_data_dir: {frame_data_dir}")

        recording_ctx: RecordingContext = RecordingContext(
            recording_id=recording_id,
            pose_provider=pose_provider,
            gaia_annotations=None,
            category_id_map=None,
            instance_id_map={},
            journey_dict=None,
            limitFOVmask=None,
            vlx_pointcloud=None,
            taxonomy=None,
        )

        num_threads = min(self.num_threads, len(reader))
        executor_type = ThreadPoolExecutor if num_threads > 1 else DummyExecutor
        logger.info(f"Starting {executor_type.__name__} with {num_threads} threads")
        with executor_type(num_threads) as executor:
            image_futures = []
            images = []
            for records in reader:
                image_futures.append(
                    executor.submit(
                        build_image_from_records,
                        recording_ctx,
                        records,
                        camera_id,
                        recording_id,
                        frame_data_dir,
                    )
                )

            for image_future in image_futures:
                image = image_future.result()
                if image is not None:
                    if not image._intrinsics:
                        logger.debug(
                            "per-frame online calibration is missing. Use factory calibration"
                        )
                        image._intrinsics = factory_intrinsics
                    # image: np.ndarray, shape (H, W), dtype np.uint8
                    frame_height = self.dataset.config.get("orig_frame_height", 1024)
                    frame_width = self.dataset.config.get("orig_frame_width", 1280)
                    assert (
                        image.bitmap.height == frame_height
                    ), f"loaded frame height mismatch. Expected: {frame_height}. Actual: {image.bitmap.height}"
                    assert (
                        image.bitmap.width == frame_width
                    ), f"loaded frame width mismatch. Expected: {frame_width}. Actual: {image.bitmap.width}"
                    images.append(image)

        return images

    def get_manifold_output_original_frames_dir(
        self, recording_id: str, stream_id: str
    ) -> str:
        output_dir = os.path.join(
            self.manifold_output_dir, "frames_original", recording_id, stream_id
        )
        pathmgr.mkdirs(output_dir)
        return output_dir

    def get_manifold_output_images_transformed_dir(
        self, recording_id: str, stream_id: str
    ) -> str:
        output_dir = os.path.join(
            self.manifold_output_dir, "frame_transformed", recording_id, stream_id
        )
        pathmgr.mkdirs(output_dir)
        return output_dir

    def upload_original_frames_to_manifold(self, images: T.List[Image]) -> None:
        # images are already sorted by timestamp in ascending order
        # Often images are from the same stream id. However, with separate NICE slots, we will have up to two streams per camera-purpose
        # https://www.internalfb.com/intern/wiki/RL/XR_Tech/Core_Libraries/visiontypes_Library/Separated_time_sharing_slots/
        stream_id_to_idx = defaultdict(lambda: 0)
        for image in images:
            # image_id is f"{recording_id}/{timestamp}/{stream_id}"
            logger.info(f"image.bitmap.path {image.bitmap.path}")
            recording_id, _timestamp, stream_id = parse_image_id(image)

            idx = stream_id_to_idx[stream_id]
            stream_id_to_idx[stream_id] += 1

            # In manifold, we store transformed frames as f"{recording_id}/{stream_id}/{frame_idx:%08d}.png"
            manifold_output_dir = self.get_manifold_output_original_frames_dir(
                recording_id,
                stream_id,
            )
            manifold_output_path = os.path.join(manifold_output_dir, f"{idx:08d}.png")
            pathmgr.copy_from_local(
                image.bitmap.path, manifold_output_path, overwrite=True  # pyre-ignore
            )
            logger.info(f"upload original frame to manifold: {manifold_output_path}")

    def upload_images_transformed_to_manifold(self, images: T.List[Image]) -> None:
        # images are already sorted by timestamp in ascending order
        # Often images are from the same stream id. However, with separate NICE slots, we will have up to two streams per camera-purpose
        # https://www.internalfb.com/intern/wiki/RL/XR_Tech/Core_Libraries/visiontypes_Library/Separated_time_sharing_slots/
        stream_id_to_idx = defaultdict(lambda: 0)

        for image in images:
            # image_id is f"{recording_id}/{timestamp}/{stream_id}"
            logger.info(f"image.bitmap.path {image.bitmap.path}")
            recording_id, _timestamp, stream_id = parse_image_id(image)

            idx = stream_id_to_idx[stream_id]
            stream_id_to_idx[stream_id] += 1

            # In manifold, we store transformed frames as f"{recording_id}/{stream_id}/{frame_idx:%08d}.png"
            manifold_output_dir = self.get_manifold_output_images_transformed_dir(
                recording_id,
                stream_id,
            )
            manifold_output_path = os.path.join(manifold_output_dir, f"{idx:08d}.png")
            pathmgr.copy_from_local(
                image.bitmap.path, manifold_output_path, overwrite=True  # pyre-ignore
            )
            logger.info(f"upload transformed frame to manifold: {manifold_output_path}")

    def transform_frames(self, images: T.List[Image]) -> T.List[Image]:
        """
        Adapted impl from original impl in modular_pipeline (https://fburl.com/code/a6gd3zs6)
        """
        config_transformations = self.dataset.config.get("transformations", [])
        valid_transformations: T.List[str] = [
            transform.value for transform in registered_transformations
        ]
        active_transformations: T.List[Transformation] = []
        for transformation in config_transformations:
            if transformation not in valid_transformations:
                raise ValueError(
                    f"Unknown transformation {transformation}. Valid are: {valid_transformations}"
                )
            valid_transformation = ValidTransformation(transformation)
            active_transformations.append(
                registered_transformations[valid_transformation]
            )

        frame_data_transformed_dir = os.path.join(
            self.work_dir, "frame_data_transformed"
        )
        os.makedirs(frame_data_transformed_dir, exist_ok=True)

        num_threads = min(self.num_threads, len(images))
        executor_type = ThreadPoolExecutor if num_threads > 1 else DummyExecutor
        with executor_type(num_threads) as executor:
            image_futures: T.List[Future] = []
            images_transformed: T.List[Image] = []
            logger.info(f"transform {len(images)} images with {num_threads} threads.")

            for image in images:
                image_futures.append(
                    executor.submit(
                        run_image_transform,
                        image,
                        active_transformations,
                        frame_data_transformed_dir,
                    )
                )

            for image_future in image_futures:
                image = image_future.result()
                if image is not None:
                    images_transformed.append(image)

        return images_transformed

    def filter_frames_by_stream_ids(
        self, images: T.List[Image], target_stream_id: T.Optional[str]
    ) -> T.List[Image]:
        """
        Often images are from the same stream id. However, with separate NICE slots, we will have up to two streams per camera-purpose
        https://www.internalfb.com/intern/wiki/RL/XR_Tech/Core_Libraries/visiontypes_Library/Separated_time_sharing_slots/
        Therefore, if needed, we filter images by stream id
        """
        if target_stream_id is None:
            return images
        logger.info(f"filter frames by stream id {target_stream_id}")
        filtered_frames = []
        for image in images:
            _recording_id, _timestamp, stream_id = parse_image_id(image)
            if stream_id == target_stream_id:
                filtered_frames.append(image)
        return filtered_frames

    def extract_recording_frames(self, recording_id: int) -> T.List[Image]:
        images = self.sample_from_vrs(recording_id)
        images = self.filter_frames_by_stream_ids(
            images, self.dataset.config.get("stream_id", None)
        )
        if self.debug:
            self.upload_original_frames_to_manifold(images)

        time_start = perf_counter()
        transformed_images = self.transform_frames(images)
        elapsed_time = perf_counter() - time_start
        logger.info(f"transform frames. Total time (secs): {elapsed_time:.2f}")

        if self.debug:
            self.upload_images_transformed_to_manifold(transformed_images)
        return transformed_images

    def transform_model_outputs(
        self, model_outputs: OrderedDict[str, Tensor]
    ) -> T.Tuple[Tensor, Tensor, Tensor]:
        compact_output_mask = bool(self.model_config.get("compact_output_mask", 0))
        if compact_output_mask:
            classes = model_outputs["classes"].detach().cpu()
            # dtype is torch.float32 (for torchscript model) or torch.uint8 (for boltnn model). So need float() to convert it to torch.float32 if needed
            mask_conf = model_outputs["mask_confidence"].detach().cpu().float()
            instance_map = model_outputs["instance_map"].detach().cpu()
            scores = model_outputs["scores"].detach().cpu()

            logger.info(f"mean mask_conf {torch.mean(mask_conf)}")

            unique_inst_id = torch.unique(instance_map)
            logger.info(f"before rounding, unique_inst_id {unique_inst_id}")
            # Due to quantization, instance ID, which has dtype float32 and ideally has integer value, could be either a bit smaller or a bit larger than the integer value. It is key to round it to the nearest integer.
            instance_map = torch.floor(instance_map + 0.5).to(torch.int32)
            unique_inst_id = torch.unique(instance_map)
            logger.info(f"after rounding, unique_inst_id {unique_inst_id}")

            # Due to quantization, class ID, which has dtype float32 and ideally has integer value, could be either a bit smaller or a bit larger than the integer value. It is key to round it to the nearest integer.
            logger.info(f"before rounding, classes {classes}")
            classes = torch.floor(classes + 0.5).to(torch.int32)
            logger.info(f"after rounding, classes {classes}")

            topk = classes.shape[0]
            h, w = mask_conf.shape
            logger.info(f"mask_conf.shape {mask_conf.shape}")

            pred_classes = torch.zeros(topk)
            pred_masks = torch.zeros(topk, h, w)
            pred_scores = torch.zeros(topk)

            inst_index = 0
            for inst_id in sorted(unique_inst_id.tolist()):
                if inst_id == 0:
                    continue

                score = scores[inst_id - 1]
                class_id = classes[inst_id - 1]
                logger.info(
                    f"inst_id {inst_id}, score {score:.2f}, class_id {class_id}"
                )

                pred_classes[inst_index] = class_id
                pred_masks[inst_index] = mask_conf * (instance_map == inst_id).float()
                pred_scores[inst_index] = score

                inst_index += 1
        else:
            pred_classes = model_outputs["pred_classes"].detach().cpu()
            logger.info(f"before rounding, pred_classes {pred_classes}")
            pred_classes = torch.floor(pred_classes + 0.5).to(torch.int32)
            logger.info(f"after rounding, pred_classes {pred_classes}")

            # dtype is torch.float32 (for torchscript model) or torch.uint8 (for boltnn model). So need float() to convert it to torch.float32 if needed
            pred_masks = model_outputs["pred_masks"].detach().cpu().float()
            logger.info(f"mean pred_masks {torch.mean(pred_masks)}")

            pred_scores = model_outputs["pred_scores"].detach().cpu()
            logger.info(f"pred_scores {pred_scores}")

        pred_classes = pred_classes.to(torch.int32)
        return pred_classes, pred_masks, pred_scores

    def visualize_model_outputs(
        self,
        model_inputs: OrderedDict[str, Tensor],
        model_outputs: OrderedDict[str, Tensor],
    ) -> np.ndarray:
        pred_classes, pred_masks, pred_scores = self.transform_model_outputs(
            model_outputs
        )

        # shape (H = 320, W = 256), dtype torch.uint8
        frame = model_inputs["frame"]
        H, W = frame.shape[-2:]
        # shape (topk, H / S, W / S)
        pred_masks = pred_masks / 255.0
        if not (H, W) == pred_masks.shape[-2:]:
            # shape (topk, H, W)
            pred_masks = F.interpolate(
                # pred_masks.expand(1, -1, -1, -1),
                pred_masks.unsqueeze(0),
                size=(H, W),
                mode="bilinear",
                align_corners=False,
            )[0]
        # shape (H, W, C = 3), dtype np.uint8
        frame_data = frame.unsqueeze(2).repeat(1, 1, 3).numpy()
        # shape (H, W, C = 3), dtype np.uint8
        semg_vis_image = visualize_single_view_segmentation(
            frame_data,
            pred_classes,
            pred_masks,
            pred_scores,
            self.config.get(
                "instance_score_thres", SEGM_DEFAULT_INSTANCE_SCORE_THRESHOLD
            ),
            self.config.get("mask_score_thres", SEGM_DEFAULT_MASK_SCORE_THRESHOLD),
            self.model.segm_metadata,
            visualization_font_size_scale=self.vis_font_size_scale,
        )
        # shape (H, 2 * W, C = 3), dtype np.uint8
        final_vis_image = np.concatenate([frame_data, semg_vis_image], axis=1)
        return final_vis_image

    def run_model_inference(
        self, recording_id: int, images: T.List[Image], manifold_vis_recording_dir: str
    ) -> None:
        vis_recording_dir = self._get_local_vis_recording_dir(recording_id)
        # Often images are from the same stream id. However, with separate NICE slots, we will have up to two streams per camera-purpose
        # https://www.internalfb.com/intern/wiki/RL/XR_Tech/Core_Libraries/visiontypes_Library/Separated_time_sharing_slots/
        stream_id_to_idx = defaultdict(lambda: 0)
        for image in tqdm.tqdm(images):
            recording_id_parsed, _timestamp, stream_id = parse_image_id(image)
            assert int(recording_id_parsed) == recording_id, "recording_id mismatch"

            idx = stream_id_to_idx[stream_id]
            stream_id_to_idx[stream_id] += 1

            frame_data = image.bitmap.load_if_not_exists()
            assert len(frame_data.shape) == 2, "frame_data should be 2d"
            assert frame_data.dtype == np.uint8, "frame_data should be uint8"
            H, W = frame_data.shape
            # shape (H = 320, W = 256), dtype torch.uint8
            frame = torch.from_numpy(frame_data)
            model_inputs = OrderedDict()
            model_inputs["frame"] = frame
            model_outputs = self.model.run_model(model_inputs)
            vis_image = self.visualize_model_outputs(model_inputs, model_outputs)

            vis_image = PILImage.fromarray(vis_image)
            local_vis_image_dir = os.path.join(vis_recording_dir, stream_id)
            os.makedirs(local_vis_image_dir, exist_ok=True)

            fname = f"{idx:08d}.png"
            local_vis_image_path = os.path.join(local_vis_image_dir, fname)
            vis_image.save(local_vis_image_path)

            if self.debug:
                manifold_vis_stream_path = os.path.join(
                    manifold_vis_recording_dir, stream_id
                )
                pathmgr.mkdirs(manifold_vis_stream_path)

                manifold_vis_image_path = os.path.join(manifold_vis_stream_path, fname)
                pathmgr.copy_from_local(
                    local_vis_image_path, manifold_vis_image_path, overwrite=True
                )

    def encode_model_prediction_vis_video(
        self, dataset_dict: T.Dict[str, T.Any], manifold_vis_dir: str
    ) -> None:
        fps = self.dataset.config.get("fps", 30)

        recording_id = dataset_dict["recording_id"]
        vis_recording_dir = self._get_local_vis_recording_dir(recording_id)

        stream_id_dirs = os.listdir(vis_recording_dir)
        for stream_id_dir in stream_id_dirs:
            vis_recording_stream_dir = os.path.join(vis_recording_dir, stream_id_dir)
            if not os.path.isdir(vis_recording_stream_dir):
                logger.warning(f"{vis_recording_stream_dir} is not a directory. Skip")
                continue
            logger.info(f"stream_id_dir {stream_id_dir}")
            logger.info(f"vis_recording_stream_dir {vis_recording_stream_dir}")

            manifold_vis_stream_dir = os.path.join(manifold_vis_dir, stream_id_dir)
            pathmgr.mkdirs(manifold_vis_stream_dir)
            logger.info(f"manifold_vis_stream_dir {manifold_vis_stream_dir}")

            generated_video_path = assemble_frames_into_video(
                vis_recording_stream_dir,
                manifold_vis_stream_dir,
                f"{recording_id}_model_pred.mp4",
                fps,
            )

            self.generated_video_paths.append(generated_video_path)

    # pyre-ignore
    def process_dataset_item(self, dataset_dict: T.Dict[str, T.Any]):
        recording_id = dataset_dict["recording_id"]
        manifold_vis_recording_dir = os.path.join(
            self.manifold_vis_dir, "recordings", str(recording_id)
        )
        pathmgr.mkdirs(manifold_vis_recording_dir)

        time_start = perf_counter()
        transformed_images = self.extract_recording_frames(int(recording_id))
        elapsed = perf_counter() - time_start
        logger.info(f"extract_recording_frames(). Total time (secs): {elapsed:.2f}")

        time_start = perf_counter()
        self.run_model_inference(
            recording_id, transformed_images, manifold_vis_recording_dir
        )
        elapsed = perf_counter() - time_start
        logger.info(f"run_model_inference(). Total time (secs): {elapsed:.2f}")

        time_start = perf_counter()
        manifold_vis_video_dir = os.path.join(self.manifold_vis_dir, "vis_videos")
        self.encode_model_prediction_vis_video(dataset_dict, manifold_vis_video_dir)
        elapsed = perf_counter() - time_start
        logger.info(
            f"encode_model_prediction_vis_video(). Total time (secs): {elapsed:.2f}"
        )
