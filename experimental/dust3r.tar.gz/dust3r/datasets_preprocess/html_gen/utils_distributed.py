# pyre-strict
import typing as T
import uuid

import fblearner_launch_utils as flu
from iopath.common.file_io import PathManager
from iopath.fb.manifold import ManifoldPathHandler

from mobile_cv.common.misc.py import (
    FolderLock,
    MultiprocessingPdb,
    PicklableWrapper,
    post_mortem_if_fail,
)
from mobile_cv.torch.utils_pytorch import comm

pathmgr = PathManager()
pathmgr.register_handler(ManifoldPathHandler())


# pyre-ignore
def post_mortem_if_fail_for_main(main_func):
    # pyre-ignore
    def new_main_func(*args, **kwargs):
        pdb_ = (
            MultiprocessingPdb(FolderLock("/tmp"))
            if comm.get_world_size() > 1
            else None  # fallback to use normal pdb for single process
        )
        return post_mortem_if_fail(pdb_)(main_func)(*args, **kwargs)

    return PicklableWrapper(new_main_func)


def launch_distributed_job(
    config_name: str,
    job_description: str,
    target: str,
    doctor_config: T.Dict[str, T.Any],
    remote_config_file_path: str,
    manifold_output_dir: str,
    num_nodes: int,
    num_processes: int,
    entitlement: str,
    secure_group: str,
    oncall: str,
    memory: str = "49g",
) -> None:

    model_desc_list = []
    for model_config in doctor_config.get("models", []):
        model_desc_list.append(model_config.get("id", "unknown model"))

    job_name = [
        "MODEL_DOCTOR_DISTRIBUTED",
        config_name,
        ",".join(model_desc_list),
        f"nodes_{num_nodes}",
        f"proc_{num_processes}",
        job_description,
    ]
    job_name = "-".join(job_name)

    flu.set_secure_group(secure_group)
    flu.set_inplace(False)

    flu.buck_run_ddp(
        job_name,
        target,
        args=[
            "--config_file",
            remote_config_file_path,
            "--num_nodes",
            "{num_nodes}",
            "--node_index",
            "{node_index}",
            "--num_processes",
            num_processes,
            "--manifold_output_dir",
            manifold_output_dir,
            "--dist_url",
            "zeus://create_table_" + str(uuid.uuid4().hex),
            "--is_fblearner_run",
            True,
        ],
        num_nodes=num_nodes,
        entitlement=entitlement,
        resources=flu.Resources(cpu=16, gpu=0, memory=memory),
        oncall="core_ai_multitask",
    )
