# pyre-strict
import copy
import logging
import typing as T

from jef.damit.damit_expansion import expand_damit_revision
# @manual=fbsource//arvr/python/damit:search_helper
from arvr.python.damit.search_helper import load_revision_by_uri

from .base_dataset import BaseDataset
from .list_dataset import ListDataset

logger: logging.Logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class DamitDataset(BaseDataset):
    def __init__(self, name: str, config: T.Dict[str, T.Any]) -> None:
        super().__init__(name, config)
        assert "damit_revision_uri" in self.config, "DAMIT revision URI is required"
        gaia_recordings_ids = self.load_damit_dataset(self.config["damit_revision_uri"])

        logger.info(f"gaia_recordings_ids count {len(gaia_recordings_ids)}")
        logger.info(f"gaia_recordings_ids[:5] {gaia_recordings_ids[:5]}")

        max_recordings = self.config.get("max_recordings", 0)
        if max_recordings > 0 and max_recordings < len(gaia_recordings_ids):
            logger.info(f"truncate to {max_recordings} recordings")
            gaia_recordings_ids = gaia_recordings_ids[:max_recordings]

        self.dataset_dicts: T.List[T.Dict[str, T.Any]] = [
            {"recording_id": recording_id} for recording_id in gaia_recordings_ids
        ]

    def load_damit_dataset(self, damit_revision_uri: str) -> T.List[int]:
        revision = load_revision_by_uri(damit_revision_uri)
        gaia_recordings = expand_damit_revision(revision)
        gaia_recordings_ids = [item.id for item in gaia_recordings]
        return gaia_recordings_ids

    def shard(self, num_shards: int) -> T.List[BaseDataset]:
        assert num_shards > 0
        sharded_datasets = []
        N = len(self)
        for shard_idx in range(num_shards):
            logger.info(
                f"Sharding dataset into {num_shards} shards... ({shard_idx+1}/{num_shards})"
            )

            shard_config = copy.deepcopy(self.config)
            shard_config["class"] = "ListDataset"
            keys_to_pop = ["damit_revision_uri", "max_recordings"]
            for key in keys_to_pop:
                if key in shard_config:
                    shard_config.pop(key)

            shard_config["recording_ids"] = [
                self.dataset_dicts[i]["recording_id"]
                for i in range(N)
                if i % num_shards == shard_idx
            ]

            sharded_dataset = ListDataset(self.name, shard_config)
            sharded_datasets.append(sharded_dataset)
        return sharded_datasets
