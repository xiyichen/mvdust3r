# pyre-strict
import copy
import logging
import typing as T

from .base_dataset import BaseDataset

logger: logging.Logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class ListDataset(BaseDataset):
    def __init__(self, name: str, config: T.Dict[str, T.Any]) -> None:
        super().__init__(name, config)
        # a list of recording gaia IDs
        self.dataset_dicts: T.List[T.Dict[str, T.Any]] = [
            {"recording_id": recording_id}
            for recording_id in self.config.get("recording_ids", [])
        ]

    def shard(self, num_shards: int) -> T.List[BaseDataset]:
        assert num_shards > 0
        sharded_datasets = []
        N = len(self)
        for shard_idx in range(num_shards):
            logger.info(
                f"Sharding dataset into {num_shards} shards... ({shard_idx+1}/{num_shards})"
            )

            shard_config = copy.deepcopy(self.config)

            shard_config["recording_ids"] = [
                self.dataset_dicts[i]["recording_id"]
                for i in range(N)
                if i % num_shards == shard_idx
            ]

            sharded_dataset = ListDataset(self.name, shard_config)
            sharded_datasets.append(sharded_dataset)
        return sharded_datasets
