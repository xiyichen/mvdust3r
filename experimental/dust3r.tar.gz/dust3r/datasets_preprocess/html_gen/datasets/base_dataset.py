# pyre-strict
import typing as T


class BaseDataset:
    def __init__(self, name: str, config: T.Dict[str, T.Any]) -> None:
        self.name = name
        self.config = config
        self.dataset_dicts: T.List[T.Dict[str, T.Any]] = []

    def __len__(self) -> int:
        return len(self.dataset_dicts)

    def __getitem__(self, idx: int) -> T.Dict[str, T.Any]:
        dataset_dict = self.dataset_dicts[idx]
        assert isinstance(dataset_dict, dict), "Dataset dict must be of type dict"
        assert "recording_id" in dataset_dict, "Dataset dict must contain recording_id"
        return dataset_dict

    def shard(self, num_shards: int) -> T.List["BaseDataset"]:
        """
        Overload this function to implement custom sharding logic
        """
        raise NotImplementedError("shard() method is not implemented")
