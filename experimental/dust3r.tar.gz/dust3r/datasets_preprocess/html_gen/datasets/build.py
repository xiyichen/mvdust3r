# pyre-strict
import typing as T

from .base_dataset import BaseDataset
# from .damit_dataset import DamitDataset
from .list_dataset import ListDataset


# Manually register the datasets below. Sort dataset classes alphabetically
dataset_register = {
    # "DamitDataset": DamitDataset,
    "ListDataset": ListDataset,
}


def build_dataset(dataset_config: T.Dict[str, T.Any]) -> BaseDataset:
    dataset_class = dataset_config["class"]
    name = dataset_config.pop("name", "unamed_dataset")
    assert (
        dataset_class in dataset_register
    ), f"dataset class {dataset_class} is not supported."
    return dataset_register[dataset_class](name, dataset_config)


def get_sharded_datasets(
    dataset_config: T.Dict[str, T.Any], num_shards: int
) -> T.List[BaseDataset]:
    dataset = build_dataset(dataset_config)
    return dataset.shard(num_shards)
