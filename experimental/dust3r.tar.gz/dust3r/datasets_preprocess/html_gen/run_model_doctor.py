# pyre-ignore
"""
    Run model doctor locally on devserver

    buck2 run @mode/dev-nosan vizard_projects/ml_depth/tools/model_doctor:run_model_doctor -- \
    --config_file [CONFIG_FILE] \
    --manifold_output_dir [MANIFOLD_DIR] \
    --num_processes [NUM_PROCESSES]
"""

import argparse
import importlib
import json
import logging
import os
import sys
import typing as T
import uuid
from datetime import timedelta
from time import perf_counter

# import zeus module so that distributed URL with *zeus://* prefix can be handled
import torch.fb.rendezvous.zeus  # noqa
from fblearner.flow.facebook.fbpackage import FbPackage

from iopath.common.file_io import PathManager
from iopath.fb.manifold import ManifoldPathHandler
from mobile_cv.torch.utils_pytorch import comm, distributed_helper as dist_helper
from vizard.utils.device_utils import is_device_leased, release_device

from .datasets.build import get_sharded_datasets

from .doctors.utils import (
    get_manifold_vis_video_dir,
    load_config,
    setup_manifold_output_dir,
)
from .frontend.summary_html import vis_video_summary_html

from .utils_distributed import post_mortem_if_fail_for_main
from .utils_misc import get_fblearner_run_id, pretty_print_nested_dict

from iopath.common.file_io import g_pathmgr

pathmgr = PathManager()
pathmgr.register_handler(ManifoldPathHandler())

logging.basicConfig(
    format="%(asctime)s,%(msecs)03d %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s",
    datefmt="%Y-%m-%d:%H:%M:%S",
    level=logging.DEBUG,
)

logger: logging.Logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


DEFAULT_DOCTOR_MODULE = (
    "vizard_projects.ml_depth.tools.model_doctor.doctors.depth_segmentation_model_doctor",
)
DEFAULT_DOCTOR_CLASS = "DepthSegmentationModelDoctor"

MAX_VIS_VIDEOS_PER_PAGE = 10




def generate_html(vis_video_dir, manifold_output_dir,
    doctor_info = {'doc': 'none'},
    dataset_info = {'dataset': 'none'},
    model_info = {'model': 'none'}
):

    g_pathmgr.mkdirs(manifold_output_dir)
    url = vis_video_summary_html(
        vis_video_dir,
        doctor_info,
        dataset_info,
        model_info,
        manifold_output_dir,
        max_videos_per_page=MAX_VIS_VIDEOS_PER_PAGE,
    )
    return url

# vis_video_dir = "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/logs/torchx-dust3r_train-scannetPair_full_4x8_pretrain_nw8_lr3e-4/videos"
# manifold_output_dir = 'manifold://ondevice_ai_writedata/tree/zgtang/dust3r/logs/torchx-dust3r_train-scannetPair_full_4x8_pretrain_nw8_lr3e-4/html'

# generate_html(vis_video_dir, manifold_output_dir)


# from .doctors.build import build_model_doctor

# # pyre-ignore
# def parse_args(in_args):
#     parser = argparse.ArgumentParser(description="Model doctor")
#     parser.add_argument("--config_file", default="", required=True)
#     parser.add_argument("--manifold_output_dir", default="", required=True)
#     parser.add_argument("--num_processes", type=int, default=1)
#     parser.add_argument("--num_nodes", type=int, default=1)
#     parser.add_argument("--node_index", type=int, default=0)
#     parser.add_argument(
#         "--dist_url",
#         type=str,
#         default="zeus://create_table_" + str(uuid.uuid4().hex),
#     )
#     parser.add_argument("--is_fblearner_run", type=bool, default=False)

#     args = parser.parse_args(in_args)
#     logger.info(f"args: {args}")

#     return args


# # pyre-ignore
# def import_model_doctor_class(model_doctor_module: str, model_doctor_name: str):
#     annotator_module = importlib.import_module(model_doctor_module)
#     model_doctor_class = getattr(annotator_module, model_doctor_name)
#     return model_doctor_class


# def find_vis_videos(manifold_dir: str, file_ext: str = "mp4") -> bool:
#     videos = [p for p in sorted(pathmgr.ls(manifold_dir)) if p.endswith(file_ext)]
#     num_videos = len(videos)
#     return True if num_videos > 0 else False


# def generate_vis_video_summary_html(
#     config: T.Dict[str, T.Any], manifold_output_dir: str
# ) -> T.Dict[str, T.Any]:
#     """
#     Within manifold output dir, the structure of sub-directories are f"{dataset_name}/{model_name}/vis/vis_video"
#     """
#     logger.info("Generate summary html page")
#     summary_html_urls = {}
#     for dataset in sorted(pathmgr.ls(manifold_output_dir)):
#         summary_html_urls[dataset] = {}
#         logger.info(f"dataset {dataset}")
#         if not pathmgr.isdir(os.path.join(manifold_output_dir, dataset)):
#             continue
#         for model in sorted(pathmgr.ls(os.path.join(manifold_output_dir, dataset))):
#             if not pathmgr.isdir(os.path.join(manifold_output_dir, dataset, model)):
#                 continue
#             logger.info(f"model {model}")

#             dataset_info = {"name": dataset}
#             model_info = {"name": model}

#             vis_video_dir = get_manifold_vis_video_dir(
#                 os.path.join(manifold_output_dir, dataset, model)
#             )

#             if find_vis_videos(vis_video_dir):
#                 # For certain model doctors, such as DepthSegmentationModelDoctor, vis videos are stored in the vis_video_dir
#                 url = vis_video_summary_html(
#                     vis_video_dir,
#                     config["doctor"],
#                     dataset_info,
#                     model_info,
#                     manifold_output_dir,
#                     max_videos_per_page=MAX_VIS_VIDEOS_PER_PAGE,
#                 )

#                 summary_html_urls[dataset][model] = url
#             else:
#                 summary_html_urls[dataset][model] = {}
#                 # For certain model doctors, such as Mask2FormerModelDoctor, vis videos are stored in the  f"{vis_video_dir}/{stream_id}""
#                 for stream_id in sorted(pathmgr.ls(vis_video_dir)):
#                     stream_id_dir = os.path.join(vis_video_dir, stream_id)
#                     if pathmgr.isdir(stream_id_dir):
#                         logger.info(
#                             f"Generate vis video summary html for model {model}, dataset {dataset}, stream id {stream_id}"
#                         )
#                         url = vis_video_summary_html(
#                             stream_id_dir,
#                             config["doctor"],
#                             dataset_info,
#                             model_info,
#                             manifold_output_dir,
#                             max_videos_per_page=MAX_VIS_VIDEOS_PER_PAGE,
#                         )

#                         summary_html_urls[dataset][model][stream_id] = url

#     return summary_html_urls


# def install_clicat() -> None:
#     """
#     Install clicat binary as in wiki below
#     https://www.internalfb.com/intern/wiki/RL/Gaia_AI_dataset_management_solutions/Authentication_QA/#fblearner
#     """
#     # Install clicat via fbpkg
#     clicat_pkg_path = FbPackage("clicat").package_path
#     os.environ["PATH"] = f"{clicat_pkg_path}:{os.environ['PATH']}"


# def run_model_doctor(
#     config_file: str, manifold_output_dir: str
# ) -> T.Optional[T.Dict[str, T.Any]]:
#     rank = comm.get_rank()
#     logger.info(f"run model doctor. rank {rank}")

#     run_id = get_fblearner_run_id()
#     logger.info(f"FBLearner workflow run id: {run_id}")

#     if run_id is not None:
#         install_clicat()
#     config = load_config(config_file)
#     for dataset_config in config["datasets"]:
#         sharded_datasets = get_sharded_datasets(dataset_config, comm.get_world_size())

#         for model_config in config["models"]:
#             model_doctor = build_model_doctor(
#                 config["doctor"],
#                 model_config,
#                 sharded_datasets[rank],
#                 manifold_output_dir,
#             )

#             model_doctor.run()

#             logger.info("".join(["*"] * 100))
#             logger.info(f"model doctor at rank {rank} is done!")
#             logger.info("".join(["*"] * 100))

#             model_doctor.cleanup()

#             comm.synchronize()

#         comm.synchronize()

#     comm.synchronize()

#     if comm.is_main_process():
#         logger.info("all ranks are done!")
#         config = load_config(config_file)
#         summary_urls = generate_vis_video_summary_html(config, manifold_output_dir)
#         logger.critical("Processing done, URLs are here:")
#         pretty_print_nested_dict(summary_urls)
#         logger.critical(summary_urls)

#     comm.synchronize()


# def setup_model_doctor(config_file: str, manifold_output_dir: str) -> str:
#     with pathmgr.open(config_file, "r") as f:
#         config = json.load(f)

#     manifold_output_dir, _remote_config_file_path = setup_manifold_output_dir(
#         manifold_output_dir, config
#     )

#     device_leased = is_device_leased()
#     if device_leased:
#         # release any device that was not leased by model doctor. We will lease device within BoltNNModel
#         release_device()

#     return manifold_output_dir


# def launch_model_doctor(
#     config_file: str,
#     manifold_output_dir: str,
#     num_processes: int,
#     num_nodes: int,
#     node_index: int,
#     dist_url: str,
#     is_fblearner_run: bool,
# ) -> None:
#     if not is_fblearner_run:
#         # we set up the output folder during this call. Otherwise, it was already set up as we are running in a distributed process
#         manifold_output_dir = setup_model_doctor(config_file, manifold_output_dir)

#     time_start = perf_counter()

#     dist_helper.launch(
#         post_mortem_if_fail_for_main(run_model_doctor),
#         num_processes_per_machine=num_processes,
#         num_machines=num_nodes,
#         machine_rank=node_index,
#         args=(config_file, manifold_output_dir),
#         dist_url=dist_url,
#         backend="GLOO",
#         timeout=timedelta(hours=5),
#     )

#     elapsed_time = perf_counter() - time_start
#     logger.info(f"total time in seconds: {elapsed_time}")

#     # this will generate per-node summaries when running in fblearner
#     # we don't need these, so we skip
#     if not is_fblearner_run:
#         config = load_config(config_file)
#         summary_html_urls = generate_vis_video_summary_html(config, manifold_output_dir)
#         logger.info(f"output manifold dir: {manifold_output_dir}")
#         logger.info("summary_html_urls")
#         pretty_print_nested_dict(summary_html_urls)


# def main() -> None:
#     args = parse_args(sys.argv[1:])

#     launch_model_doctor(
#         args.config_file,
#         args.manifold_output_dir,
#         args.num_processes,
#         args.num_nodes,
#         args.node_index,
#         args.dist_url,
#         args.is_fblearner_run,
#     )


# if __name__ == "__main__":
#     main()
