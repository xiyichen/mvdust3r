# pyre-strict
import json
import logging
import os
import typing as t
import uuid
from datetime import date, datetime

import click
import mobile_cv.common.fb.flu.task_helper as th

from iopath.common.file_io import PathManager
from iopath.fb.manifold import ManifoldPathHandler
from vizard_projects.ml_depth.tools.model_doctor.run_model_doctor import (
    launch_model_doctor,
)
from vizard_projects.ml_depth.tools.model_doctor.utils_distributed import (
    launch_distributed_job,
)

from vizard_projects.ml_depth.tools.model_doctor.utils_misc import (
    create_config_file_from_template,
    get_config_file_path,
)

from xri_scene.d2go_projects.segmentation_2d.lib.visualization.tasks import (
    ModelDoctorSideBySide,
)

from .doctors.utils import setup_manifold_output_dir


logging.basicConfig(level=logging.INFO)
logger: logging.Logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

pathmgr = PathManager()
pathmgr.register_handler(ManifoldPathHandler())

NUM_NODES = 1
# We currently don't use GPU
NUM_GPUS = 0

DOCTOR_DISTRIBUTED_TARGET = (
    "vizard_projects/ml_depth/tools/model_doctor:run_model_doctor"
)

# For a single job, there is a hard quota TOTAL_DEVICE_COUNT_PER_JOB_ID, that limits max # of leased device to be 10
MAX_RIOT_DEVICE_LEASE = 10

"""
Task **doctor_local** launches model doctor locally, and takes a config file as input.
Optionally, it takes FBLearner job ids as input. In such case, it will use the provided config file as template, and overwrite model info based on FBLearner jobs.

buck2 run @mode/$MODE //vizard_projects/ml_depth/tools/model_doctor:launch_doctor -- \
doctor_local \
--config_file [CONFIG_FILE] \
[Other options]

"""


@th.TASKS.register("doctor_local")
@click.option("--config_file", type=str)
@click.option("--manifold_output_dir", type=str)
@click.option("--num_processes", default=1)
@click.option("--job_ids", type=str, default="")
@click.option("--model_type", default="torchscript_int8")
@click.option("--model_file_name", default="model.jit")
def run_doctor_local(
    config_file: str,
    manifold_output_dir: str,
    num_processes: int,
    job_ids: str,
    model_type: str,
    model_file_name: str,
) -> None:
    """
    Args:
        config_file: path to config file
        manifold_output_dir: manifold path to the output folder
        num_processes: number of processes to use for model doctor
        job_ids [optional]: a list of FBLearner job ids separated by comma, such as "f53930772,f53930773"
        model_type [optional]: model type, such as "torchscript_int8". Useful to retrieve model file path from FBLearner job
        model_file_name [optional]: model file name. Useful to retrieve model file path from FBLearner job
    """
    dist_url = "zeus://create_table_" + str(uuid.uuid4().hex)

    config_file = get_config_file_path(config_file)
    logger.info(f"config_file: {config_file}")

    if len(job_ids) == 0:
        config_file_path = config_file
    else:
        config_file_path = create_config_file_from_template(
            config_file, job_ids, model_type, model_file_name
        )

    if "boltnn" in model_type.lower():
        assert num_processes == 1, "BoltNN model does not support multi-processes"

    num_nodes = 1
    node_index = 0
    launch_model_doctor(
        config_file_path,
        manifold_output_dir,
        num_processes,
        num_nodes,
        node_index,
        dist_url,
        is_fblearner_run=False,
    )


# NOTE: logic in this file is based on fbcode/mobile-vision/experimental/unified_machine_annotation/scripts/launch_annotation.py


"""
Task **doctor_distributed** takes a config file as input, launches model doctor as a distributed job in FBLearner. It can use multiple nodes for speed up. It is suitable to use Torchscript model. Currently, since using BoltNN model requires to lease HMD device on-the-fly, it is not supported yet.


buck2 run vizard_projects/ml_depth/tools/model_doctor:launch_doctor -- \
    -t doctor_distributed     \
    --config_file vizard_projects/ml_depth/tools/m2f_rc4_torchscript_int8_4_sequences_multimodel.json \
    --manifold_output_dir manifold://output_indoor_seg_training/tree/karlab/testing/data_doctor \
    --num_nodes 2

"""


@th.TASKS.register("doctor_distributed")
@click.option("--config_file", default="")
@click.option("--entitlement", default="xr_presence")
@click.option("--secure_group", default="scenes_ml_dev")
@click.option("--oncall", default="core_ai_multitask")
@click.option("--num_nodes", default=64)  # 256 is the default used by UMA
@click.option("--num_processes", default=1)
@click.option("--description", default="")
@click.option("--manifold_output_dir", default="")
@click.option("--job_ids", type=str, default="")
@click.option("--model_type", default="torchscript_int8")
@click.option("--model_file_name", default="model.jit")
@click.option("--memory", default="49g")
def run_doctor_distributed(
    config_file: str,
    entitlement: str,
    secure_group: str,
    oncall: str,
    num_nodes: int,
    num_processes: int,
    description: str,
    manifold_output_dir: str,
    job_ids: str,
    model_type: str,
    model_file_name: str,
    memory: str,
) -> None:
    """
    Args:
        config_file: path to config file
        entitlement: FBLearner entitlement
        secure_group: as the name
        num_nodes: # of server nodes
        num_processes: number of processes to use for model doctor
        description: job description, which will be part of the job name
        manifold_output_dir: manifold path to the output folder
        job_ids [optional]: a list of FBLearner job ids separated by comma, such as "f53930772,f53930773"
        model_type [optional]: model type, such as "torchscript_int8". Useful to retrieve model file path from FBLearner job
        model_file_name [optional]: model file name. Useful to retrieve model file path from FBLearner job
        memory [optional]: cpu server memory requirements
    """
    assert not config_file == "", "config_file is required"

    config_file = get_config_file_path(config_file)
    logger.info(f"config_file: {config_file}")

    if "boltnn" in model_type.lower():
        assert num_processes == 1, "BoltNN model does not support multi-processes"
        assert (
            num_nodes <= MAX_RIOT_DEVICE_LEASE
        ), f"{num_nodes} devices are requested, but the maximum number of devices that can be leased is {MAX_RIOT_DEVICE_LEASE}."

    if len(job_ids) == 0:
        config_file_path = config_file
    else:
        config_file_path = create_config_file_from_template(
            config_file, job_ids, model_type, model_file_name
        )

    with pathmgr.open(config_file_path, "r") as f:
        config_json = json.load(f)

    manifold_output_dir, remote_config_file_path = setup_manifold_output_dir(
        manifold_output_dir, config_json
    )

    launch_distributed_job(
        os.path.basename(config_file_path),
        description,
        DOCTOR_DISTRIBUTED_TARGET,
        config_json,
        remote_config_file_path,
        manifold_output_dir,
        num_nodes,
        num_processes,
        entitlement,
        secure_group,
        oncall,
        memory=memory,
    )


"""
buck2 run @mode/dev-nosan \;';vizard_projects/ml_depth/tools/model_doctor:launch_doctor -- \
    -t doctor_side_by_side \
    --manifold_output_dir manifold://output_indoor_seg_training/tree/karlab/testing/data_doctor/side_by_side \
    --doctor_output_folders "https://interncache-pnb.fbcdn.net/manifold/output_indoor_seg_training/tree/users/zyan3/model_doctor/2024-03-27/Mask2FormerModelDoctor_2024-03-27-00:17:50_51716b7821bd4cc6a8c1f8811ffb34ac/exobodies_in_the_wild_zur_20240312/f544906130_M2F_RC4_boltnn/vis/vis_videos/205-1/index.html,https://interncache-pnb.fbcdn.net/manifold/output_indoor_seg_training/tree/users/zyan3/model_doctor/2024-03-27/Mask2FormerModelDoctor_2024-03-27-00:58:01_09be4856eb034497a8fbd0c6be36fd7f/exobodies_in_the_wild_zur_20240312/f544906211_M2F_RC4_boltnn/vis/vis_videos/205-1/index.html" \
"""


@th.TASKS.register("doctor_side_by_side")
@click.option("--manifold_output_dir", type=str)
@click.option("--doctor_output_folders", type=str)
@click.option("--playback_speeds", type=str, default=None)
@click.option("--column_comparative_view", default=False, is_flag=True)
def run_doctor_side_by_side(
    manifold_output_dir: str,
    doctor_output_folders: str,
    playback_speeds: t.Optional[str],
    column_comparative_view: bool,
) -> None:
    """
    Args:
        doctor_output_folders: a list of doctor visualization output folders separated by commas
            Option A: the path to the folder containing the index.html file
            Option B: the full link to one of the HTML files for doctor visualization (index.html or one of the parts)
          Note that this will accept links starting with either manifold://(...) or https://interncache-pnb.fbcdn.net/(...)
        playback_speeds: a list of playback speeds separated by commas
            If not provided, a default playback speed of 1 will be used.
        column_comparative_view: if True, will generate a columnwise comparative view.
    """
    # create a specific manifold output dir
    today = date.today()
    now = datetime.now()
    dt_string = now.strftime("%Y-%m-%d-%H:%M:%S")
    manifold_output_dir = os.path.join(
        manifold_output_dir,
        str(today),
        f"{dt_string}_{str(uuid.uuid4().hex)}",
    )
    pathmgr.mkdirs(manifold_output_dir)

    side_by_side = ModelDoctorSideBySide(doctor_output_folders.split(","))
    url = side_by_side.generate_comparison(
        manifold_output_dir,
        playback_speeds=(
            list(map(float, playback_speeds.split(","))) if playback_speeds else None
        ),
        column_comparative_view=column_comparative_view,
    )
    logger.info(f"Visualization available at -> {url}")


def main() -> None:
    th.main()


if __name__ == "__main__":
    main()
