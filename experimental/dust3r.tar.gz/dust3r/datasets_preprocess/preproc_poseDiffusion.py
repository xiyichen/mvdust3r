# 'filepath', 'bbox', 'R', 'T', 'focal_length', 'principal_point'
# {'filepath': 'tv/397_49980_98389/images/frame000001.jpg', 'bbox': [258, 83, 1010, 744], 'R': [[0.7446383237838745, -0.5196457505226135, -0.41890576481819153], [0.4870184361934662, -0.006171653047204018, 0.8733698725700378], [-0.45642828941345215, -0.85435950756073, 0.24848142266273499]], 'T': [1.6427916288375854, 1.8028584718704224, 10.953643798828125], 'focal_length': [3.2680823802948, 3.2680823802948], 'principal_point': [-0.0, 0.0009708738070912659]}


from copy import deepcopy
import sys, os


import argparse
parser = argparse.ArgumentParser()
# parser.add_argument("--data-name")
# parser.add_argument("--n-render", default = 0, type=int)
# parser.add_argument("--n-dps", default = 10, type=int)
# parser.add_argument("--h5py", default = 0, type=int)
# parser.add_argument("--node-no", default=0, type=int)
args = parser.parse_args()

try:
    import torch.manifold.patch
    from iopath.common.file_io import g_pathmgr
    from dust3r.utils.geometry import depthmap_to_absolute_camera_coordinates
    from dust3r.pcd_render import pcd_render, save_image_manifold, save_video_combined


except:
    pass

import PIL
import numpy as np
import torch
import glob, sys
import json
import imageio
import cv2
import h5py

import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__))))

# dps_test.h5

data_list = [
    'scannet_large_0.3_0.7_30_test_3.0',
    'mp3d_tdf_2_new_24_6_0.06_3.0',
    'hs_tdf_2_new_test_24_6_0.1_3.0',
]

# no torchx
def manifold_get_dps():

    for data_name in data_list:
        # makedir at /home/zgtang/{dataname}
        os.system(f"mkdir /home/zgtang/data_PD/{data_name}")
        command = f"manifold --prod-use-cython-client get --threads 100 ondevice_ai_writedata/tree/zgtang/dust3r/data/{data_name}/dps_test.h5 /home/zgtang/data_PD/{data_name}/dps_test.h5"
        print(command)
        os.system(command)


'''
'filepath', 'bbox', 'R', 'T', 'focal_length', 'principal_point'
{'filepath': 'tv/397_49980_98389/images/frame000001.jpg', 
'bbox': [258, 83, 1010, 744], 
'R': [[0.7446383237838745, -0.5196457505226135, -0.41890576481819153], [0.4870184361934662, -0.006171653047204018, 0.8733698725700378], [-0.45642828941345215, -0.85435950756073, 0.24848142266273499]], 
'T': [1.6427916288375854, 1.8028584718704224, 10.953643798828125], 
'focal_length': [3.2680823802948, 3.2680823802948], 
'principal_point': [-0.0, 0.0009708738070912659]}
'''

# need torchx
def extract_dps():

    import fbvscode
    fbvscode.attach_debugger()
    for data_name in data_list:
        print('extract', data_name)
        # read dps_test.h5
        info_dataset_i = []
        dir_name = f"/home/zgtang/data_PD/{data_name}"
        rel_dir_name = f"data_PD/{data_name}"
        
        h5_path = f"{dir_name}/dps_test.h5"
        res_name = f"{dir_name}/task.json"
        with h5py.File(h5_path, 'r') as h5f:
            n = len(h5f['json_strs'])
            target_n = 100
            if target_n > n:
                target_n = n
            id_list = [int(i * n / target_n) for i in range(target_n)]
            for (data_id, json_str) in enumerate(h5f['json_strs'][:]):
                if data_id not in id_list:
                    continue
                print(data_id)
                info_dp_i = []
                json_dict = json.loads(json_str)
                rgb_list = json_dict['rgb_list']
                if len(rgb_list) == 1:
                    img = imageio.imread(g_pathmgr.get_local_path(rgb_list[0]))
                    h, w_all = img.shape[:2]
                    n = w_all // h
                    img = np.split(img, n, axis=1)
                else:
                    img = []
                    for rgb_path in rgb_list:
                        img.append(imageio.imread(g_pathmgr.get_local_path(rgb_path)))

                if "pose_list" in json_dict.keys():
                    pose_list = []
                    for pose_path in json_dict['pose_list']:
                        pose_list.append(np.loadtxt(g_pathmgr.get_local_path(pose_path)).astype(np.float32))
                        pose_list[-1] = np.linalg.inv(pose_list[-1])
                else:
                    pose_list = []
                    for pose_path in json_dict['pose_raw_list']:
                        pose_list.append(np.array(pose_path).astype(np.float32))
                        pose_list[-1] = np.linalg.inv(pose_list[-1])
                h,w = img[0].shape[:2]
                s = min(h,w)
                intrinsics = np.array(json_dict['intrinsic_raw'])
                fx, fy = intrinsics[0,0], intrinsics[1,1]
                fx_ndc = fx * 2 / s
                fy_ndc = fy * 2 / s

                for i in range(len(img)):
                    imageio.imwrite(f"{dir_name}/rgb_{data_id}_{i}.png", img[i])
                    info_i = {}
                    info_i['filepath'] = f"{rel_dir_name}/rgb_{data_id}_{i}.png"
                    info_i['R'] = pose_list[i][:3,:3].tolist()
                    info_i['T'] = pose_list[i][:3,3].tolist()
                    info_i['focal_length'] = [fx_ndc, fy_ndc]
                    info_i['principal_point'] = [0, 0]
                    info_dp_i.append(info_i)
                # import fbvscode
                # fbvscode.set_trace()
                info_dataset_i.append(info_dp_i)
        with open(res_name, 'w') as f:
            json.dump(info_dataset_i, f, indent=4)

def main():
    # makedir
    os.makedirs('/home/zgtang/data_PD/', exist_ok=True)
    manifold_get_dps()
    extract_dps()

main()
