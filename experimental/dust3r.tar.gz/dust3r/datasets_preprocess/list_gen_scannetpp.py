import numpy as np
import os
import glob


file_list = ["nvs_sem_train.txt", "nvs_sem_val.txt", "sem_test.txt"]

all_file = []
for file in file_list:
    file_name = f"/home/zgtang/scannetpp/splits/{file}"
    file = open(file_name, "r").read().split('\n')[:-1]
    file = ["manifold://ondevice_ai_writedata/tree/zgtang/data/scannetpp/" + x for x in file]
    all_file = all_file + file
    print(len(file))

np.save("/home/zgtang/scannetpp/scan_list.npy", all_file)
