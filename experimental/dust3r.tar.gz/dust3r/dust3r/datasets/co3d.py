# Copyright (C) 2024-present Naver Corporation. All rights reserved.
# Licensed under CC BY-NC-SA 4.0 (non-commercial use only).
#
# --------------------------------------------------------
# Dataloader for preprocessed Co3d_v2
# dataset at https://github.com/facebookresearch/co3d - Creative Commons Attribution-NonCommercial 4.0 International
# See datasets_preprocess/preprocess_co3d.py
# --------------------------------------------------------

import sys
# sys.path.insert(0, "/data/sandcastle/boxes/fbsource/fbcode/on_device_ai/experimental/third_party/dust3r")
import os.path as osp
import json
import itertools
from collections import deque
import imageio
from copy import deepcopy

import cv2
import numpy as np
import random
import h5py
import torch

from iopath.common.file_io import g_pathmgr

from dust3r.datasets.base.base_stereo_view_dataset import BaseStereoViewDataset
from dust3r.utils.image import imread_cv2

class Co3d(BaseStereoViewDataset):
    def __init__(self, mask_bg=True, *args, ROOT, **kwargs):
        self.ROOT = ROOT # 'manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/co3d_subset_processed'
        super().__init__(*args, **kwargs)
        assert mask_bg in (True, False, 'rand')
        self.mask_bg = mask_bg

        # load all scenes
        with g_pathmgr.open(osp.join(self.ROOT, f'selected_seqs_{self.split}.json'), 'r') as f:
            self.scenes = json.load(f)
            self.scenes = {k: v for k, v in self.scenes.items() if len(v) > 0}
            self.scenes = {(k, k2): v2 for k, v in self.scenes.items()
                           for k2, v2 in v.items()}
        self.scene_list = list(self.scenes.keys())

        # for each scene, we have 100 images ==> 360 degrees (so 25 frames ~= 90 degrees)
        # we prepare all combinations such that i-j = +/- [5, 10, .., 90] degrees
        self.combinations = [(i, j)
                             for i, j in itertools.combinations(range(100), 2)
                             if 0 < abs(i-j) <= 30 and abs(i-j) % 5 == 0]

        self.invalidate = {scene: {} for scene in self.scene_list}

        print('co3d dataset size', len(self.scene_list), len(self.combinations))

    def __len__(self):
        return len(self.scene_list) * len(self.combinations)

    def _get_views(self, idx, resolution, rng):
        # choose a scene
        obj, instance = self.scene_list[idx // len(self.combinations)]
        image_pool = self.scenes[obj, instance]
        im1_idx, im2_idx = self.combinations[idx % len(self.combinations)]

        # add a bit of randomness
        last = len(image_pool)-1

        if resolution not in self.invalidate[obj, instance]:  # flag invalid images
            self.invalidate[obj, instance][resolution] = [False for _ in range(len(image_pool))]

        # decide now if we mask the bg
        mask_bg = (self.mask_bg == True) or (self.mask_bg == 'rand' and rng.choice(2))

        views = []
        if self.fix_order:        
            imgs_idxs = [max(0, min(im_idx + 0, last)) for im_idx in [im2_idx, im1_idx]]
        else:
            imgs_idxs = [max(0, min(im_idx + rng.integers(-4, 5), last)) for im_idx in [im2_idx, im1_idx]]
        imgs_idxs = deque(imgs_idxs)
        while len(imgs_idxs) > 0:  # some images (few) have zero depth
            im_idx = imgs_idxs.pop()

            if self.invalidate[obj, instance][resolution][im_idx]:
                # search for a valid image
                random_direction = 2 * rng.choice(2) - 1
                for offset in range(1, len(image_pool)):
                    tentative_im_idx = (im_idx + (random_direction * offset)) % len(image_pool)
                    if not self.invalidate[obj, instance][resolution][tentative_im_idx]:
                        im_idx = tentative_im_idx
                        break

            view_idx = image_pool[im_idx]

            impath = osp.join(self.ROOT, obj, instance, 'images', f'frame{view_idx:06n}.jpg')

            # load camera params
            input_metadata = np.load(g_pathmgr.get_local_path(impath.replace('jpg', 'npz')))
            camera_pose = input_metadata['camera_pose'].astype(np.float32)
            intrinsics = input_metadata['camera_intrinsics'].astype(np.float32)

            # load image and depth
            rgb_image = imread_cv2(g_pathmgr.get_local_path(impath))
            depthmap = imread_cv2(g_pathmgr.get_local_path(impath.replace('images', 'depths') + '.geometric.png'), cv2.IMREAD_UNCHANGED)
            depthmap = (depthmap.astype(np.float32) / 65535) * np.nan_to_num(input_metadata['maximum_depth'])

            if mask_bg:
                # load object mask
                maskpath = osp.join(self.ROOT, obj, instance, 'masks', f'frame{view_idx:06n}.png')
                maskmap = imread_cv2(g_pathmgr.get_local_path(maskpath), cv2.IMREAD_UNCHANGED).astype(np.float32)
                maskmap = (maskmap / 255.0) > 0.1

                # update the depthmap with mask
                depthmap *= maskmap

            rgb_image, depthmap, intrinsics = self._crop_resize_if_necessary(
                rgb_image, depthmap, intrinsics, resolution, rng=rng, info=impath)

            num_valid = (depthmap > 0.0).sum()
            if num_valid == 0:
                # problem, invalidate image and retry
                self.invalidate[obj, instance][resolution][im_idx] = True
                imgs_idxs.append(im_idx)
                continue

            views.append(dict(
                img=rgb_image,
                depthmap=depthmap,
                camera_pose=camera_pose,
                camera_intrinsics=intrinsics,
                dataset='Co3d_v2',
                label=osp.join(obj, instance),
                instance=osp.split(impath)[1],
            ))
        return views

class Scannet(BaseStereoViewDataset):
    def __init__(self, mask_bg=True, from_tar = False, random_order = False, random_render_order = False, debug = False, *args, ROOT, n_test=1000, num_render_views = 0, n_vis_test = 8, n_vis_train = 8, split_thres = 0.9, render_start = None, tb_name = None, ref_all = False, n_ref = 1, random_nv_nr = None, dps_name = 'dps.h5', n_all = None, single_id = None, reverse = False, **kwargs): # note that n_test's definition is different from what in ScannetPair.
        self.ROOT = ROOT # 'manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/co3d_subset_processed'
        self.num_render_views = num_render_views
        self.from_tar = from_tar
        self.random_order = random_order
        self.random_render_order = random_render_order
        super().__init__(*args, **kwargs) # self.num_views, split set inside
        if "test" in dps_name:
            self.test = True
        else:
            self.test = False
        self.num_inference_views = self.num_views - self.num_render_views
        self.num_vis_test = n_vis_test
        self.num_vis_train = n_vis_train
        if render_start is None:
            render_start = self.num_inference_views
        self.render_start = render_start
        self.tb_name = tb_name if tb_name is not None else self.split
        self.ref_all = ref_all
        self.n_ref = n_ref
        if random_nv_nr is None:
            random_nv_nr = [[self.num_views, self.num_render_views]]
        self.random_nv_nr = random_nv_nr
        self.dps_name = dps_name
        self.single_id = single_id

        # load all scenes
        print('before downloading dps.json')
        self.data_name = osp.basename(self.ROOT)
        self.h5f_path = g_pathmgr.get_local_path(osp.join(self.ROOT, self.dps_name))
        # self.h5f_path = h5py.File(g_pathmgr.get_local_path(osp.join(self.ROOT, f'dps.h5')), 'r')['json_strs']
        with h5py.File(self.h5f_path, 'r') as h5f:
            self.dps = [i for i in range(len(h5f['json_strs']))]

        # with open(g_pathmgr.get_local_path(osp.join(self.ROOT, f'dps.json')), 'r') as f: # self.split should be used here for data list.
        #     self.dps = json.load(f)
        #     # choice_id = [x for x in range(0, len(self.dps), len(self.dps) // 11)] * 10000
        #     # self.dps = [self.dps[x] for x in choice_id]
        #     if debug:
        #         self.dps = self.dps[:10000] # hdf5?
        
        print('after downloading dps.json', self.ROOT, len(self.dps))

        if self.split != "all":
            split_ind = int(len(self.dps) * split_thres)
            test_id_list = [x for x in range(split_ind, len(self.dps), (len(self.dps) - split_ind) // n_test)]
            train_id_list = np.setdiff1d(np.arange(split_ind), test_id_list)
            train_test_id_list = [x + 1 for x in range(0, split_ind, split_ind // n_test)]
            vis_list = [x for x in range(split_ind, len(self.dps), (len(self.dps) - split_ind) // n_vis_test)][-n_vis_test:] + [train_test_id_list[x] for x in range(0, len(train_test_id_list), len(train_test_id_list) // n_vis_train)][-n_vis_train:]
            # vis_list = [x for x in range(split_ind, len(self.dps), (len(self.dps) - split_ind) // n_vis_test)][-n_vis_test:] + [train_test_id_list[x] for x in range(0, len(train_test_id_list), len(train_test_id_list) // n_vis_train)][-n_vis_train:]
            print('vis list', len(vis_list), vis_list)
        
        if self.split == "all":
            if n_all is not None:
                self.dps = [self.dps[int(id / n_all * len(self.dps))] for id in range(n_all)]
            pass
        elif self.split == "train":
            self.dps = [self.dps[x] for x in train_id_list]
        elif self.split == "train_test":
            self.dps = [self.dps[x] for x in train_test_id_list]
        elif self.split == "vis":
            self.dps = [self.dps[x] for x in vis_list]
        elif self.split == "test":
            self.dps = [self.dps[x] for x in test_id_list]
        if self.single_id is not None:
            self.dps = [self.dps[self.single_id]]
        if reverse:
            self.dps = list(reversed(self.dps))
    def __len__(self):
        print('len in dataset', len(self.dps), self.split)
        if self.ref_all:
            return len(self.dps) * self.num_inference_views
        return len(self.dps)

    def change_to_sr(self, file_lists):
        results = []
        for file_list in file_lists:
            file_list_new = []
            for f in file_list:
                file_list_new.append(f.replace("manifold://scannet_dataset/tree/scans/", "manifold://on_device_sr/tree/datasets/scannet/scans/"))
            results.append(file_list_new)
        return results

    def _get_views(self, idx, resolution, rng, from_tar = False, ref_view_id = None):
        
        random_nv_nr = random.choice(self.random_nv_nr)
        # self.num_views = random_nv_nr[0]
        # self.num_render_views = random_nv_nr[1]
        # self.num_inference_views = self.num_views - self.num_render_views
        if ref_view_id is None:
            ref_view_id = 0
        if self.ref_all:
            ref_view_id = idx % self.num_inference_views
            idx = idx // self.num_inference_views
        with h5py.File(self.h5f_path, 'r') as h5f:
            json_str = h5f['json_strs'][self.dps[idx]]
            data_dict = json.loads(json_str)
            C = data_dict['C'] if 'C' in data_dict.keys() else None
            if C is None:
                C_avg = np.array(0.).astype(np.float32)
            else:
                C = np.array(C)
                C = C[:self.num_inference_views,:self.num_inference_views]
                C_avg = C.mean()
                if C[0][0] > 0.9:
                    C_avg -= 1 / self.num_inference_views
                C_avg = np.array(C_avg).astype(np.float32)
            
            rgb_list = data_dict['rgb_list']
            depth_list = data_dict['depth_list']
            pose_raw_list, pose_list = [], []
            if "pose_raw_list" in data_dict.keys():
                pose_raw_list = data_dict['pose_raw_list']
            else:
                pose_list = data_dict['pose_list']
            intrinsic_raw, intrinsic_list = None, []
            if "intrinsic_raw" in data_dict.keys():
                intrinsic_raw = data_dict['intrinsic_raw']
            else:
                intrinsic_list = data_dict['intrinsic_list']

            if len(rgb_list) < self.num_views and 'nv' not in data_dict.keys(): # not implemented
                n_repeat = (self.num_views - 1) // len(rgb_list) + 1
                rgb_list = (rgb_list * n_repeat)[:self.num_views]
                depth_list = (depth_list * n_repeat)[:self.num_views]
                pose_raw_list = (pose_raw_list * n_repeat)[:self.num_views]
                pose_list = (pose_list * n_repeat)[:self.num_views]
                intrinsic_list = (intrinsic_list * n_repeat)[:self.num_views]
        
        num_tuple = len(rgb_list)
        if 'nv' in data_dict.keys():
            num_tuple = data_dict['nv']
            rgb_all = imageio.imread(g_pathmgr.get_local_path(rgb_list[0])).astype(np.uint8)
            depth_all = imageio.imread(g_pathmgr.get_local_path(depth_list[0])).astype(np.float32) / 1000
            rgb_all = np.split(rgb_all, num_tuple, axis=1)
            depth_all = np.split(depth_all, num_tuple, axis=1)
            if len(rgb_all) < self.num_views:
                n_repeat = (self.num_views - 1) // len(rgb_all) + 1
                pose_raw_list = (pose_raw_list * n_repeat)[:self.num_views]
                pose_list = (pose_list * n_repeat)[:self.num_views]
                intrinsic_list = (intrinsic_list * n_repeat)[:self.num_views]
                rgb_all = (rgb_all * n_repeat)[:self.num_views]
                depth_all = (depth_all * n_repeat)[:self.num_views]
        if self.random_render_order:
            # randomly choose num_render_views from num_views w/o replacement:
            render_set = np.random.choice(range(self.num_views), size = self.num_render_views, replace = False)
        else:
            render_set = [self.render_start + i for i in range(self.num_render_views)]
        
        inference_set = []
        for i in range(self.num_views):
            if i not in render_set:
                inference_set.append(i)
            if len(inference_set) == self.num_inference_views:
                break
        
        # rgb_list = self.dps[idx]['rgb_list']
        # depth_list = self.dps[idx]['depth_list']
        # pose_list = self.dps[idx]['pose_list']
        # intrinsic_list = self.dps[idx]['intrinsic_list']

        rgb_list, depth_list, pose_list, intrinsic_list = self.change_to_sr([rgb_list, depth_list, pose_list, intrinsic_list])
        # import fbvscode
        # fbvscode.set_trace()
        views = []
        for i in inference_set + render_set:
            
            if 'nv' in data_dict.keys():
                rgb = rgb_all[i]
                depth = depth_all[i]
            else:
                rgb = imageio.imread(g_pathmgr.get_local_path(rgb_list[i])).astype(np.uint8) # / 256
                if depth_list[i].endswith('.npy'):
                    depth = np.load(g_pathmgr.get_local_path(depth_list[i]))
                else:
                    depth = imageio.imread(g_pathmgr.get_local_path(depth_list[i])).astype(np.float32) / 1000
            
            if intrinsic_raw is not None:
                intrinsic_ = np.array(intrinsic_raw).astype(np.float32)
                intrinsic = np.zeros((4,4)).astype(np.float32)
                intrinsic[:3,:3] = intrinsic_[:3,:3]
            else:
                intrinsic = np.loadtxt(g_pathmgr.get_local_path(intrinsic_list[i])).astype(np.float32)
            if len(pose_raw_list):
                camera_pose = np.array(pose_raw_list[i]).astype(np.float32)
            else:
                camera_pose = np.loadtxt(g_pathmgr.get_local_path(pose_list[i])).astype(np.float32)
            rgb = cv2.resize(rgb, (depth.shape[1], depth.shape[0]))

            rgb, depth, intrinsic = self._crop_resize_if_necessary(
                rgb, depth, intrinsic, resolution, rng=rng, info="[Empty]")
            if self.save_results:
                if i < len(rgb_list):
                    if 'gibson' in rgb_list[i]:
                        scene_name = rgb_list[i].split('/')[-2]
                    elif 'hm3d' in rgb_list[i]:
                        scene_name = rgb_list[i].split('/')[-3]
                    elif 'mp3d' in rgb_list[i]:
                        scene_name = rgb_list[i].split('/')[-2]
                    else:
                        scene_name = rgb_list[i].split('/')[-4]
                label=f"dataName_{self.tb_name}_id_{str(idx).zfill(9)}_sceneName_{scene_name}_refId_{str(ref_view_id).zfill(3)}"
            else:
                label=f"{str(idx).zfill(9)}"
                
            views.append(dict(
                random_nv_nr=np.array(random_nv_nr),
                img=rgb,
                depthmap=depth,
                camera_pose=camera_pose,
                camera_intrinsics=intrinsic,
                dataset=self.data_name,
                label=label,
                instance=str(idx),
                only_render = i in render_set,
                num_render_views = random_nv_nr[1],
                n_ref = self.n_ref,
                C_avg = C_avg,
            ))
        
        if ref_view_id != 0:
            views[0], views[ref_view_id] = deepcopy(views[ref_view_id]), deepcopy(views[0])

        if self.random_order:
            random.shuffle(views)
        else:
            views[0], views[1] = deepcopy(views[1]), deepcopy(views[0])
        
        if self.num_inference_views < 12:
            if len(views) > 3:
                views[1], views[3] = deepcopy(views[3]), deepcopy(views[1])
            
            if len(views) > 6:
                views[2], views[6] = deepcopy(views[6]), deepcopy(views[2])
        else:
            
            change_id = self.num_inference_views // 4 + 1
            views[1], views[change_id] = deepcopy(views[change_id]), deepcopy(views[1])
            change_id = (self.num_inference_views * 2) // 4 + 1
            views[2], views[change_id] = deepcopy(views[change_id]), deepcopy(views[2])
            change_id = (self.num_inference_views * 3) // 4 + 1
            views[3], views[change_id] = deepcopy(views[change_id]), deepcopy(views[3])

        views_inference, views_render = [], []
        for view in views:
            if view['only_render']:
                views_render.append(view)
            else:
                views_inference.append(view)
        views = views_inference + views_render
        assert len(views) == self.num_views
        
        return views

class ScannetPair(BaseStereoViewDataset):
    def __init__(self, mask_bg=True, *args, ROOT, n_test, **kwargs):
        self.ROOT = ROOT # 'manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/co3d_subset_processed'
        self.num_views = kwargs['num_views']
        super().__init__(*args, **kwargs)

        # load all scenes
        with g_pathmgr.open(osp.join(self.ROOT, f'dps.json'), 'r') as f: # self.split should be used here for data list.
            self.dps = json.load(f)
        test_id_list = [x * n_test for x in range(len(self.dps) // n_test)]
        # range(len(self.dps)) - test_id_list
        train_id_list = np.setdiff1d(np.arange(len(self.dps)), test_id_list)
        train_test_id_list = [x * n_test + 1 for x in range(len(self.dps) // n_test)]
        vis_list = [402123, 1085417, 726686, 1204925, 1457707, 363396, 542870, 203148]
        if self.split == "train":
            self.dps = [self.dps[x] for x in train_id_list]
        elif self.split == "train_test":
            self.dps = [self.dps[x] for x in train_test_id_list]
        elif self.split == "vis":
            self.dps = [self.dps[x] for x in vis_list]
        elif self.split == "test":
            self.dps = [self.dps[x] for x in test_id_list]

    def __len__(self):
        # print('scannetPair size', len(self.dps))
        return len(self.dps)

    def _get_views(self, idx, resolution, rng):


        rgb_list = self.dps[idx]['rgb_list']
        depth_list = self.dps[idx]['depth_list']
        pose_list = self.dps[idx]['pose_list']
        intrinsic_list = self.dps[idx]['intrinsic_list']

        views = []
        for i in range(self.num_views):
            
            rgb = imageio.imread(g_pathmgr.get_local_path(rgb_list[i])).astype(np.uint8) # / 256
            intrinsic = np.loadtxt(g_pathmgr.get_local_path(intrinsic_list[i])).astype(np.float32)
            camera_pose = np.loadtxt(g_pathmgr.get_local_path(pose_list[i])).astype(np.float32)
            depth = imageio.imread(g_pathmgr.get_local_path(depth_list[i])).astype(np.float32) / 1000
            rgb = cv2.resize(rgb, (depth.shape[1], depth.shape[0]))

            rgb, depth, intrinsic = self._crop_resize_if_necessary(
                rgb, depth, intrinsic, resolution, rng=rng, info="[Empty]")


            views.append(dict(
                img=rgb,
                depthmap=depth,
                camera_pose=camera_pose,
                camera_intrinsics=intrinsic,
                dataset='Scannet',
                label=str(idx),
                instance=str(idx),
            ))
        return views

class ScannetPairTest(BaseStereoViewDataset):
    def __init__(self, mask_bg=True, *args, ROOT, **kwargs):
        self.ROOT = ROOT # 'manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/co3d_subset_processed'
        self.num_views = kwargs['num_views']
        super().__init__(*args, **kwargs)

        # load all scenes
        with g_pathmgr.open(osp.join(self.ROOT, f'dps.json'), 'r') as f: # self.split should be used here for data list.
            choiced_list = [402123, 1085417, 726686, 1204925, 1457707, 363396, 542870, 203148]
            self.dps = json.load(f)
            self.dps = [self.dps[x] for x in choiced_list]

    def __len__(self):
        print('scannetPair size', len(self.dps))
        return len(self.dps)

    def _get_views(self, idx, resolution, rng):

        print('get views scannet pair', self.split, idx)
        rgb_list = self.dps[idx]['rgb_list']
        depth_list = self.dps[idx]['depth_list']
        pose_list = self.dps[idx]['pose_list']
        intrinsic_list = self.dps[idx]['intrinsic_list']

        views = []
        for i in range(self.num_views):
            
            rgb = imageio.imread(g_pathmgr.get_local_path(rgb_list[i])).astype(np.uint8) # / 256
            intrinsic = np.loadtxt(g_pathmgr.get_local_path(intrinsic_list[i])).astype(np.float32)
            camera_pose = np.loadtxt(g_pathmgr.get_local_path(pose_list[i])).astype(np.float32)
            depth = imageio.imread(g_pathmgr.get_local_path(depth_list[i])).astype(np.float32) / 1000
            rgb = cv2.resize(rgb, (depth.shape[1], depth.shape[0]))

            rgb, depth, intrinsic = self._crop_resize_if_necessary(
                rgb, depth, intrinsic, resolution, rng=rng, info="[Empty]")


            views.append(dict(
                img=rgb,
                depthmap=depth,
                camera_pose=camera_pose,
                camera_intrinsics=intrinsic,
                dataset='Scannet',
                label=str(idx),
                instance=str(idx),
            ))
        return views



def test():
    from dust3r.datasets.base.base_stereo_view_dataset import view_name
    from dust3r.viz import SceneViz, auto_cam_size
    from dust3r.utils.image import rgb

    # dataset = Co3d(split='train', ROOT="/home/zgtang/manifold_things/data/co3d_subset_processed", resolution=224, aug_crop=16)
    # dataset = Co3d(split='train', ROOT="/home/zgtang/manifold_things/data/co3d_subset_processed", resolution=224, aug_crop=16)
    dataset = Scannet(split='train', ROOT='/home/zgtang/manifold_things/data/scannet_middle', aug_crop=16, mask_bg='rand', resolution=224, num_views = 4)

    cnt = -1
    for idx in np.random.permutation(len(dataset)):
        cnt += 1
        if cnt == 10:
            break
        views = dataset[idx]
        assert len(views) == dataset.num_views
        # viz = SceneViz()
        poses = [views[view_idx]['camera_pose'] for view_idx in [0, 1]]
        cam_size = max(auto_cam_size(poses), 0.001)
        for view_idx in range(dataset.num_views):
            print(cnt, view_idx)
            id_name = str(cnt).zfill(6)
            import os
            data_name = "scannet"
            os.makedirs(f"/home/zgtang/manifold_things/data/data_vis/co3d", exist_ok=True)
            # rgbimg = [np.load(f"./data/{folder_name}/{scene_name}/{id_name}_rgb_{i}.npy") for i in range(n_v)]
            # pts3d = [np.load(f"./data/{folder_name}/{scene_name}/{id_name}_pcd_{i}.npy") for i in range(n_v)]
            # msk = [np.load(f"./data/{folder_name}/{scene_name}/{id_name}_valid_{i}.npy") > 0 for i in range(n_v)]
            # focals = [float(np.load(f"./data/{folder_name}/{scene_name}/{id_name}_focal_{i}.npy")) for i in range(n_v)]
            # cams2world = [np.load(f"./data/{folder_name}/{scene_name}/{id_name}_pose_{i}.npy") for i in range(n_v)]
            np.save(f"/home/zgtang/manifold_things/data/data_vis/{data_name}/{id_name}_rgb_{view_idx}.npy", rgb(views[view_idx]['img']))
            np.save(f"/home/zgtang/manifold_things/data/data_vis/{data_name}/{id_name}_pcd_{view_idx}.npy", views[view_idx]['pts3d'])
            np.save(f"/home/zgtang/manifold_things/data/data_vis/{data_name}/{id_name}_valid_{view_idx}.npy", views[view_idx]['valid_mask'])
            np.save(f"/home/zgtang/manifold_things/data/data_vis/{data_name}/{id_name}_pose_{view_idx}.npy", views[view_idx]['camera_pose'])
            np.save(f"/home/zgtang/manifold_things/data/data_vis/{data_name}/{id_name}_focal_{view_idx}.npy", views[view_idx]['camera_intrinsics'][0, 0])

            # pts3d = views[view_idx]['pts3d']
            # valid_mask = views[view_idx]['valid_mask']
            # colors = rgb(views[view_idx]['img'])
            # viz.add_pointcloud(pts3d, colors, valid_mask)
            # viz.add_camera(pose_c2w=views[view_idx]['camera_pose'],
            #                focal=views[view_idx]['camera_intrinsics'][0, 0],
            #                color=(idx*255, (1 - idx)*255, 0),
            #                image=colors,
            #                cam_size=cam_size)
        # viz.show()


if __name__ == "__main__":
    test()
