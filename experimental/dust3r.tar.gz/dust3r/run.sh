
# TODO

## generate videos of pointclouds. [D]
## make sure the test set is always the same set. [D]
## shrink the data [D]

torchx run -- -j 1x2 -m train.py -- --train_dataset "100 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \
--test_dataset "100 @ ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
100 @ ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
 --model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" --train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/checkpoints/DUSt3R_ViTLarge_BaseDecoder_224_linear.pth" --lr 0.0001 --min_lr 0.000001 --warmup_epochs 1 --epochs 10 --batch_size 4 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --output_dir torchx-dust3r_train-test_debug3 &> ~/manifold_things/temp8.txt



# finetune from 224 linear, 2x8

# sanity check with lr=0, 1x8

torchx run -s mast -- -h grandteton -j 1x8 -m train.py -- \
--train_dataset "100 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \drvrkjibdgvtnhehnhbjrticucchgjvl
--test_dataset "100 @ ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
100 @ ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/checkpoints/DUSt3R_ViTLarge_BaseDecoder_224_linear.pth" --lr 0.0 --min_lr 0.0 --warmup_epochs 1 --epochs 10 --batch_size 4 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 4 --output_dir torchx-dust3r_train-scannetPair_lr0

# debugging locally

torchx run -- -j 1x2 -m train.py -- \
--train_dataset "100 @ ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \
--test_dataset "100 @ ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/checkpoints/DUSt3R_ViTLarge_BaseDecoder_224_linear.pth" --lr 0.0001 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 4 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 8 --output_dir torchx-dust3r_train-scannetPair_debug_local

# sanity check with lr=1e-4, 1x8

torchx run -s mast -- -h grandteton -j 1x8 -m train.py -- \
--train_dataset "100 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \
--test_dataset "100 @ ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
100 @ ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/checkpoints/DUSt3R_ViTLarge_BaseDecoder_224_linear.pth" --lr 0.0001 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 4 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 4 --output_dir torchx-dust3r_train-scannetPair_smallScale_lr1e-4


# 0: a sanity check here: https://www.internalfb.com/manifold/explorer/ondevice_ai_writedata/tree/zgtang/dust3r/logs/torchx-dust3r_train-scannetPair_full_4x8_pretrain_nw8_lr1e-4
the loss is decreasing normally, test and train evaluation all decrease. can check detailed time usage here

# 1: large scale training, loading the pretrained, 1x8, worker=8, lr=0.00015
# just a sanity check to see whether the loss decrease. it should decrease.

torchx run -s mast -- -h grandteton -j 1x8 -m train.py -- \
--train_dataset "1000000 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \
--test_dataset "ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/checkpoints/DUSt3R_ViTLarge_BaseDecoder_224_linear.pth" --lr 0.00015 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 24 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 8 --output_dir torchx-dust3r_train-scannetPair_full_1x8_pretrain_nw8_lr1.5e-4


# 2: large scale training, from scratch, 1x8, worker=8, lr=0.00015
# this is used to compare with dust3r training metrics.

torchx run -s mast -- -h grandteton -j 1x8 -m train.py -- \
--train_dataset "1000000 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \
--test_dataset "ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --lr 0.00015 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 24 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 8 --output_dir torchx-dust3r_train-scannetPair_full_1x8_pretrain_nw8_lr1.5e-4


# 3: large scale training, from scratch, 1x8, worker=16, lr=0.00015
# comparing with 2, checking whether this makes data loading faster.

torchx run -s mast -- -h grandteton -j 1x8 -m train.py -- \
--train_dataset "1000000 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \
--test_dataset "ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --lr 0.00015 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 24 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 16 --output_dir torchx-dust3r_train-scannetPair_full_1x8_pretrain_nw16_lr1.5e-4

# 3.1 worker=32
# around 10pm~11pm

torchx run -s mast -- -h grandteton -j 1x8 -m train.py -- \
--train_dataset "1000000 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \
--test_dataset "ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --lr 0.00015 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 24 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 32 --output_dir torchx-dust3r_train-scannetPair_full_1x8_pretrain_nw32_lr1.5e-4

# 3.2 another one of worker=16
# around 11pm

torchx run -s mast -- -h grandteton -j 1x8 -m train.py -- \
--train_dataset "1000000 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \
--test_dataset "ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --lr 0.00015 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 24 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 32 --output_dir torchx-dust3r_train-scannetPair_full_1x8_pretrain_nw16_lr1.5e-4_2

# 4: large scale training, from scratch, 4x8, worker=8, lr=0.0006
# comparing with 2, checking whether this makes data loading faster.

torchx run -s mast -- -h grandteton -j 4x8 -m train.py -- \
--train_dataset "1000000 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \
--test_dataset "ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --lr 0.0006 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 24 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 8 --output_dir torchx-dust3r_train-scannetPair_full_4x8_pretrain_nw8_lr6e-4

# 4.1 lr=0.0003

torchx run -s mast -- -h grandteton -j 4x8 -m train.py -- \
--train_dataset "1000000 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \
--test_dataset "ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --lr 0.0003 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 24 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 8 --output_dir torchx-dust3r_train-scannetPair_full_4x8_pretrain_nw8_lr3e-4

# 4.2 11:07pm
torchx run -s mast -- -h grandteton -j 4x8 -m train.py -- \
--train_dataset "1000000 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \
--test_dataset "ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --lr 0.0006 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 24 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 8 --output_dir torchx-dust3r_train-scannetPair_full_4x8_pretrain_nw8_lr6e-4_grad_norm_record

# 4.2.1
torchx run -s mast -- -h grandteton -j 4x8 -m train.py -- \
--train_dataset "100000 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=2)" \
--test_dataset "ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --lr 0.0006 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 100 --batch_size 24 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 8 --output_dir torchx-dust3r_train-scannetPair_full_4x8_pretrain_nw8_lr6e-4_grad_norm_record_2

# 5 loading from 1, nk=24
# 1 name: ondevice_ai_writedata/tree/zgtang/dust3r/logs/torchx-dust3r_train-scannetPair_full_1x8_pretrain_nw8_lr1.5e-4/checkpoint-final.pth

torchx run -s mast -- -h grandteton -j 4x8 -m train.py -- \
--train_dataset "1000000 @ ScannetPair(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', aug_crop=16, resolution=[(512, 384), (512, 336), (512, 288), (512, 256), (512, 160)], transform=ColorJitter, num_views=2)" \
--test_dataset "ScannetPair(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=(512,384), seed=777, fix_order=True, num_views=2) + \
ScannetPair(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=(512,384), seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=2) + \
ScannetPair(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=(512,384), seed=777, fix_order=True, num_views=2)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', patch_embed_cls='ManyAR_PatchEmbed', img_size=(512, 512), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis'), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/logs/torchx-dust3r_train-scannetPair_full_1x8_pretrain_nw8_lr1.5e-4/checkpoint-final.pth" --lr 0.00015 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 4 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 24 --output_dir torchx-dust3r_train-scannetPair-2nd_full_4x8_nw24_lr1.5e-4


## MV starts here

# 0 local debug

torchx run -- -j 1x1 -m train.py -- \
--train_dataset "100 @ Scannet(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=4)" \
--test_dataset "100 @ Scannet(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=4) + \
Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=4) + \
100 @ Scannet(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/manifold_things/data/scannet_pair', resolution=224, seed=777, fix_order=True, num_views=4)" \
--model "AsymmetricCroCo3DStereoMultiView(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis', mv = True), alpha=0.2)"     --test_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis', mv = True), alpha=0.2)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/checkpoints/DUSt3R_ViTLarge_BaseDecoder_224_linear.pth" --lr 0.00015 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 4 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 8 --output_dir torchx-dust3r_train-scannet_debug

# 0.1 large scale train

torchx run -s mast -- -h grandteton -j 4x8 -m train.py -- \
--train_dataset "Scannet(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=4)" \
--test_dataset "Scannet(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', resolution=224, seed=777, fix_order=True, num_views=4) + \
Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=4) + \
Scannet(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', resolution=224, seed=777, fix_order=True, num_views=4)" \
--model "AsymmetricCroCo3DStereoMultiView(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis', mv = True), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True, mv = True)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/checkpoints/DUSt3R_ViTLarge_BaseDecoder_224_linear.pth" --lr 0.00015 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 20 --batch_size 4 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 16 --output_dir torchx-dust3r_train-scannet_4x8

# 0.2 debug locally, inference on global optimization

torchx run -- -j 1x1 -m inference_global_optimization_batch.py -- \
--train_dataset "100 @ Scannet(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=4)" \
--test_dataset "100 @ Scannet(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', resolution=224, seed=777, fix_order=True, num_views=4) + \
Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=4) + \
100 @ Scannet(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', resolution=224, seed=777, fix_order=True, num_views=4)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis', mv = True), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True, mv = True)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/checkpoints/DUSt3R_ViTLarge_BaseDecoder_224_linear.pth" --lr 0.00015 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 10 --batch_size 2 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 8 --output_dir torchx-dust3r_train-scannet_debug_go

# 1 finetune on higher resolution

torchx run -- -j 1x2 -m train.py -- \
--train_dataset "Scannet(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', aug_crop=16, resolution=[(512, 384), (512, 336), (512, 288), (512, 256), (512, 160)], transform=ColorJitter, num_views=4)" \
--test_dataset "10 @ Scannet(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', resolution=(512,384), seed=777, fix_order=True, num_views=4) + \
10 @ Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', resolution=(512,384), seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=4) + \
10 @ Scannet(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', resolution=(512,384), seed=777, fix_order=True, num_views=4)" \
--model "AsymmetricCroCo3DStereoMultiView(pos_embed='RoPE100', patch_embed_cls='ManyAR_PatchEmbed', img_size=(512, 512), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis', mv = True), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True, mv = True)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/checkpoints/DUSt3R_ViTLarge_BaseDecoder_224_linear.pth" --lr 0.00015 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 20 --batch_size 4 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 16 --output_dir torchx-dust3r_train-scannet_2nd_1x2_local


torchx run -s mast -- -h grandteton -j 4x8 -m train.py -- \
--train_dataset "Scannet(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', aug_crop=16, resolution=[(512, 384), (512, 336), (512, 288), (512, 256), (512, 160)], transform=ColorJitter, num_views=4)" \
--test_dataset "Scannet(n_test=1000, split='train_test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', resolution=(512,384), seed=777, fix_order=True, num_views=4) + \
Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', resolution=(512,384), seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=4) + \
Scannet(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', resolution=(512,384), seed=777, fix_order=True, num_views=4)" \
--model "AsymmetricCroCo3DStereoMultiView(pos_embed='RoPE100', patch_embed_cls='ManyAR_PatchEmbed', img_size=(512, 512), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis', mv = True), alpha=0.2)"     --test_criterion "Regr3D_ScaleShiftInv(L21, gt_scale=True, mv = True)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/checkpoints/DUSt3R_ViTLarge_BaseDecoder_224_linear.pth" --lr 0.00015 --min_lr 0.000001 \
--warmup_epochs 1 --epochs 20 --batch_size 4 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 16 --output_dir torchx-dust3r_train-scannet_2nd_4x8


# 7.15 TODO:
## visualization of pcd of MV, correct testing. [Done, training here done]
## scannet++ data [not good, waiting downloading again, downloading again]
## web for videos [done]
## gaussian spatting, first asking yuchen with scannet++ problem together.

# 7.16

## inference by dust3r or MV-dust3r, comparison needed. [done]

### batch inference
### dataloader for inference

## (some details may need to be added:

### data aug
### redefine training and test set [1]
### may need let the network know which is canonical view, which is src view during attention.
### note that 1st stage dust3r training is not from scratch but loaded from --pretrained="checkpoints/CroCo_V2_ViTLarge_BaseDecoder.pth", need fix it later.
### other parameters like warmup_epochs, epoch size are not the same.

## finetuning on higher resolution. [done, looks normal]


# 7.21

# check why scannet_4x8 failed (stuck after 3 epochs) [0, running]

# ScanNet++ dataset downloading and processing [1. do now]
# impl of global adjustment for baseline Dust3R [2. debug here, should be finished today]
# Novel view synthesis task eval impl
# solve the rebase problem with hongyu [2.5]
# Gaussian splatting component impl [start implementing tomorrow]
# better html [3. should be after rebase, should be finished today]
# [optional] improve 4-view Dust3R training recipe [if today we have time, do this: check the loading data speed, seems it is the bottleneck]


## GS

# maybe we need concat image to later decoder because they need to decode the color.
# may need pcd and gs head communication
