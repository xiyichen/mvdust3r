# EVALUATE


# evaluate skip

torchx run -s mast -- -h grandteton -j 4x8 -m train.py -- \
--train_dataset "16700 @ Scannet(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_12', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False) + \
16700 @ Scannet(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_12', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False) + \
25000 @ Scannet(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannetpp_large_easy_16', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, split_thres=0.99) + \
67000 @ Scannet(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_large', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, split_thres=0.98, render_start = 8) + \
67000 @ Scannet(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_tree_large', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, split_thres=0.98, render_start = 8) + \
25000 @ Scannet(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannetpp_large_easier_16', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, split_thres=0.99)" \
--test_dataset "Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_tree_large', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=8, num_render_views=0, n_vis_test=32, n_vis_train=32, split_thres = 0.5, render_start = 8, tb_name = 'hs_tree') + \
Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_large', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=8, num_render_views=0, n_vis_test=32, n_vis_train=32, split_thres = 0.5, render_start = 8, tb_name = 'hs_first') + \
Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_16', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=10, num_render_views=2, n_vis_test=56, n_vis_train=8, split_thres = 0.8, render_start = 12, tb_name = 'vis_easy_16') + \
Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_16', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=10, num_render_views=2, n_vis_test=56, n_vis_train=8, split_thres = 0.91, render_start = 12, tb_name = 'vis_easier_16') + \
Scannet(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_12', resolution=224, seed=777, fix_order=True, num_views=10, num_render_views=2, random_order = False, tb_name = 'test_easy_12') + \
Scannet(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_16', resolution=224, seed=777, fix_order=True, num_views=8, num_render_views=0, random_order = False, tb_name = 'test_easy_16') + \
Scannet(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_16', resolution=224, seed=777, fix_order=True, num_views=8, num_render_views=0, random_order = False, tb_name = 'test_easier_16')" \
--model "AsymmetricCroCo3DStereoMultiView(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, 1e9), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12, GS = True, sh_degree=0, pts_head_config = {'skip':True})" \
--train_criterion "GSRenderLoss(L21, norm_mode='avg_dis', mv = True, scale_scaled = True, use_gt_pcd = False, lpips_coeff = 1.0, rgb_coeff = 1.0, use_img_rgb = True, local_loss_coeff=0.0) + ConfLoss(Regr3D(L21, norm_mode='avg_dis', mv = True), alpha=0.2)" \
--test_criterion "GSRenderLoss(L21, norm_mode='avg_dis', mv = True, render_included = True, scale_scaled = True, use_img_rgb = True, local_loss_coeff=0.0) + Regr3D_ScaleShiftAllInv(L21, gt_scale=True, mv = True)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/logs/torchx-dust3r_train-scannetHuge_hard_4x8_GS_sh1_bs16_mv10_2_rr_1e-4_4e-3_use_img_rgb_lpips_1_rgb_1_fs_spp_hs_double_full_skip_new/checkpoint-20.pth" \
--lr 0.00015 --min_lr 0.000001 --warmup_epochs 1 --epochs 100 --batch_size 8 --accum_iter 4 --save_freq 1 --keep_freq 5 --eval_freq 2 --num_workers 16 --only_test 1 \
--output_dir torchx-dust3r_full_skip_load

# evaluate GO

torchx run -s mast -- -h grandteton -j 4x8 -m inference_global_optimization_batch.py -- \
--train_dataset "100 @ Scannet(n_test=1000, split='train', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=4)" \
--test_dataset "Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_16', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=8, num_render_views=0, n_vis_test=56, n_vis_train=8, split_thres = 0.8, render_start = 12) + \
Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_16', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=8, num_render_views=0, n_vis_test=56, n_vis_train=8, split_thres = 0.91, render_start = 12) + \
Scannet(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_16', resolution=224, seed=777, fix_order=True, num_views=8, num_render_views=0, random_order = False)" \
--model "AsymmetricCroCo3DStereo(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, inf), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12)" \
--train_criterion "ConfLoss(Regr3D(L21, norm_mode='avg_dis', mv = True), alpha=0.2)" \
--test_criterion "GSRenderLoss(L21, norm_mode='avg_dis', mv = True, render_included = True, scale_scaled = True, use_img_rgb = True) + Regr3D_ScaleShiftAllInv(L21, gt_scale=True, mv = True)" \
--pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/checkpoints/DUSt3R_ViTLarge_BaseDecoder_224_linear.pth" \
--lr 0.00015 --min_lr 0.000001 --warmup_epochs 1 --epochs 10 --batch_size 2 --accum_iter 1 --save_freq 1 --keep_freq 5 --eval_freq 1 --num_workers 8 --output_dir torchx-dust3r_train-scannet_go_mv_new

# TRAIN

# MV-dust3r

<!-- scannet: 1.0
scannetpp: 0.4
habitat: 1.0
15w in sum for one epoch
-->

torchx run -- -j 1x2 -m train.py -- \
torchx run -s mast -- -h grandteton -j 4x8 -m train.py --max_retries 2 -- \
--train_dataset " \
15000 @ Scannet(split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_huge_3.0', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, dps_name = 'dps_train.h5', random_nv_nr = [[5,1],[10,2]]) + \
15000 @ Scannet(split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_huge_easy_3.0', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, dps_name = 'dps_train.h5', random_nv_nr = [[5,1],[10,2]]) + \
15000 @ Scannet(split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_12_3.0', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, dps_name = 'dps_train.h5', random_nv_nr = [[5,1],[10,2]]) + \
15000 @ Scannet(split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_12_3.0', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, dps_name = 'dps_train.h5', random_nv_nr = [[5,1],[10,2]]) + \
15000 @ Scannet(split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannetpp_large_easy_16_3.0', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, dps_name = 'dps_train.h5', random_nv_nr = [[5,1],[10,2]]) + \
15000 @ Scannet(split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannetpp_large_easier_16_3.0', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, dps_name = 'dps_train.h5', random_nv_nr = [[5,1],[10,2]]) + \
15000 @ Scannet(split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_3.0', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, render_start = 8, dps_name = 'dps_train.h5', random_nv_nr = [[5,1],[10,2]]) + \
15000 @ Scannet(split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_tree_3.0', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, render_start = 8, dps_name = 'dps_train.h5', random_nv_nr = [[5,1],[10,2]]) + \
15000 @ Scannet(split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_chain_3.0', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, render_start = 8, dps_name = 'dps_train.h5', random_nv_nr = [[5,1],[10,2]]) + \
15000 @ Scannet(split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_tree_last_3.0', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, render_start = 8, dps_name = 'dps_train.h5', random_nv_nr = [[5,1],[10,2]]) + \
15000 @ Scannet(split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_tree_diverse_first_3.0', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, render_start = 8, dps_name = 'dps_train.h5', random_nv_nr = [[5,1],[10,2]]) + \
15000 @ Scannet(split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_tree_diverse_first_2_3.0', aug_crop=16, mask_bg='rand', resolution=224, transform=ColorJitter, num_views=10, num_render_views=2, random_order = True, random_render_order = False, render_start = 8, dps_name = 'dps_train.h5', random_nv_nr = [[5,1],[10,2]])" \
--test_dataset " \
Scannet(n_all=32, split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_tree_3.0', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=8, num_render_views=0, render_start = 8, dps_name = 'dps_train.h5', tb_name = 'hs_tree_train') + \
Scannet(n_all=32, split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_3.0', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=8, num_render_views=0, render_start = 8, dps_name = 'dps_train.h5', tb_name = 'hs_train') + \
Scannet(n_all=32, split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_chain_3.0', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=8, num_render_views=0, render_start = 8, dps_name = 'dps_train.h5', tb_name = 'hs_chain_train') + \
Scannet(n_all=32, split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_tree_diverse_first_2_3.0', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=8, num_render_views=0, render_start = 8, dps_name = 'dps_train.h5', tb_name = 'hs_tdf_2_train') + \
Scannet(n_all=32, split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_huge_3.0', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=5, num_render_views=1, render_start = 4, dps_name = 'dps_train.h5', tb_name = 'sc_4_hard_train') + \
Scannet(n_all=32, split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_12_3.0', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=10, num_render_views=2, render_start = 8, dps_name = 'dps_train.h5', tb_name = 'sc_8_easy_train') + \
Scannet(n_all=32, split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_5_test_3.0', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=5, num_render_views=1, render_start = 4, dps_name = 'dps_test.h5', tb_name = 'sc_4_hard_test') + \
Scannet(n_all=32, split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_15_test_3.0', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=10, num_render_views=2, render_start = 8, dps_name = 'dps_test.h5', tb_name = 'sc_8_easy_test') + \
Scannet(n_all=1000, split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_5_test_3.0', resolution=224, seed=777, fix_order=True, num_views=5, num_render_views=1, random_order = False, tb_name = 'sc_4_hard_testFull') + \
Scannet(n_all=1000, split='all', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_15_test_3.0', resolution=224, seed=777, fix_order=True, num_views=10, num_render_views=2, random_order = False, tb_name = 'sc_8_easy_testFull')" \
--model "AsymmetricCroCo3DStereoMultiView(pos_embed='RoPE100', img_size=(224, 224), head_type='linear', output_mode='pts3d', depth_mode=('exp', -inf, inf), conf_mode=('exp', 1, 1e9), enc_embed_dim=1024, enc_depth=24, enc_num_heads=16, dec_embed_dim=768, dec_depth=12, dec_num_heads=12, GS = True, sh_degree=0, pts_head_config = {'skip':True})" \
--train_criterion "GSRenderLoss(L21, norm_mode='avg_dis', mv = True, scale_scaled = True, use_gt_pcd = False, lpips_coeff = 1.0, rgb_coeff = 1.0, use_img_rgb = True, local_loss_coeff=0.0) + ConfLoss(Regr3D(L21, norm_mode='avg_dis', mv = True), alpha=0.2)" \
--test_criterion "GSRenderLoss(L21, norm_mode='avg_dis', mv = True, render_included = True, scale_scaled = True, use_img_rgb = True, local_loss_coeff=0.0) + Regr3D_ScaleShiftInv(L21, gt_scale=True, mv = True)" --pretrained "manifold://ondevice_ai_writedata/tree/zgtang/dust3r/checkpoints/DUSt3R_ViTLarge_BaseDecoder_224_linear.pth" \
--lr 0.00015 --min_lr 0.000001 --warmup_epochs 1 --epochs 100 --batch_size 8 --accum_iter 2 --save_freq 1 --keep_freq 5 --eval_freq 2 --num_workers 16 \
--output_dir MV-dust3r




Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/hs_large', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=8, num_render_views=0, n_vis_test=32, n_vis_train=32, split_thres = 0.5, render_start = 8, tb_name = 'hs_first') + \
Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_16', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=10, num_render_views=2, n_vis_test=56, n_vis_train=8, split_thres = 0.8, render_start = 12, tb_name = 'vis_easy_16') + \
Scannet(n_test=1000, split='vis', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_16', resolution=224, seed=777, fix_order=True, save_results=True, save_prefix='test', num_views=10, num_render_views=2, n_vis_test=56, n_vis_train=8, split_thres = 0.91, render_start = 12, tb_name = 'vis_easier_16') + \
Scannet(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_12', resolution=224, seed=777, fix_order=True, num_views=10, num_render_views=2, random_order = False, tb_name = 'test_easy_12') + \
Scannet(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easy_16', resolution=224, seed=777, fix_order=True, num_views=8, num_render_views=0, random_order = False, tb_name = 'test_easy_16') + \
Scannet(n_test=1000, split='test', ROOT='manifold://ondevice_ai_writedata/tree/zgtang/dust3r/data/scannet_large_easier_16', resolution=224, seed=777, fix_order=True, num_views=8, num_render_views=0, random_order = False, tb_name = 'test_easier_16')" \
