#!/bin/bash

# n_job=11
# n_v=5
# n_render=1
# data_type=scannet
# hardness=hard
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet2.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done


# n_job=11
# n_v=15
# n_render=3
# data_type=scannet
# hardness=easy
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet2.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done


# n_job=11
# n_v=15
# n_render=3
# data_type=scannet
# hardness=easier
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet2.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done


# n_job=44
# n_v=24
# n_render=0
# data_type=scannet
# hardness=easy
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet2.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done

# n_job=11
# n_v=5
# n_render=1
# data_type=scannet
# hardness=easy
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet2.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done


# n_job=11
# n_v=15
# n_render=3
# data_type=scannet
# hardness=0.3_0.6
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet2.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done


# n_job=11
# n_v=15
# n_render=3
# data_type=scannet
# hardness=0.3_0.7
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet3.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done


# n_job=79
# n_v=30
# n_render=6
# data_type=scannet
# hardness=0.3_0.7
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet3.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done

# n_job=55
# n_v=30
# n_render=6
# data_type=scannet
# hardness=0.2999_0.7
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet2.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done

# n_job=10
# n_v=12
# n_render=0
# data_type=scannet
# hardness=0.8_1.0
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet_adj.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done

# n_job=10
# n_v=12
# n_render=0
# data_type=scannet
# hardness=0.9_1.0
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet_adj.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done

# n_job=10
# n_v=12
# n_render=0
# data_type=scannet
# hardness=0.95_1.0
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet_adj.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done

n_job=10
n_v=100
n_render=0
data_type=scannet
hardness=0.0_1.0
split=test
n_tuple_per_scene=1 # 292 scens, 292 * 40 > 10000

for ((i=0; i<n_job; i++))
do
  echo $((8 * n_job)) $i
  torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet_adj2.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
done

# n_job=11
# n_v=15
# n_render=3
# data_type=scannet
# hardness=0.2_0.6
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet2.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done

# n_job=11
# n_v=15
# n_render=3
# data_type=scannet
# hardness=0.2_0.5
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet2.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done

# n_job=11
# n_v=15
# n_render=3
# data_type=scannet
# hardness=0.1_0.5
# split=test
# n_tuple_per_scene=40 # 292 scens, 292 * 40 > 10000

# for ((i=0; i<n_job; i++))
# do
#   echo $((8 * n_job)) $i
#   torchx run -s mast -- -h zion_2s -j 1x8 -m datasets_preprocess/preproc_scannet2.py -- --div $((8 * n_job)) --node-no $i --n-v $n_v --n-render $n_render --data-type $data_type --hardness $hardness --split $split --n-tuple-per-scene $n_tuple_per_scene
# done
