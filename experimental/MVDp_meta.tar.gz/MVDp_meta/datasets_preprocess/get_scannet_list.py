import glob
import os, sys
import json
import numpy as np
import torch
import h5py

import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--data-name")
# parser.add_argument("--node-no", default=0, type=int)
args = parser.parse_args()

def tuple4():
    dps = []
    metadata_list = glob.glob("/home/zgtang/manifold_things/data/scannet_middle/*/*extra.json")
    sorted(metadata_list)
    for x in metadata_list:
        try:
            dp = {}
            dp['scene_name'] = x.split('/')[-2]
            print(dp['scene_name'], x)
            x = json.load(open(x, 'r'))
            print(x['rgb_list'], x['depth_list'], x['pose_list'])
            print(x['intrinsic_list'])
            dp['rgb_list'] = x['rgb_list']
            dp['depth_list'] = x['depth_list']
            dp['pose_list'] = x['pose_list']
            dp['intrinsic_list'] = x['intrinsic_list']
            dps.append(dp)
            print('A')
        except:
            pass
    json.dump(dps, open("/home/zgtang/manifold_things/data/scannet_middle/dps.json", 'w'), indent=4)

def tuple2():
    dps = []
    metadata_list = glob.glob("/home/zgtang/manifold_things/data/scannet_pair/*/*extra.json")
    sorted(metadata_list)
    print(len(metadata_list))
    # exit(0)
    for x_id, x in enumerate(metadata_list):
        try:
            dp = {}
            dp['scene_name'] = x.split('/')[-2]
            # print(dp['scene_name'], x)
            x = json.load(open(x, 'r'))
            # print(x['rgb_list'], x['depth_list'], x['pose_list'])
            # print(x['intrinsic_list'])
            dp['rgb_list'] = x['rgb_list']
            dp['depth_list'] = x['depth_list']
            dp['pose_list'] = x['pose_list']
            dp['intrinsic_list'] = x['intrinsic_list']
            dps.append(dp)
            # print('A')
        except:
            pass
    json.dump(dps, open("/home/zgtang/manifold_things/data/scannet_pair/dps.json", 'w'), indent=4)

def tuple4_large():
    dps = []
    metadata_list = glob.glob("/home/zgtang/manifold_things/data/scannet_large2/*/*extra.pt")
    sorted(metadata_list)
    print(len(metadata_list))
    for x_id, x in enumerate(metadata_list):
        dp = {}
        dp['scene_name'] = x.split('/')[-2]
        # print(dp['scene_name'], x)
        x = torch.load(x)
        # print(x['rgb_list'], x['depth_list'], x['pose_list'])
        # print(x['intrinsic_list'])
        dp['rgb_list'] = x['rgb_list']
        dp['depth_list'] = x['depth_list']
        dp['pose_list'] = x['pose_list']
        dp['intrinsic_list'] = x['intrinsic_list']
        dps.append(dp)
        print(x_id)
    json.dump(dps, open("/home/zgtang/manifold_things/data/scannet_large2/dps.json", 'w'), indent=4) # 143744 tuple, 140 scenes

def tuple4_huge():
    dps = []
    # metadata_list = glob.glob("/home/zgtang/scannet_large_easy/*/*extra.pt")
    metadata_list = glob.glob("/home/zgtang/scannet_large/*/*extra.pt")
    sorted(metadata_list)
    print(len(metadata_list))
    scene_cnt = {}
    for x_id, x in enumerate(metadata_list):
        dp = {}
        dp['scene_name'] = x.split('/')[-2]
        if dp['scene_name'] not in scene_cnt.keys():
            scene_cnt[dp['scene_name']] = 1
        else:
            scene_cnt[dp['scene_name']] += 1
        
        # print(dp['scene_name'], x)
        x = torch.load(x)
        # print(x['rgb_list'], x['depth_list'], x['pose_list'])
        # print(x['intrinsic_list'])
        dp['rgb_list'] = x['rgb_list']
        dp['depth_list'] = x['depth_list']
        dp['pose_list'] = x['pose_list']
        dp['intrinsic_list'] = x['intrinsic_list']
        dps.append(dp)
        if x_id % 10000 == 0:
            print(len(scene_cnt.keys()), scene_cnt)
            print(x_id)
    # json.dump(dps, open("/home/zgtang/scannet_large_easy/dps.json", 'w'), indent=4) # 134000, 1341
    json.dump(dps, open("/home/zgtang/scannet_large/dps.json", 'w'), indent=4) # 

def tuple4_huge_tar():
    dps = []
    metadata_list = glob.glob("/home/zgtang/scannet_large_easy2/*/*extra.pt")
    # metadata_list = glob.glob("/home/zgtang/scannet_large2/*/*extra.pt")
    sorted(metadata_list)
    print(len(metadata_list))
    scene_cnt = {}
    for x_id, x in enumerate(metadata_list[:]):
        dp = {}
        scene_name = x.split('/')[-2]
        dp['scene_name'] = scene_name
        tar_root = "manifold://on_device_sr/tree/datasets/scannet/scans_tar"
        dp['tar_name'] = f"{tar_root}/{scene_name}.tar"
        if dp['scene_name'] not in scene_cnt.keys():
            scene_cnt[dp['scene_name']] = 1
        else:
            scene_cnt[dp['scene_name']] += 1
        
        # print(dp['scene_name'], x)
        x = torch.load(x)
        # print(x['rgb_list'], x['depth_list'], x['pose_list'])
        # print(x['intrinsic_list'])
        dp['rgb_list'] = [f"{scene_name}/frames/color/{os.path.basename(y)}" for y in x['rgb_list']]
        dp['depth_list'] = [f"{scene_name}/frames/depth/{os.path.basename(y)}" for y in x['depth_list']]
        dp['pose_list'] = [f"{scene_name}/frames/pose/{os.path.basename(y)}" for y in x['pose_list']]
        dp['intrinsic_list'] = [f"{scene_name}/frames/intrinsic/{os.path.basename(y)}" for y in x['intrinsic_list']]
        dps.append(dp)
        if x_id % 10000 == 0:
            print(len(scene_cnt.keys()), scene_cnt)
            print(x_id)
    # json.dump(dps, open("/home/zgtang/scannet_large_easy/dps.json", 'w'), indent=4) # 134000, 1341
    # json.dump(dps, open("/home/zgtang/scannet_huge/dps.json", 'w'), indent=4)
    json.dump(dps, open("/home/zgtang/scannet_huge_easy/dps.json", 'w'), indent=4)


def extract_scene_name(x, data_name_):
    print(x, data_name_)
    if "_meta" == data_name_[-5:]:
        data_name = data_name_[:-5]
    else:
        data_name = data_name_
    # print('extract', x, data_name)
    if "scannet_dataset" in x:
        x = x.replace('manifold://scannet_dataset/tree/scans/', '')
        # "manifold://scannet_dataset/tree/scans/scene0000_00/frames/color/1660.jpg"
        result = x.split('/')[0]
    elif "scannetpp" in x:
        # x = x.replace('manifold://ondevice_ai_writedata/tree/zgtang/data/scannetpp/data/', '')
        x = x.replace('manifold://ondevice_ai_writedata/tree/zgtang/data/scannetpp/data/', 'scannetpp/') # a hack, all scannetpp should be train
        # manifold://ondevice_ai_writedata/tree/zgtang/data/scannetpp/data/09c1414f1b/iphone/rgb/frame_002770.jpg
        result = x.split('/')[0]
    elif "habitat_sim" in x:
        # x = x.replace('manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/hs/gibson/', '')
        x = x.replace(f'manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/{data_name}/gibson/', 'gibson/') # a hack, all gibson should be train
        x = x.replace(f'manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/{data_name}/hm3d/val/', '')
        x = x.replace(f'manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/{data_name}/hm3d/train/', '')
        x = x.replace(f'manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/{data_name}/mp3d/', '')
        # manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/hs/gibson/Aldrich/00000000.png
        # manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/hs/hm3d/val/00899-58NLZxWBSpk/58NLZxWBSpk.basis/00001997.png
        # manifold://ondevice_ai_writedata/tree/zgtang/data/habitat_sim/hs/hm3d/train/00009-vLpv2VX547B/vLpv2VX547B.basis/00000575.png
        result = x.split('/')[0]
    if result[:len("manifold")] == "manifold":
        raise NotImplementedError
    return result

# /home/zgtang/misc/train_name_list.json
train_name_list = json.load(open("/home/zgtang/misc/train_name_list.json", 'r'))

def split_dps(x, dir_name):
    data_train = []
    data_test = []
    for (d_id, d) in enumerate(x):
        rgb_path = d['rgb_list'][0]
        data_name = extract_scene_name(rgb_path, args.data_name)
        if data_name in train_name_list:
            data_train.append(d)
        else:
            data_test.append(d)
    
    print('train', len(data_train), 'test', len(data_test))
    json.dump(data_train[::1000], open(f"{dir_name}/dps_train_sample.json", 'w'), indent=4)
    json.dump( data_test[::1000], open(f"{dir_name}/dps_test_sample.json", 'w'), indent=4)

    if len(data_train):
        print('dumping train')
        json_strs = [json.dumps(x) for x in data_train]
        ma_len = max(map(len, json_strs))
        json_strs = np.array(json_strs, dtype='S'+str(ma_len))
        with h5py.File(f"{dir_name}/dps_train.h5", 'w') as f:
            f.create_dataset('json_strs', data=json_strs, compression='gzip')
    
    if len(data_test):
        print('dumping test')
        json_strs = [json.dumps(x) for x in data_test]
        ma_len = max(map(len, json_strs))
        json_strs = np.array(json_strs, dtype='S'+str(ma_len))
        with h5py.File(f"{dir_name}/dps_test.h5", 'w') as f:
            f.create_dataset('json_strs', data=json_strs, compression='gzip')


def tuple_n_general(data_name):
    
    dps = []
    # metadata_list = glob.glob("/home/zgtang/scannet_large_easy/*/*extra.pt")
    pt_name = f"/home/zgtang/{data_name}/*/*extra.pt"
    metadata_list = []
    for i in range(6):
        # print(pt_name)
        metadata_list = metadata_list + glob.glob(pt_name)
        pt_name = pt_name.replace("/*extra.pt", "/*/*extra.pt")
    sorted(metadata_list)
    print('tuple in sum', len(metadata_list))
    
    scene_cnt = {}
    for x_id, x in enumerate(metadata_list[::100]):
        dp = {}
        dp['scene_name'] = x.split('/')[-2]
        if dp['scene_name'] not in scene_cnt.keys():
            scene_cnt[dp['scene_name']] = 1
        else:
            scene_cnt[dp['scene_name']] += 1
    print('scene in sum', len(list(scene_cnt.keys())))
        
    scene_cnt = {}
    cnt_failed = 0
    for x_id, x_ in enumerate(metadata_list[:]):
        try:
            x = torch.load(x_)
            # print(x_)
            dp = {}
            dp['scene_name'] = x_.split('/')[-2]
            if dp['scene_name'] not in scene_cnt.keys():
                scene_cnt[dp['scene_name']] = 1
            else:
                scene_cnt[dp['scene_name']] += 1
            
            # print(dp['scene_name'], x)
            # print(x['rgb_list'], x['depth_list'], x['pose_list'])
            # print(x['intrinsic_list'])
            dp['rgb_list'] = x['rgb_list']
            dp['depth_list'] = x['depth_list']
            if 'pose_raw_list' in x.keys():
                dp['pose_raw_list'] = x['pose_raw_list']
            else:
                dp['pose_list'] = x['pose_list']
            if "nv" in x.keys():
                dp['nv'] = x['nv']
            if "intrinsic_raw" in x.keys():
                dp['intrinsic_raw'] = x['intrinsic_raw']
            else:
                dp['intrinsic_list'] = x['intrinsic_list']
            C = np.round(np.array(x['C']), 2).tolist()
            dp['C'] = C
            dps.append(dp)
            if x_id % 10000 == 0:
                print(len(scene_cnt.keys()), scene_cnt)
                print(x_id, cnt_failed)
        except:
            cnt_failed += 1
        
    # json.dump(dps, open("/home/zgtang/scannet_large_easy/dps.json", 'w'), indent=4) # 134000, 1341
    json.dump(dps, open(f"/home/zgtang/{data_name}/dps.json", 'w'), indent=4)
    json_strs = [json.dumps(x) for x in dps]
    ma_len = max(map(len, json_strs))
    json_strs = np.array(json_strs, dtype='S'+str(ma_len))
    with h5py.File(f"/home/zgtang/{data_name}/dps.h5", 'w') as f:
        f.create_dataset('json_strs', data=json_strs, compression='gzip')
    
    # np.savez_compressed(f"/home/zgtang/{data_name}/dps.npz", json_strs)
    
def tuple_n_general_new(data_name):
    
    dir_name = f"/home/zgtang/{data_name}"
    if os.path.exists(f"{dir_name}/dps.h5"):
        x = h5py.File(f"{dir_name}/dps.h5", 'r')
        json_strs = x['json_strs']
        for x in json_strs[::1000]:
            print(json.loads(x)['rgb_list'])
        input()
        x = [json.loads(x) for x in json_strs]
        split_dps(x, dir_name)
        return
    if os.path.exists(f"/home/zgtang/{data_name}/dps.json"):
        x = json.load(open(f"/home/zgtang/{data_name}/dps.json", 'r'))
        split_dps(x, dir_name)
        return
    dps = []
    # metadata_list = glob.glob("/home/zgtang/scannet_large_easy/*/*extra.pt")
    pt_name = f"/home/zgtang/{data_name}/*/*extra.pt"
    metadata_list = []
    for i in range(6):
        # print(pt_name)
        metadata_list = metadata_list + glob.glob(pt_name)
        pt_name = pt_name.replace("/*extra.pt", "/*/*extra.pt")
    sorted(metadata_list)
    print('tuple in sum', len(metadata_list))
    
    scene_cnt = {}
    for x_id, x in enumerate(metadata_list[::100]):
        dp = {}
        dp['scene_name'] = x.split('/')[-2]
        if dp['scene_name'] not in scene_cnt.keys():
            scene_cnt[dp['scene_name']] = 1
        else:
            scene_cnt[dp['scene_name']] += 1
    print('scene in sum', len(list(scene_cnt.keys())))
        
    scene_cnt = {}
    cnt_failed = 0
    for x_id, x_ in enumerate(metadata_list[::]):
        try:
            x = torch.load(x_)
            # print(x_)
            dp = {}
            dp['scene_name'] = x_.split('/')[-2]
            if dp['scene_name'] not in scene_cnt.keys():
                scene_cnt[dp['scene_name']] = 1
            else:
                scene_cnt[dp['scene_name']] += 1
            
            # print(dp['scene_name'], x)
            # print(x['rgb_list'], x['depth_list'], x['pose_list'])
            # print(x['intrinsic_list'])
            dp['rgb_list'] = x['rgb_list']
            dp['depth_list'] = x['depth_list']
            if 'pose_raw_list' in x.keys():
                dp['pose_raw_list'] = x['pose_raw_list']
            else:
                dp['pose_list'] = x['pose_list']
            if "nv" in x.keys():
                dp['nv'] = x['nv']
            if "intrinsic_raw" in x.keys():
                dp['intrinsic_raw'] = x['intrinsic_raw']
            else:
                dp['intrinsic_list'] = x['intrinsic_list']
            C = np.round(np.array(x['C']), 2).tolist()
            dp['C'] = C
            dps.append(dp)
            if x_id % 20000 == 0:
                print('tuple collecting', len(scene_cnt.keys()), x_id, cnt_failed)
            # print(x)
        except:
            cnt_failed += 1
        
    split_dps(dps, dir_name)
    # # json.dump(dps, open("/home/zgtang/scannet_large_easy/dps.json", 'w'), indent=4) # 134000, 1341
    # json.dump(dps, open(f"/home/zgtang/{data_name}/dps.json", 'w'), indent=4)
    # json_strs = [json.dumps(x) for x in dps]
    # ma_len = max(map(len, json_strs))
    # json_strs = np.array(json_strs, dtype='S'+str(ma_len))
    # with h5py.File(f"/home/zgtang/{data_name}/dps.h5", 'w') as f:
    #     f.create_dataset('json_strs', data=json_strs, compression='gzip')
    
    # np.savez_compressed(f"/home/zgtang/{data_name}/dps.npz", json_strs)
    

# tuple4_huge_tar()

# tuple_n_general(args.data_name)
tuple_n_general_new(args.data_name)
# tuple_n_general("scannet_large_easy_12")
