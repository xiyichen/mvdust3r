import json
import torch
import os, glob, sys
import json

folder_list = glob.glob('/home/zgtang/mp3d/*')

json_dict = []

for folder in folder_list:
    res = {}
    folder = folder.split('/')[-1]
    glb_name = glob.glob(f'/home/zgtang/mp3d/{folder}/*.glb')[0]
    glb_name = glb_name.split('/')[-1]
    navmesh_name = glob.glob(f'/home/zgtang/mp3d/{folder}/*.navmesh')[0]
    navmesh_name = navmesh_name.split('/')[-1]
    res['scene'] = f"./data/habitat-sim-data/scene_datasets/mp3d//{folder}/{glb_name}"
    res['scene_dataset_config_file'] = ""
    res['navmesh'] = f"./data/habitat-sim-data/scene_datasets/mp3d//{folder}/{navmesh_name}"
    res['output_dir'] = f"mp3d/{folder}/"

    json_dict.append(res)

with open('/home/zgtang/mp/mp3d_list.json', 'w') as f:
    json.dump(json_dict, f, indent=4)

'''
{
    "scene": "./data/habitat-sim-data/scene_datasets/mp3d//17DRP5sb8fy/17DRP5sb8fy.glb",
    "scene_dataset_config_file": "",
    "navmesh": "./data/habitat-sim-data/scene_datasets/mp3d//17DRP5sb8fy/17DRP5sb8fy.navmesh",
    "output_dir": "mp3d/17DRP5sb8fy/"
},
'''

'''
{
    "scene": "./data/habitat-sim-data/scene_datasets/mp3d//00000-kfPV7w3FaU5/kfPV7w3FaU5.basis.glb",
    "scene_dataset_config_file": "",
    "navmesh": "./data/habitat-sim-data/scene_datasets/mp3d//00000-kfPV7w3FaU5/kfPV7w3FaU5.basis.navmesh",
    "output_dir": "mp3d/00000-kfPV7w3FaU5/kfPV7w3FaU5.basis"
}
'''
