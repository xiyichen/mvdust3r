from copy import deepcopy
import sys, os


import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--data-name")
parser.add_argument("--n-render", default = 0, type=int)
parser.add_argument("--n-dps", default = 10, type=int)
parser.add_argument("--h5py", default = 0, type=int)
# parser.add_argument("--node-no", default=0, type=int)
args = parser.parse_args()
n_render = args.n_render

import torch.manifold.patch

import PIL
import numpy as np
import torch
import glob, sys
import json
import imageio
import cv2
import h5py

import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__))))

from dust3r.utils.geometry import depthmap_to_absolute_camera_coordinates
from dust3r.pcd_render import pcd_render, save_image_manifold, save_video_combined

from iopath.common.file_io import g_pathmgr

def get_color_linear(x):

    colors = [(255, 0, 0), (255, 165, 0), (255, 255, 0), (0, 128, 0), (0, 0, 255), (75, 0, 130), (238, 130, 238)]
    # Calculate the index of the color based on x
    index = int((len(colors) - 1) * x)
    if index == len(colors) - 1:
        index -= 1
    # Calculate the interpolated RGB values based on x and the surrounding colors
    rate = (x * (len(colors) - 1) - float(index))
    r = int(colors[index][0] + (colors[index + 1][0] - colors[index][0]) * rate)
    g = int(colors[index][1] + (colors[index + 1][1] - colors[index][1]) * rate)
    b = int(colors[index][2] + (colors[index + 1][2] - colors[index][2]) * rate)
    # Return the interpolated RGB values as a tuple
    print('get color linear', x, index, r, g, b)
    return np.array([r, g, b]) / 255

def main(data_name, dps_ids):
    # from fbvscode import set_trace
    # set_trace()
    
    if not h5py:
        with open(f"/home/zgtang/{data_name}/dps.json", 'r') as f:
            json_data = json.load(f)
            data_size = len(json_data)
    else:
        with h5py.File(f"/home/zgtang/{data_name}/dps.h5", 'r') as h5f:
            data_size = len(h5f['json_strs'])
    # import fbvscode
    # fbvscode.set_trace()
    ma_rgb, ma_depth = 0, 0
    # shuffle dps_ids
    if len(dps_ids) == 0:
        dps_ids = list(range(data_size))

    # random_shuffle dps_ids
    np.random.shuffle(dps_ids)
    for dps_id in dps_ids:
        
        if h5py:
            with h5py.File(f"/home/zgtang/{data_name}/dps.h5", 'r') as h5f:
                json_str = h5f['json_strs'][dps_id]
                dps = json.loads(json_str)
        else:
            dps = json_data[dps_id]
        if 'nv' in dps.keys():
            n_view = dps['nv']
        else:
            n_view = len(dps['rgb_list'])
        if 'nv' in dps.keys():
            rgb_raws = imageio.imread(g_pathmgr.get_local_path(dps['rgb_list'][0])).astype(np.float32) / 255
            rgb_raws = np.split(rgb_raws, n_view, axis=1)
            # depths = np.load(g_pathmgr.get_local_path(dps['depth_list'][0]))['arr_0'].astype(np.float32)  # npz
            depths = imageio.imread(g_pathmgr.get_local_path(dps['depth_list'][0])).astype(np.float32) / 1000
            depths = np.split(depths, n_view, axis=1)
        else:
            rgb_raws = [imageio.imread(g_pathmgr.get_local_path(dps['rgb_list'][i])).astype(np.float32) / 255 for i in range(n_view)]
            depths = [imageio.imread(g_pathmgr.get_local_path(dps['depth_list'][i])).astype(np.float32) / 1000 for i in range(n_view)]
        
        ma_rgb_i = np.max(rgb_raws)
        ma_depth_i = np.max(depths)
        ma_rgb = max(ma_rgb, ma_rgb_i)
        ma_depth = max(ma_depth, ma_depth_i)
        print('range', dps_id, ma_rgb_i, ma_depth_i, np.mean(depths), ma_rgb, ma_depth)
        continue
        # import fbvscode
        # fbvscode.set_trace()

        if 'pose_raw_list' in dps.keys():
            poses = [np.array(dps['pose_raw_list'][i]) for i in range(n_view)]
            R = np.eye(4)
            R[:3, :3] = [
                [1, 0, 0],
                [0, 0, -1],
                [0, 1, 0]
            ]
            poses = [np.matmul(R, pose) for pose in poses]
        else:
            poses = [np.loadtxt(g_pathmgr.get_local_path(dps['pose_list'][i])) for i in range(n_view)]
        if "intrinsic_raw" in dps.keys():
            intrinsics = [np.array(dps['intrinsic_raw']) for i in range(n_view)]
        else:
            intrinsics = [np.loadtxt(g_pathmgr.get_local_path(dps['intrinsic_list'][i])) for i in range(n_view)]
        rgbs = []
        rgbs_original = []
        rgbs_all = []
        n_inference = len(rgb_raws) - n_render
        shrink_rate = depths[0].shape[0] // 100

        for rgb_id, rgb in enumerate(rgb_raws):
            rgb = cv2.resize(rgb, (depths[0].shape[1], depths[0].shape[0]))
            rgbs_all.append(deepcopy(rgb))
            rgb = rgb[::shrink_rate,::shrink_rate]
            rgbs_original.append(deepcopy(rgb))
            rgb[:] = get_color_linear(rgb_id / (len(rgb_raws) - 1))
            if rgb_id >= n_inference:
                rgb[:] = (127 + 127. * (rgb_id - n_inference) / n_render) / 255
            rgbs.append(rgb)
        pcds = []
        for i in range(n_view):
            pcd, valid_mask = depthmap_to_absolute_camera_coordinates(depths[i], intrinsics[i], poses[i])
            print('pcd', pcd.shape)
            pcd = pcd[::shrink_rate, ::shrink_rate]
            pcds.append(pcd)
        print('rgb and depth', rgb.shape)
        rgbs = torch.from_numpy(np.stack(rgbs).reshape(-1, 3)).float().cuda()
        rgbs_original = torch.from_numpy(np.stack(rgbs_original).reshape(-1, 3)).float().cuda()
        rgbs_all = np.concatenate(rgbs_all, 1)

        pcds = torch.from_numpy(np.stack(pcds).reshape(-1, 3)).float().cuda()
        print('before pcd_render', pcds.shape, rgbs.shape)
        video_pcd = pcd_render(pcds, rgbs, normalize = True, debug = True)
        video_path = "/home/zgtang/manifold_things/videos_false"
        os.path.exists(video_path) or os.makedirs(video_path)
        save_video_combined([video_pcd], f"{video_path}/{dps_id}_id.mp4")
        imageio.imwrite(f"{video_path}/{dps_id}_rgb.png", rgbs_all)

        video_pcd = pcd_render(pcds, rgbs_original, normalize = True)
        save_video_combined([video_pcd], f"{video_path}/{dps_id}_original.mp4")

# data_name = "scannet_large_easy_12"
# data_name = "scannet_large_12"
data_name = args.data_name
main(data_name, [i for i in range(0, args.n_dps)])
