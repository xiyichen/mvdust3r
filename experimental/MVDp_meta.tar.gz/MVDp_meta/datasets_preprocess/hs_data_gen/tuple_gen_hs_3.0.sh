#!/bin/bash

# n_node=13
# n_process_per_node=8
# n_v=5
# n_render=1
# data_name=hs_tree_old_test_easy_4_1
# n_tuple_per_scene=110
# view_sample_type=tree_old
# random_step_variance=1.0
# render_overlap=0.95
# split=test
# minimum_covisibility=0.3
# maximum_covisibility=0.7

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $i
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility
# done

# n_node=15
# n_process_per_node=8
# n_v=5
# n_render=1
# data_name=hs_tree_old_test_hard_4_1
# n_tuple_per_scene=110
# view_sample_type=tree_old
# random_step_variance=1.0
# render_overlap=0.95
# split=test
# minimum_covisibility=0.1
# maximum_covisibility=0.4

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $i
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility
# done

# n_node=15
# n_process_per_node=8
# n_v=5
# n_render=1
# data_name=hs_tree_old_test_easy_4_1
# n_tuple_per_scene=110
# view_sample_type=tree_old
# random_step_variance=1.0
# render_overlap=0.95
# split=test
# minimum_covisibility=0.3
# maximum_covisibility=0.7

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $i
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility
# done

# n_node=81
# n_process_per_node=8
# n_v=4
# n_render=0
# data_name=hs_tree_hard_4
# n_tuple_per_scene=1000
# view_sample_type=tree_diverse_first
# random_step_variance=2.0
# render_overlap=0.95
# split=all
# minimum_covisibility=0.1
# maximum_covisibility=0.4

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $i
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility
# done


# n_node=41
# n_process_per_node=8
# n_v=4
# n_render=0
# data_name=hs_tree_easy_4
# n_tuple_per_scene=1000
# view_sample_type=tree_diverse_first
# random_step_variance=2.0
# render_overlap=0.95
# split=all
# minimum_covisibility=0.3
# maximum_covisibility=0.7

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $i
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility
# done

# n_node=13
# n_process_per_node=8
# n_v=24
# n_render=0
# data_name=hs_tdf_2_test_24
# n_tuple_per_scene=110
# view_sample_type=tree_diverse_first
# random_step_variance=2.0
# render_overlap=0.95
# split=test
# minimum_covisibility=0.3
# maximum_covisibility=0.7

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $i
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility
# done


# n_node=13
# n_process_per_node=8
# n_v=30
# n_render=6
# data_name=hs_tdf_2_new_test_24_6_0.06
# n_tuple_per_scene=110
# view_sample_type=tree_diverse_first
# random_step_variance=2.0
# render_overlap=0.0
# split=test
# minimum_covisibility=0.3
# maximum_covisibility=0.7


# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $i
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility
# done

# n_node=12
# n_process_per_node=8
# n_v=30
# n_render=6
# data_name=mp3d_tdf_2_new_24_6_0.06
# n_tuple_per_scene=110
# view_sample_type=tree_diverse_first
# random_step_variance=2.0
# render_overlap=0.0
# split=all
# minimum_covisibility=0.3
# maximum_covisibility=0.7
# scene_data_path=/mnt/mffuse/zgtang/data/hs_scene/mp3d_list.json

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $i
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility --scenes_data_path $scene_data_path
# done


# n_node=13
# n_process_per_node=8
# n_v=100
# n_render=0
# data_name=hs_100_all_rnd
# n_tuple_per_scene=1
# view_sample_type=all_rnd
# random_step_variance=2.0
# render_overlap=0.0
# split=test
# minimum_covisibility=0.3
# maximum_covisibility=0.7
# scene_data_path=/mnt/mffuse/zgtang/data/hs_scene/scenes_data.json

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $((8 * i))
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility --scenes_data_path $scene_data_path
# done


# n_node=13
# n_process_per_node=8
# n_v=100
# n_render=0
# data_name=hs_100_tree_loose_1
# n_tuple_per_scene=1
# view_sample_type=tree_loose
# random_step_variance=1.0
# render_overlap=0.0
# split=test
# minimum_covisibility=0.5
# maximum_covisibility=1.0
# scene_data_path=/mnt/mffuse/zgtang/data/hs_scene/scenes_data.json

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $((8 * i))
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility --scenes_data_path $scene_data_path
# done

# n_node=13
# n_process_per_node=8
# n_v=100
# n_render=0
# data_name=hs_100_tree_loose_2
# n_tuple_per_scene=1
# view_sample_type=tree_loose
# random_step_variance=2.0
# render_overlap=0.0
# split=test
# minimum_covisibility=0.5
# maximum_covisibility=1.0
# scene_data_path=/mnt/mffuse/zgtang/data/hs_scene/scenes_data.json

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $((8 * i))
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility --scenes_data_path $scene_data_path
# done

n_node=1
n_process_per_node=8
n_v=100
n_render=0
data_name=hs_100_tree_d_1_0.6
n_tuple_per_scene=1
view_sample_type=tree_diverse_first
random_step_variance=1.0
render_overlap=0.0
split=test
minimum_covisibility=0.5
maximum_covisibility=1.0
scene_data_path=/mnt/mffuse/zgtang/data/hs_scene/scenes_data.json

for ((i=0; i<n_node; i++))
do
  echo $((8 * n_node)) $((8 * i))
  torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility --scenes_data_path $scene_data_path
done

# # the old one.

# n_node=101
# n_process_per_node=8
# n_v=12
# data_name=hs_tree_diverse_first_2
# n_tuple_per_scene=2000
# view_sample_type=tree_diverse_first
# random_step_variance=2.0

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $i
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance
# done

# n_node=16
# n_process_per_node=8
# n_v=15
# n_render=3
# data_name=hs_tree_old_test_easy_12_3
# n_tuple_per_scene=110
# view_sample_type=tree_old
# random_step_variance=1.0
# render_overlap=0.95
# split=test
# minimum_covisibility=0.3
# maximum_covisibility=0.7

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $i
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility
# done

# n_node=15
# n_process_per_node=8
# n_v=15
# n_render=3
# data_name=hs_tree_old_test_easier_12_3
# n_tuple_per_scene=110
# view_sample_type=tree_old
# random_step_variance=1.0
# render_overlap=0.95
# split=test
# minimum_covisibility=0.3
# maximum_covisibility=1.0

# for ((i=0; i<n_node; i++))
# do
#   echo $((8 * n_node)) $i
#   torchx run -s mast_conda -- -h zion_2s -j 1x8 -m hs/generate_multiview_images.py -- --div $((n_process_per_node * n_node)) --start_rank_id $((n_process_per_node * i)) --n_v $n_v --data_name $data_name --n_tuple_per_scene $n_tuple_per_scene --view_sample_type $view_sample_type --random_step_variance $random_step_variance --render_overlap $render_overlap --n_render $n_render --split $split --minimum_covisibility $minimum_covisibility --maximum_covisibility $maximum_covisibility
# done
