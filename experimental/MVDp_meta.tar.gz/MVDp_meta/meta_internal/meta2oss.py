import h5py
import json
import numpy as np

file_name = "/home/zgtang/GD/trajectories/scannet_test/dps_test.h5"

h5py_file = h5py.File(file_name, "r")['json_strs']
json_dict = [json.loads(x) for x in h5py_file]

str_a = r"manifold://scannet_dataset/tree/scans/"
str_b = r"data/scannet/"

for x in json_dict:
    for k in x.keys():
        if isinstance(x[k], list):
            if isinstance(x[k][0], str):
                for i in range(len(x[k])):
                    x[k][i] = x[k][i].replace(str_a, str_b)

json_strs = [json.dumps(x) for x in json_dict]
ma_len = max(map(len, json_strs))
json_strs = np.array(json_strs, dtype='S'+str(ma_len))
with h5py.File(f"/home/zgtang/GD/trajectories/scannet_test/dps_test_local.h5", 'w') as f:
    f.create_dataset('json_strs', data=json_strs, compression='gzip')

json.dump(json_dict, open("/home/zgtang/GD/trajectories/scannet_test/dps_test_local.json", "w"), indent = 4)
