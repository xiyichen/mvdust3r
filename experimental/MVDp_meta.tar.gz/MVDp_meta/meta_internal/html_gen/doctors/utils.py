# pyre-strict
import copy
import glob
import json
import logging
import os
import tempfile
import typing as T

import uuid
from datetime import date, datetime, timedelta

import numpy as np


from iopath.common.file_io import PathManager
from iopath.fb.manifold import ManifoldPathHandler
from jef_clients.core.helpers.subprocess import run_binary


pathmgr = PathManager()
pathmgr.register_handler(ManifoldPathHandler())

# pyre-ignore
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

DATA_DUMPER_TIMEOUT = timedelta(seconds=1200)  # 20 min timeout for running data dumper

SEGM_DEFAULT_INSTANCE_SCORE_THRESHOLD = 0.5
SEGM_DEFAULT_MASK_SCORE_THRESHOLD = 0.8


def run_data_dumper(
    gaia_id: int,
    output_path: str,
    device: str,
    frame_type: int,  # frame_type: 0: save IOT and IR frames in consecutive order; 1: save only IOT frames; 2: save only IR frames
    do_image_binning: bool,
    bolt_pyramid_level: int,  # 1 for euraka
    debug: bool,
    app_depth_pipeline_bin: T.Optional[str] = None,
    build_app_depth_pipeline: bool = False,
    gaia_timestamp_sec: T.Optional[float] = None,
    time_window_sec: T.Optional[float] = None,
    calibration_path: T.Optional[str] = None,
) -> T.Optional[T.Dict[str, T.Any]]:
    """
    Run standalone cpp data dumper app_depth_pipeline_oxx_runner to extract per-timestamp frame data
    """
    # Run command
    bolt_pipeline_output_path = output_path

    cwd = os.getcwd()
    if build_app_depth_pipeline:
        user = os.environ["USER"]
        fbsource_dir = f"/home/{user}/fbsource/"
        os.chdir(fbsource_dir)

        command = [
            "buck2",
            "run",
            # "@arvr/mode/fb-linux-nh/opt-stripped",
            "@arvr/mode/platform010/opt",
            "//arvr/projects/depthsensing/products/depthmanager/depth/apps:app_depth_pipeline_oxx_runner",
            "-m",
            "qualcomm_eva3",
            "--",
        ]

    else:
        assert app_depth_pipeline_bin is not None, "app_depth_pipeline_bin is None"
        command = [
            f"{app_depth_pipeline_bin}",
        ]

    command += [
        "--vrs",
        f"gaia:{gaia_id}",
        "--frame_type",
        f"{frame_type}",
        "--camera_ids",
        "0",
        "1",
        "--product",
        "eureka",
        "--application",
        "passthrough",
        "--stereo_method",
        "no_op",
        "--pose",
        "none",
        "--depth.cherry.runtime",
        "data_dumper",
        "--depth.cherry.data_dumper_dir",
        bolt_pipeline_output_path,
    ]

    if frame_type in (0, 1, 2):
        # Image binning options only apply to eureka
        if device == "eureka":
            if do_image_binning:
                command.extend(["--enable_image_binning"])
            command.extend(["--disable_replay_binning", "--enable_calibration_binning"])
        else:
            assert (
                not do_image_binning
            ), f"Image Binning only supported on Eureka. Got {device}"

        # Pyramid level only supported for grayscale frames
        command.extend(
            [
                "--depth.pyramid",
                str(bolt_pyramid_level),
                "--depth.triangulation_pyramid",
                str(bolt_pyramid_level),
            ]
        )
    else:
        assert not do_image_binning, "Image Binning not supported on color frames"
        assert (
            bolt_pyramid_level == 0
        ), f"Only pyramid level 0 supported on color frames. Got {bolt_pyramid_level}"

    # cherry.device parameter works with arcata input also for stinson and ventura
    # Due to naming inconsistencies, depth app expects arcata as a device name but this class expects seacliff
    command.extend(
        ["--depth.cherry.device", "arcata" if device == "seacliff" else device]
    )

    if gaia_timestamp_sec is not None and time_window_sec is not None:
        command.extend(
            [
                "--start_time",
                str(gaia_timestamp_sec - time_window_sec / 2),
                "--end_time",
                str(gaia_timestamp_sec + time_window_sec / 2),
            ]
        )

    if calibration_path:
        command.extend(["--calib", calibration_path])

    completed_process = run_binary(
        command, check_exit_code=False, timeout=DATA_DUMPER_TIMEOUT, log_output=debug
    )
    if completed_process.returncode != 0:
        logger.error(
            f"Data dumper process failed with code {completed_process.returncode}"
        )
        return None

    # check that files were produced
    im_files = glob.glob(os.path.join(bolt_pipeline_output_path, "*.bin"))
    dc_files = glob.glob(os.path.join(bolt_pipeline_output_path, "*.dc"))
    assert len(im_files) > 0 and (
        len(im_files) == len(dc_files)
    ), "Data dumper process produced none or mismatching output files"
    logger.info("run_data_dumper completed")

    logger.info(f"image files: {len(im_files)}")

    if build_app_depth_pipeline:
        os.chdir(cwd)

    return {
        "im_files": im_files,
        "dc_files": dc_files,
    }


def load_mld_preprocess_data_file(
    data_path: str, height: int, width: int
) -> np.ndarray:
    return np.fromfile(data_path, dtype="float32").reshape(-1, height, width)


def parse_image_id(image) -> T.Tuple[str, str, str]:
    # image_id is f"{recording_id}/{timestamp}/{stream_id}"
    image_id = image.img_id
    logger.info(f"image_id: {image_id}")

    image_id_parts = image_id.split(os.sep)
    assert len(image_id_parts) == 3, f"Invalid image id: {image_id}"

    recording_id, timestamp, stream_id = image_id_parts
    return recording_id, timestamp, stream_id


def get_manifold_vis_dir(manifold_output_dir_per_dataset_per_model: str) -> str:
    return os.path.join(manifold_output_dir_per_dataset_per_model, "vis")


def get_manifold_vis_video_dir(manifold_output_dir_per_dataset_per_model: str) -> str:
    manifold_vis_dir = get_manifold_vis_dir(manifold_output_dir_per_dataset_per_model)
    return os.path.join(manifold_vis_dir, "vis_videos")


def load_config(config_file: str) -> T.Dict[str, T.Any]:
    with pathmgr.open(config_file, "r") as f:
        config = json.load(f)

    config_copy = copy.deepcopy(config)

    if "dataset_default" in config:
        for idx, dataset in enumerate(config["datasets"]):
            for key, value in config["dataset_default"].items():
                if key not in dataset:
                    dataset[key] = value
            config_copy["datasets"][idx] = dataset

    if "model_default" in config:
        for idx, model in enumerate(config["models"]):
            for key, value in config["model_default"].items():
                if key not in model:
                    model[key] = value
            config_copy["models"][idx] = model

    return config_copy


def setup_manifold_output_dir(
    manifold_output_root_dir: str, config: T.Dict[str, T.Any]
) -> T.Tuple[str, str]:
    today = date.today()
    now = datetime.now()
    dt_string = now.strftime("%Y-%m-%d-%H:%M:%S")
    doctor_class = config["doctor"]["class"]

    temp_dir = tempfile.TemporaryDirectory()
    local_config_file_path = os.path.join(temp_dir.name, "config.json")
    with pathmgr.open(local_config_file_path, "w") as f:
        json.dump(config, f, indent=4)

    manifold_output_dir = os.path.join(
        manifold_output_root_dir,
        str(today),
        f"{doctor_class}_{dt_string}_{str(uuid.uuid4().hex)}",
    )
    logger.info(f"manifold_output_dir: {manifold_output_dir}")
    pathmgr.mkdirs(manifold_output_dir)
    # we save a copy of the config file in the output folder.
    remote_config_file_path = os.path.join(manifold_output_dir, "config.json")
    pathmgr.copy_from_local(
        local_config_file_path, remote_config_file_path, overwrite=True
    )

    return manifold_output_dir, remote_config_file_path


def model_description(model_name: str, model_id: T.Optional[str] = None) -> str:
    desc_list = []
    if model_id is not None:
        desc_list.append(model_id)
    desc_list.append(model_name)
    return "_".join(desc_list)
