# pyre-strict
import logging
import os
import typing as T

import cv2

# @manual = //fbsource//third-party/pypi/ffmpeg-python:ffmpeg-python
# import ffmpeg

from iopath.common.file_io import PathManager
from iopath.fb.manifold import ManifoldPathHandler
from yattag import Doc, SimpleDoc


import torch
import torch.manifold.patch

# from ..visualization.ffmpeg import ffprobe_bin

pathmgr = PathManager()
pathmgr.register_handler(ManifoldPathHandler())


logger: logging.Logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# use 90% of typical QHD resolution on 32'' monitor (1440, 2560)
VIDEO_DISPLAY_SIZE = (1296, 2304)  # (H, W)


def video_display_size(video_height: int, video_width: int) -> T.Tuple[int, int]:
    """
    Given a video's height and width, compute its display size
    """
    scale = min(
        VIDEO_DISPLAY_SIZE[0] / video_height,
        VIDEO_DISPLAY_SIZE[1] / video_width,
    )
    return (int(scale * video_height), int(scale * video_width))


def get_cdn_url(manifold_path: str) -> str:
    if manifold_path.startswith("manifold://"):
        manifold_path = manifold_path[len("manifold://") :]
    return f"https://interncache-pnb.fbcdn.net/manifold/{manifold_path}"


def get_gaia_view_url(explorer_url: str) -> str:
    gaia_id = get_recording_id_from_manifold_explorer_url(explorer_url)
    return f"https://www.internalfb.com/gaia/vrswebplayer?uri=gaia%3A{gaia_id}"


def get_manifold_explorer_url(manifold_path: str) -> str:
    if manifold_path.startswith("manifold://"):
        manifold_path = manifold_path[len("manifold://") :]
    return f"https://www.internalfb.com/manifold/explorer/{manifold_path}"


def get_recording_id_from_manifold_explorer_url(explorer_url: str) -> int:
    """
    Input:
        explorer_url is a url to open manifold file in the Manifold explorer, such as the one below

        https://www.internalfb.com/manifold/explorer/output_indoor_seg_training/tree/zyan3/model_doctor/2024-03-05/DepthSegmentationModelDoctor_70aada46b09f49bd8a38fb910a77d7fa/jackalope_v3_test_recordings/mt_argos_v0.2_f525060619_torchscript_int8/vis/vis_videos/131551483381657_model_pred.mp4
    """
    filename = os.path.basename(explorer_url)
    recording_id = int(filename.split("_")[0])
    return recording_id


def build_summary_part_page(
    video_tuples: T.List[T.Tuple[str, str]],
    video_height: int,
    video_width: int,
    doctor_info: T.Dict[str, T.Any],
    model_info: T.Dict[str, T.Any],
    dataset_info: T.Dict[str, T.Any],
    manifold_output_dir: str,
) -> str:
    # Generate html
    doc, tag, text = Doc().tagtext()
    with tag("html"):
        with tag("body"):
            _build_page_header(
                doc,
                tag,
                text,
                doctor_info,
                model_info,
                dataset_info,
                manifold_output_dir,
            )

            for idx, (video_url, explorer_url) in enumerate(video_tuples):

                info_file_name = str(video_url).replace('_and_gt.mp4', '.pth').replace('_and_gt_GS.mp4', '.pth').replace('https://interncache-pnb.fbcdn.net/manifold/', 'manifold://') # https://interncache-pnb.fbcdn.net/manifold/ondevice_ai_writedata/tree/zgtang/dust3r/logs/torchx-dust3r_train-scannetHuge_hard_4x8_GS_sh1_bs16_gt_pcd_local/videos/00000_00000_0000_test_000.pth

                with tag("div", id=f"video-container-{idx}"):
                    gaia_id = get_recording_id_from_manifold_explorer_url(explorer_url)
                    text(f"Recording: {gaia_id}")
                    doc.stag("br")

                    video_name = os.path.basename(video_url)
                    
                    if "_GS.mp4" in str(video_url):
                        text(f"Video name: {video_name}; PCD prediction (left: ours pcd prediction, middle: ours pcd but 3% pcds with lowest confidence are removed, right: gt)" )
                    else:
                        text(f"Video name: {video_name}; 3DGS rgb rendering (Ours, pcd from ours but img from GT, all GT)" )

                    doc.stag("br")

                    with tag("a", href=explorer_url):
                        text("Manifold explorer")
                    doc.stag("br")

                    with tag("a", href=get_gaia_view_url(explorer_url)):
                        text("VRS Web Player")
                    doc.stag("br")

                    with tag(
                        "video",
                        width=f"{video_width}",
                        height=f"{video_height}",
                        controls="loop",
                    ):
                        doc.stag("source", src=video_url, type="video/mp4")
                    # print('video url', video_url)

                    if "_GS.mp4" in str(video_url):
                        doc.stag("br")
                        text(f"3DGS rgb rendering from input views")
                        doc.stag("br")
                        img_url = str(video_url).replace("_and_gt_GS.mp4", "_rgb_all.png")
                        with tag("img", src=img_url, alt="input image"):
                            pass
                        img_url = str(video_url).replace("_and_gt_GS.mp4", "_gs.png")
                        with tag("img", src=img_url, alt="3DGS rgb rendering"):
                            pass
                        img_url = str(video_url).replace("_and_gt_GS.mp4", "_gs_relocated.png")
                        with tag("img", src=img_url, alt="3DGS rgb rendering"):
                            pass
                        doc.stag("br")
                        
                        
                    else:
                        doc.stag("br")
                        text(f"Input image")
                        doc.stag("br")
                        img_url = str(video_url).replace("_and_gt.mp4", "_rgb_all.png")
                        with tag("img", src=img_url, alt="input image"):
                            pass
                        
                        other_info = torch.load(pathmgr.get_local_path(info_file_name))
                        for k in other_info.keys():
                            if type(other_info[k]) != float and type(other_info[k]) != int:
                                continue
                            text(f"{k}: {other_info[k]}")
                            doc.stag("br")
                        
                    
    return doc.getvalue()


def _build_page_header(
    doc: SimpleDoc,
    tag: T.Callable,  # pyre-ignore
    text: T.Callable,  # pyre-ignore
    doctor_info: T.Dict[str, T.Any],
    model_info: T.Dict[str, T.Any],
    dataset_info: T.Dict[str, T.Any],
    manifold_output_dir: str,
) -> None:
    text("XR Model Doctor")
    doc.stag("br")

    manifold_output_dir_url = get_manifold_explorer_url(manifold_output_dir)

    text("Doctor output dir: ")
    with tag("a", href=manifold_output_dir_url):
        text(f"{manifold_output_dir}")

    doc.stag("br")
    text("Doctor info")
    with tag("ul", id="Model doctor"):
        keys = list(doctor_info.keys())
        keys.sort()
        for key in keys:
            with tag("li"):
                text(f"{key}: {doctor_info[key]}")

    doc.stag("br")
    text("Model info")
    with tag("ul", id="Model"):
        keys = list(model_info.keys())
        keys.sort()
        for key in keys:
            with tag("li"):
                text(f"{key}: {model_info[key]}")

    doc.stag("br")
    text("Dataset info")
    with tag("ul", id="Dataset"):
        keys = list(dataset_info.keys())
        keys.sort()
        for key in keys:
            with tag("li"):
                text(f"{key}: {dataset_info[key]}")


def generate_index_html(
    num_videos: int,
    max_videos_per_page: int,
    num_pages: int,
    html_page_paths: T.List[str],
    doctor_info: T.Dict[str, T.Any],
    model_info: T.Dict[str, T.Any],
    dataset_info: T.Dict[str, T.Any],
    manifold_output_dir: str,
    n_epoch = 1,
    n_part_per_epoch = 1,
) -> str:
    doc, tag, text = Doc().tagtext()
    with tag("html"):
        with tag("body"):
            _build_page_header(
                doc,
                tag,
                text,
                doctor_info,
                model_info,
                dataset_info,
                manifold_output_dir,
            )

            doc.stag("br")
            text("Visualization videos of model prediction")

            with tag("ul", id="visualization_video_parts"):
                for idx, html_page_path in enumerate(html_page_paths):
                    with tag("li"):
                        with tag("a", href=html_page_path):
                            start = idx * max_videos_per_page
                            end = min((idx + 1) * max_videos_per_page, num_videos)

                            text(f"Epoch {idx // n_part_per_epoch} Part {idx % n_part_per_epoch}: {start} - {end - 1}")

    return doc.getvalue()


# TODO: @karlab revert to using ffprobe if supported by fblearner
def probe_video_info(video_path: str) -> T.Dict[str, T.Any]:
    logger.info(f"Probing video info from {video_path}")

    video_path_local = pathmgr.get_local_path(video_path)
    probe = ffmpeg.probe(video_path_local, cmd=ffprobe_bin)
    video_streams = [
        stream for stream in probe["streams"] if stream["codec_type"] == "video"
    ]
    logger.info(f"# of video streams {len(video_streams)}")

    if len(video_streams) == 0:
        raise ValueError(f"No video stream found in {video_path}")

    if len(video_streams) > 1:
        logger.warning("Multiple video streams detected!")

    video_stream = video_streams[0]
    return video_stream


def get_video_shape(video_path: str) -> T.Tuple[int, int]:
    local_video_path = pathmgr.get_local_path(video_path)
    cap = cv2.VideoCapture(local_video_path)
    # Read the first frame of the video to get its width and height
    _, first_frame = cap.read()
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    cap.release()
    return (height, width)

def get_epoch_video_n(videos):
    cnt = 0
    for x in videos:
        n = int(x.split('_')[0])
        if n == 0:
            cnt += 1
    return cnt

def vis_video_summary_html(
    manifold_dir: str,
    doctor_info: T.Dict[str, T.Any],
    dataset_info: T.Dict[str, T.Any],
    model_info: T.Dict[str, T.Any],
    manifold_output_dir: str,
    file_ext: str = "mp4",
    max_videos_per_page: int = 20,
) -> str:
    """
    Input:
        manifold_dir: a folder containing a list of videos which visualize the model prediction on a set of gaia recordings. For each video file name, we assume the pattern f"{recording_id}_{free_form_text}.{file_ext}"
        doctor_info: -
        dataset_info: -
        model_info: -
        manifold_output_dir: -
        file_ext: video file extension
        max_videos_per_page: maximum number of videos per page
    Return:
        summary_html_URL: a URL pointing to a html file that contains links to all visualization videos
    """

    videos = [p for p in sorted(pathmgr.ls(manifold_dir)) if p.endswith(file_ext)]
    num_videos = len(videos)
    max_videos_per_page = get_epoch_video_n(videos)
    n_video_per_epoch = max_videos_per_page
    print('videos', videos, num_videos, max_videos_per_page)
    # while max_videos_per_page > 512:
    #     max_videos_per_page //= 2
    if max_videos_per_page > 128:
        max_videos_per_page = 128
    n_part_per_epoch = n_video_per_epoch // max_videos_per_page
    n_epoch = (1 + (num_videos - 1) / n_video_per_epoch) // 1
    if num_videos == 0:
        logger.warning(f"No video found under {manifold_dir}")
        return ""

    video_manifold_paths = []
    for video_filename in videos:
        video_manifold_paths.append(os.path.join(manifold_dir, video_filename))
    return generate_html_summary_from_manifold_paths(
        video_manifold_paths,
        max_videos_per_page,
        manifold_dir,
        doctor_info,
        dataset_info,
        model_info,
        manifold_output_dir,
        n_epoch = n_epoch,
        n_part_per_epoch = n_part_per_epoch
    )


def generate_html_summary_from_manifold_paths(
    video_manifold_paths: T.List[str],
    max_videos_per_page: int,
    manifold_dir: str,
    doctor_info: T.Dict[str, T.Any],
    dataset_info: T.Dict[str, T.Any],
    model_info: T.Dict[str, T.Any],
    manifold_output_dir: str,
    n_epoch = 1,
    n_part_per_epoch = 1,
) -> str:
    """
    Input:
        video_manifold_paths: a list of manifold paths to video files
        max_videos_per_page: maximum number of videos per page
        manifold_dir: output folder under which index.html will be saved
        dataset_info: a dict containing dataset name under the key "name"
        model_info: a dict containing model name under the key "name"
        manifold_output_dir: manifold output root dir
    Return:
        summary_html_URL: a URL pointing to a html file that contains links to all visualization videos
    """

    num_videos = len(video_manifold_paths)
    if num_videos == 0:
        logger.warning("No video found")
        return ""

    dataset_info["total recordings"] = num_videos

    sample_video_path = video_manifold_paths[0]

    if False:
        sample_video_info = probe_video_info(sample_video_path)
        logger.info(f"sample_video_info: {sample_video_info}")

        video_height_display, video_width_display = video_display_size(
            sample_video_info["coded_height"], sample_video_info["coded_width"]
        )
    else:
        video_height, video_width = get_video_shape(sample_video_path)

        video_height_display, video_width_display = video_display_size(
            video_height, video_width
        )

    video_tuples = []
    for video_manifold_path in video_manifold_paths:
        video_tuples.append(
            (
                get_cdn_url(video_manifold_path),
                get_manifold_explorer_url(video_manifold_path),
            )
        )

    num_pages = (num_videos + max_videos_per_page - 1) // max_videos_per_page
    html_page_paths = []
    num_pages_start = num_pages - n_part_per_epoch * 2
    if num_pages_start < 0:
        num_pages_start = 0
    num_pages_start = 0
    for i in range(num_pages_start, num_pages):
        start_idx = i * max_videos_per_page
        end_idx = min((i + 1) * max_videos_per_page, num_videos)

        html_page_path = os.path.join(manifold_output_dir, f"part_{i + 1}.html")
        with pathmgr.open(html_page_path, "w") as f:
            f.write(
                build_summary_part_page(
                    video_tuples[start_idx:end_idx],
                    video_height_display,
                    video_width_display,
                    doctor_info,
                    model_info,
                    dataset_info,
                    manifold_output_dir,
                )
            )

        html_page_paths.append(html_page_path)
        logger.info(f"Write html page for part of visualization to {html_page_path}")

    # generate the final index.html
    index_html_path = os.path.join(manifold_output_dir, "index.html")
    with pathmgr.open(index_html_path, "w") as f:
        f.write(
            generate_index_html(
                num_videos,
                max_videos_per_page,
                num_pages,
                [get_cdn_url(p) for p in html_page_paths],
                doctor_info,
                model_info,
                dataset_info,
                manifold_output_dir,
                n_epoch = n_epoch,
                n_part_per_epoch = n_part_per_epoch
            )
        )
    
    url = get_cdn_url(index_html_path)

    index_html_txt_path = os.path.join(manifold_output_dir, "index_html.txt") # manifold_output_dir is manifold://ondevice_ai_writedata/tree/zgtang/dust3r/logs/xxx/html
    with pathmgr.open(index_html_txt_path, "w") as f:
        f.write(str(url))

    # Write index.html: https://interncache-pnb.fbcdn.net/manifold/ondevice_ai_writedata/tree/zgtang/dust3r/logs/torchx-dust3r_train-scannetHuge_hard_4x8_GS_sh1_bs16_gt_img_only_vis/html/index.html
    logger.info(f"Write index.html: {url}")
    return url
