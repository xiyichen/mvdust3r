# pyre-strict
"""
Add misc utility functions useful for more than 1 subfolder under *model_doctor* folder
"""

import copy
import json
import logging
import os
import typing as T

from fblearner.flow import api as flow

from iopath.common.file_io import PathManager
from iopath.fb.manifold import ManifoldPathHandler
from libfb.py import parutil
from mobile_cv.common.fb.flu.fblearner_helper import get_workflow_run

from mobile_cv.common.fb.flu.fblearner_launch_utils import create_working_path
from mobile_cv.torch.utils_pytorch import comm


MANIFOLD_PATH = "output_indoor_seg_training/tree/users"
MANIFOLD_PREFIX = "manifold://"

DOCTOR_FBPKG = "xr_model_doctor:latest"

logger: logging.Logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

pathmgr = PathManager()
pathmgr.register_handler(ManifoldPathHandler())


def run_cmd(cmd: str) -> str:
    global_rank: int = comm.get_rank()
    local_rank: int = comm.get_local_rank()
    output = os.popen(cmd).read()
    logger.info(f"global rank {global_rank}, local rank {local_rank}, cmd: {cmd}")
    logger.info(f"global rank {global_rank}, local rank {local_rank}, output: {output}")
    return output


# TODO(zyan3): make the function below more general for other models beyond M2F model
def create_config_file_from_template(
    template_config_file: str,
    fbl_job_ids: str,
    model_type: str,
    model_file_name: str,
) -> str:
    """
    Inputs:
        template_config_file: a template config file that contains placeholders to be replaced by actual values
        fbl_job_ids: a list of FBLearner job ids separated by comma, such as "f539307723,f539307724"
        model_path: manifold path to the trained model
    Outputs:
        config_file_path: a path to the config file which includes the exported model path from the FBLearner job

    Currently, it only supports Mask2Former model and does not support Multi-Task (MT) model because MT model needs manual model exportation after the training.
    """
    config_file_name = os.path.basename(template_config_file).split(".")[0]
    with pathmgr.open(template_config_file, "r") as f:
        config = json.load(f)

    model_configs = config["models"]
    assert len(model_configs) >= 1, "Miss model config"

    new_model_configs = []
    for fbl_job_id in fbl_job_ids.split(","):
        wf = get_workflow_run(fbl_job_id)
        out_results = wf.get_results()
        predictor_paths = out_results["predictor_paths"]
        assert model_type in predictor_paths, f"model {model_type} not found!"
        predictor_dir = predictor_paths[model_type]
        predictor_path = os.path.join(predictor_dir, model_file_name)
        # we only make a copy of the first model config in the template
        model_config = copy.deepcopy(model_configs[0])
        model_config["name"] = f"{model_type}_model"
        model_config["id"] = f"{fbl_job_id}"
        model_config["model_path"] = predictor_path

        new_model_configs.append(model_config)

    doctor_config = copy.deepcopy(config)
    doctor_config["models"] = new_model_configs

    working_dir = create_working_path(
        f"model_doctor_{model_type}",
        use_manifold=True,
        parent_dir=MANIFOLD_PATH,
    )

    logger.info(f"working_dir {working_dir}")

    config_file_path = os.path.join(
        working_dir, f"{config_file_name}_{model_config['name']}.json"
    )
    with pathmgr.open(config_file_path, "w") as f:
        json.dump(doctor_config, f)
    logger.info(f"write config json file: {config_file_path}")

    return config_file_path


def pretty_print_nested_dict(d: T.Dict[str, T.Any], indent: int = 0) -> None:
    for key, value in d.items():
        logger.info("\t" * indent + str(key))
        if isinstance(value, dict):
            pretty_print_nested_dict(value, indent + 1)
        else:
            logger.info("\t" * (indent + 1) + str(value))


def get_fblearner_run_id() -> T.Optional[int]:
    run_id = None
    try:
        flow_env = flow.get_flow_environ()
        run_id = flow_env.workflow_run_id
    except Exception:
        logger.warning("fail to get FBlearner workflow run id")

    return run_id


def get_config_file_path(config_file: str) -> str:
    if config_file.startswith(MANIFOLD_PREFIX):
        return config_file
    else:
        return parutil.get_file_path(config_file, pkg=__package__)
