# pyre-ignore

import argparse
import importlib
import json
import logging
import os
import sys
import typing as T
import uuid
from datetime import timedelta
from time import perf_counter

from iopath.common.file_io import PathManager
from iopath.fb.manifold import ManifoldPathHandler
from mobile_cv.torch.utils_pytorch import comm, distributed_helper as dist_helper
from vizard.utils.device_utils import is_device_leased, release_device

from .doctors.utils import (
    get_manifold_vis_video_dir,
    load_config,
    setup_manifold_output_dir,
)
from .frontend.summary_html import vis_video_summary_html

from .utils_misc import get_fblearner_run_id, pretty_print_nested_dict

from iopath.common.file_io import g_pathmgr

pathmgr = PathManager()
pathmgr.register_handler(ManifoldPathHandler())

logging.basicConfig(
    format="%(asctime)s,%(msecs)03d %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s",
    datefmt="%Y-%m-%d:%H:%M:%S",
    level=logging.DEBUG,
)

logger: logging.Logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


DEFAULT_DOCTOR_MODULE = (
    "vizard_projects.ml_depth.tools.model_doctor.doctors.depth_segmentation_model_doctor",
)
DEFAULT_DOCTOR_CLASS = "DepthSegmentationModelDoctor"

MAX_VIS_VIDEOS_PER_PAGE = 10




def generate_html(vis_video_dir, manifold_output_dir,
    doctor_info = {'doc': 'none'},
    dataset_info = {'dataset': 'none'},
    model_info = {'model': 'none'}
):

    g_pathmgr.mkdirs(manifold_output_dir)
    url = vis_video_summary_html(
        vis_video_dir,
        doctor_info,
        dataset_info,
        model_info,
        manifold_output_dir,
        max_videos_per_page=MAX_VIS_VIDEOS_PER_PAGE,
    )
    return url
