# pyre-strict
import logging
import os

from fblearner.flow.facebook.fbpackage import FbPackage

from iopath.common.file_io import PathManager
from iopath.fb.manifold import ManifoldPathHandler

from ..utils_misc import run_cmd


pathmgr = PathManager()
pathmgr.register_handler(ManifoldPathHandler())


# pyre-ignore
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


ffmpeg_pkg: FbPackage = FbPackage("ffmpeg-ref")
ffmpeg_bin: str = os.path.join(ffmpeg_pkg.package_path, "ffmpeg", "bin", "ffmpeg")
ffprobe_bin: str = os.path.join(ffmpeg_pkg.package_path, "ffmpeg", "bin", "ffprobe")


def assemble_frames_into_video(
    local_dir: str,
    manifold_output_dir: str,
    output_video_file_name: str,
    fps: int,
) -> str:
    cwd = os.getcwd()
    os.chdir(local_dir)
    # Generated per-frame images have names of format %08d.png, such as 00000000.png
    # FFMPEG command tutorial:
    #   - https://ffmpeg.org/ffmpeg.html
    #   - https://fburl.com/rayzn7mh
    cmd = f"{ffmpeg_bin} -framerate {fps} -i %08d.png -c:v libx264 -pix_fmt yuv420p -crf 25 -r {fps} {output_video_file_name}"
    run_cmd(cmd)

    manifold_output_video_path = os.path.join(
        manifold_output_dir, output_video_file_name
    )
    pathmgr.copy_from_local(
        output_video_file_name, manifold_output_video_path, overwrite=True
    )
    logger.info(f"write video to manifold: {manifold_output_video_path}")
    os.chdir(cwd)
    return manifold_output_video_path
