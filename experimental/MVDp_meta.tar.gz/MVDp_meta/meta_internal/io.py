# raise Exception("This file is not used anymore.")
import torch.manifold.patch
import os, time

from iopath.common.file_io import g_pathmgr
from on_device_ai.cvg.pipix.mini.distributed import get_local_path, set_device
from on_device_ai.cvg.pipix.mini.logging import get_log_dir

def get_log_dir_warp(output_dir):

    return get_log_dir(
            manifold_bucket="ondevice_ai_writedata",
            manifold_dir="zgtang/dust3r/logs",
            resume_from=output_dir,
        )

def change_to_sr(file_lists):
    results = []
    for file_list in file_lists:
        file_list_new = []
        for f in file_list:
            file_list_new.append(f.replace("manifold://scannet_dataset/tree/scans/", "manifold://on_device_sr/tree/datasets/scannet/scans/"))
        results.append(file_list_new)
    return results

from iopath.common.file_io import g_pathmgr

import imageio

try:
    from fblearner.flow.facebook import fbtypes
    if os.path.exists("/usr/local/fbprojects/ffmpeg-ref/ffmpeg/bin/ffmpeg"):
        os.environ[
            "IMAGEIO_FFMPEG_EXE"
        ] = "/usr/local/fbprojects/ffmpeg-ref/ffmpeg/bin/ffmpeg"
    else:
        ffmpeg_pkg = fbtypes.FBPACKAGE.new("ffmpeg-ref:prod")
        ffmpeg_path = os.path.join(ffmpeg_pkg.package_path, "ffmpeg/bin/ffmpeg")
        os.environ["IMAGEIO_FFMPEG_EXE"] = ffmpeg_path
except:
    pass

def move_manifold2(src, tgt):

    g_pathmgr.copy_from_local(src, tgt, overwrite = True)

def save_image_manifold(img, tgt):

    temp_name = f"/tmp/output_{time.time()}.png"
    imageio.imwrite(temp_name, img)
    move_manifold2(temp_name, tgt)
